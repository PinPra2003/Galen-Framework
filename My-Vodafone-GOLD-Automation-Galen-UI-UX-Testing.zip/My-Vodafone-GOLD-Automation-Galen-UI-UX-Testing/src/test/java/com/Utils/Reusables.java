package com.Utils;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Reusables {

	public static String getdateFormatmonth(String hint, int months, String date) throws Exception {
		String nextday = null;

		try {
			String dt = date;
			SimpleDateFormat ft = new SimpleDateFormat(hint);
			Calendar c = Calendar.getInstance();
			c.setTime(ft.parse(dt));
			c.add(Calendar.MONTH, months);// number of months to add
			nextday = ft.format(c.getTime());
		} catch (Exception localException) {
			System.out.println(localException.getMessage());
			return nextday;
		}
		return nextday;
	}

	public static String getdateFormatdays(String hint, int days, String date) throws Exception {
		String nextday = null;

		try {
			String dt = date;
			SimpleDateFormat ft = new SimpleDateFormat(hint);
			Calendar c = Calendar.getInstance();
			c.setTime(ft.parse(dt));
			c.add(Calendar.DATE, days);// number of months to add
			nextday = ft.format(c.getTime());
		} catch (Exception localException) {
			System.out.println(localException.getMessage());
			return nextday;
		}
		return nextday;
	}

	public static String getdateFormat(String hint, int days) {
		String nextday = null;

		try {
			Date dNow = new Date();
			SimpleDateFormat ft = new SimpleDateFormat(hint);
			//			String today = ft.format(dNow);
			//			Date dtoday = ft.parse(today);
			Calendar c = Calendar.getInstance();
			c.setTime(dNow);
			c.add(Calendar.DATE, days); // number of days to add
			nextday = ft.format(c.getTime());
		} catch (Exception localException) {
			System.out.println(localException.getMessage());
			return nextday;
		}
		return nextday;
	}

	public static String getdateFormat(String date, String in_format, String out_format) throws Exception {
		String out_date = null;

		try {
			SimpleDateFormat ft = new SimpleDateFormat(in_format);
			SimpleDateFormat ft_out = new SimpleDateFormat(out_format);
			Date dNow = ft.parse(date);
			out_date = ft_out.format(dNow);
		} catch (Exception localException) {
			System.out.println(localException.getMessage());
			return out_date;
		}
		return out_date;
	}

	public static String getDaysFrom(String date, String format, int days) throws Exception {
		String nextday = null;
		try {

			SimpleDateFormat ft = new SimpleDateFormat(format);
			Date dNow = ft.parse(date);
			Calendar c = Calendar.getInstance();
			c.setTime(dNow);
			c.add(Calendar.DATE, days); // number of days to add
			nextday = ft.format(c.getTime());
		} catch (Exception localException) {
			System.out.println(localException.getMessage());
			return nextday;
		}
		return nextday;
	}

	public static String getXMLdata(String XMLContent, String NodeName, String TAG) throws Exception {
		String ReturnXMLvalue = null;

		try {
			java.io.FileWriter fw = new java.io.FileWriter(
					System.getProperty("user.dir") + "\\MYXML.xml");
			fw.write(XMLContent);
			fw.close();

			File fXmlFile = new File(System.getProperty("user.dir") + "\\MYXML.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);

			doc.getDocumentElement().normalize();

			NodeList nList = doc.getElementsByTagName(NodeName);
			// System.out.println("Root element :" +
			// doc.getDocumentElement().getNodeName());
			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					ReturnXMLvalue = eElement.getElementsByTagName(TAG).item(0).getTextContent();
					break;
				}
			}
		} catch (Exception e) {

		}
		return ReturnXMLvalue;
	}

	public static int GetNumberOfDaysInAMonth(String Str_RequestedDate) {
		try {
			String date1 = Str_RequestedDate;
			SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			Date convertedDate = new Date();
			try {
				convertedDate = df.parse(date1);
			} catch (Exception e) {
				System.out.print(e);
			}
			Calendar cal = Calendar.getInstance();
			cal.setTime(convertedDate);
			//			int year = cal.get(Calendar.YEAR);
			//			int month = cal.get(Calendar.MONTH);
			//			int day = cal.get(Calendar.DAY_OF_MONTH);
			int numDays;//, startMonth;
			numDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
			return numDays;
		} catch (Exception e) {

		}
		return 0;
	}


	public static String getFutureDate(String Str_NumberOfDays) {
		String formatted =	"";
		try {
			SimpleDateFormat SDF = new SimpleDateFormat("dd-MMM-yy");
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, Integer.parseInt(Str_NumberOfDays));
			formatted = SDF.format(cal.getTime());
		}catch(NullPointerException npe) {

		}catch(Exception e) {

		}
		return formatted;
	}


	public static String RandomName(int count) {


		String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int)(Math.random()*ALPHA_NUMERIC_STRING.length());
			builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
		return builder.toString();
	}

	public static String GetFileContents(String filename) throws Exception {
//		List<String> lines = Files.readAllLines(Paths.get(filename));
		String FileContent = "";
//		for(String A : lines) {
//			FileContent = A;
//			break;
//		}
//		return FileContent.trim();
		

		//br = new BufferedReader(new FileReader(FILENAME));
		FileReader fr = new FileReader(filename);
		BufferedReader br = new BufferedReader(fr);

		String sCurrentLine;

		while ((sCurrentLine = br.readLine()) != null) {
			FileContent+=sCurrentLine;
		}
		return FileContent;
		
	}
}