package com.Utils;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import com.Engine.ExceptionHandlers;
import com.Engine.Reporter;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class ReadExcelSheet {
	public Reporter Report;



	public ReadExcelSheet(Reporter report) {
		Report = report;
	}

	public ReadExcelSheet() {

	}
	// String sheetPath = LoadEnvironment.workingDir+LoadEnvironment.INPUTSHEET;

	public Sheet Excel(String filename, String sheetname) throws Exception {
		Sheet sheet = null;
		try {

			WorkbookSettings settings = new WorkbookSettings();
			settings.setLocale(new Locale("en", "EN"));

			settings.setNamesDisabled(true);
			settings.setFormulaAdjust(true);
			// settings.setMergedCellChecking(true);
			// settings.setCellValidationDisabled(true);

			Workbook workbook = Workbook.getWorkbook(new File(filename), settings);
			sheet = workbook.getSheet(sheetname);
		} catch (Exception e) {
			Report.fnReportFailAndTerminateTest("Failed to read from Excel file", "ReadExcel");
			e.printStackTrace();
		}

		if (sheet == null) {
			System.out.println("NULL SHEET");
		}
		return sheet;
	}

	public String ReadFromExcel(String WorkbookLocation, String SheetName, String TestScript, String PARAMETER)
			throws Exception {

		Sheet sheet = Excel(WorkbookLocation, SheetName);

		int row = 0;
		int column = 0;
		row = sheet.findCell(TestScript).getRow();
		column = sheet.findCell(PARAMETER).getColumn();
		String iterations = sheet.getCell(column, row).getContents();
		System.out.println("the Column is ->" + PARAMETER + " the parameter value is ->" + iterations);
		return iterations;

	}

	/**
	 * This function will retrieve data from excel sheet
	 * 
	 * @param WorkbookLocation
	 * @param SheetName
	 * @param Row
	 * @param PARAMETERS
	 *            multiple parameteres can be sent
	 * @return ReturnValue it contains data from sheet. Multiple data separated
	 *         by '|' character DateModified 10 Aug 2016
	 * @throws Exception
	 */
	public String ReadFromExcelWithRows(String WorkbookLocation, String SheetName, String Row, String... PARAMETERS)
			throws Exception {
		try {
			String ReturnValue = "";
			Sheet sheet = Excel(WorkbookLocation, SheetName);
			int column = 0;
			int row = Integer.parseInt(Row);
			for (String PARAMETER : PARAMETERS) {
				try {
					column = sheet.findCell(PARAMETER).getColumn();
				} catch (NullPointerException e) {
					throw new NullPointerException(PARAMETER + " is not found in the sheet " + SheetName);
				} catch (Exception e) {
					e.printStackTrace();
				}
				String Data = sheet.getCell(column, row).getContents();
				ReturnValue = ReturnValue + "|" + Data;
			}
			return ReturnValue.replaceAll("^\\|", "");
		} catch (NullPointerException npe) {
			npe.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public Map<String, String> CreateMapFromExcel(String WorkbookLocation, String SheetName, String Row)
			throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		if (Row.equals("-1")) {
			// map.put("BROWSER",
			// LoadEnvironment.ENV_DATA_MAP.get("DefaultBrowser").toString().toUpperCase());
			// map.put("MODE",
			// LoadEnvironment.ENV_DATA_MAP.get("DefaultMode").toString().toUpperCase());

			// map.put("BROWSER", "CHROME");
			// map.put("MODE", "DESKTOP");
		} else {
			Sheet sheet = Excel(WorkbookLocation, SheetName);
			int column = sheet.getColumns();
			int row = Integer.parseInt(Row);
			for (int i = 0; i < column; i++) {
				String KEY = sheet.getCell(i, 0).getContents();
				String VALUE = sheet.getCell(i, row).getContents();
				if (VALUE == null) {
					VALUE = "";
				}
				map.put(KEY, VALUE);
			}
		}
		return map;
	}

	public static Multimap<String, String> GetMSOMatrix(String SCRIPT_ID ,String WorkBookPath, String WorkSheetname) throws Exception {
		Multimap<String, String> multimap = ArrayListMultimap.create();
		Workbook workbk;
		workbk = Workbook.getWorkbook(new File(WorkBookPath));

		Sheet sht = workbk.getSheet(WorkSheetname);
		ReadExcelSheet RX = new ReadExcelSheet(null);
		Sheet sheet = RX.Excel(WorkBookPath, WorkSheetname);
		int row = sheet.getRows();
		int SCRIPT_ID_COLUMN = sheet.findCell("SCRIPT_ID").getColumn();
		int PROPOSITION_COLUMN = sheet.findCell("PROPOSITION").getColumn();
		int PLAN_COLUMN = sheet.findCell("PLAN").getColumn();

		for (int i = 0; i < row; i++) {
			if ((sht.getCell(SCRIPT_ID_COLUMN, i).getContents().equalsIgnoreCase(SCRIPT_ID))) {
				multimap.put(sht.getCell(PROPOSITION_COLUMN, i).getContents().toString(), sht.getCell(PLAN_COLUMN, i).getContents().toString());
			}
		}
		return multimap;
	}

	public static String GetIMEIDetails(String WorkBookPath, String WorkSheetname) throws Exception {
		
		Workbook   workbk= Workbook.getWorkbook(new File(WorkBookPath));
		Sheet  sht = workbk.getSheet(WorkSheetname);
		int row = sht.getRows();
		int AVAILABILITY = sht.findCell("AVAILABILITY").getColumn();
		int IMEI = sht.findCell("IMEI").getColumn();
		
		
     		String IMEI_VALUE="";
		for (int i = 0; i < row; i++) {
			if ((sht.getCell(AVAILABILITY, i).getContents().equalsIgnoreCase("YES"))) {
				IMEI_VALUE = sht.getCell(IMEI, i).getContents().toString();
				  
			}
		}
		
		return IMEI_VALUE;
	}
	
public static String GetSIMDetails(String WorkBookPath, String WorkSheetname) throws Exception {
		
		Workbook   workbk= Workbook.getWorkbook(new File(WorkBookPath));
		Sheet  sht = workbk.getSheet(WorkSheetname);
		int row = sht.getRows();
		int AVAILABILITY = sht.findCell("AVAILABILITY").getColumn();
		int IMEI = sht.findCell("SIM").getColumn();
		
		
     		String IMEI_VALUE="";
		for (int i = 0; i < row; i++) {
			if ((sht.getCell(AVAILABILITY, i).getContents().equalsIgnoreCase("YES"))) {
				IMEI_VALUE = sht.getCell(IMEI, i).getContents().toString();
				  
			}
		}
		
		return IMEI_VALUE;
	}

}
