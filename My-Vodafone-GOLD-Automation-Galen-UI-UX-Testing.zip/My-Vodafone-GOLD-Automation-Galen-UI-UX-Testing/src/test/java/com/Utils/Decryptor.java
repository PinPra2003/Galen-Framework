package com.Utils;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.Properties;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.properties.EncryptableProperties;

public class Decryptor {

	public static String workingDir = System.getProperty("user.dir");

	public static void main(String[] args) {

		 String[] BENV = {"1"};
		for (String ENV : BENV) {
			DENCProperToMapLoader("DOWNSTREAM ENVIRONMENT ie; TRIO PROPERTIES", ENV,
					workingDir + "/PropertyFiles/EnvironmentProperties/" + ENV + ".properties");
		}
	}

	public static void DENCProperToMapLoader(String PropertyType, String PropertyIdentifier, String PropertyLocation) {
		try {
			String TEXT = "";
			StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
			encryptor.setPassword("AUTOMATION"); // could be got from web, env
													// variable...
			Properties prop = new EncryptableProperties(encryptor);
			prop.load(new FileInputStream(PropertyLocation));
			for (String key : prop.stringPropertyNames()) {
				System.out.println(key + "=" + prop.getProperty(key));
				TEXT = TEXT + key + "=" + prop.getProperty(key) + "\n";
			}
			FileWriter writer = new FileWriter(PropertyLocation);
			writer.write(TEXT);
			writer.flush();
			writer.close();
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}
}
