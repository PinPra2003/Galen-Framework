package com.Utils;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.util.Properties;

import org.jasypt.util.text.BasicTextEncryptor;

public class Encryptor {

	public static String workingDir = System.getProperty("user.dir");

	public static void main(String[] args) {

		String[] BENV = { "1" };

		for (String ENV : BENV) {
			PropertyEncryptor("DOWNSTREAM ENVIRONMENT ie; TRIO PROPERTIES", ENV,
					workingDir + "/PropertyFiles/EnvironmentProperties/" + ENV + ".properties");
		}

	}

	public static void PropertyEncryptor(String PropertyType, String PropertyIdentifier, String PropertyLocation) {
		Properties prop = new Properties();
		InputStream input = null;
		String TEXT = "";
		try {
			input = new FileInputStream(PropertyLocation);
			prop.load(input);
			for (String key : prop.stringPropertyNames()) {
				BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
				textEncryptor.setPassword("AUTOMATION");
				String myEncryptedText = textEncryptor.encrypt(prop.getProperty(key));
				// String plainText =
				textEncryptor.decrypt(myEncryptedText);
				System.out.println(key + "=ENC(" + myEncryptedText + ")");
				TEXT = TEXT + key + "=ENC(" + myEncryptedText + ")" + "\n";
			}
			FileWriter writer = new FileWriter(PropertyLocation);
			writer.write(TEXT);
			writer.flush();
			writer.close();
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

}
