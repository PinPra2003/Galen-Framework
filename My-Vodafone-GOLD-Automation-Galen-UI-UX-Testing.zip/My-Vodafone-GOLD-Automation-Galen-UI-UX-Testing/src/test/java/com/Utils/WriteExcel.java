package com.Utils;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.Engine.CommonStaticVariables;
import com.Engine.Reporter;

import jxl.*;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

/**
 * @author 661317
 *
 */
public class WriteExcel{
	public static void main(String args[]) throws Exception {
		//		for(int i=0;i<10;i++) {
		//			Random r = new Random();
		//			int Low = 100;
		//			int High = 1100;
		//			int Result = r.nextInt(High-Low) + Low;System.out.println("WXCEL WRITE WAIT "+ Result);
		//		}

		System.out.println(GET_IMEI_SIM_DETAILS("IMEI"));
		System.out.println(GET_IMEI_SIM_DETAILS("SIMS"));
	}

	public static synchronized void TestDataWriteDataExcel(String OrderID,String CustomerType,String RowID, Reporter report)throws Exception {
		//Random Sleep
		Random r = new Random();
		int Low = 100;
		int High = 1100;
		int Result = r.nextInt(High-Low) + Low;System.out.println("WXCEL WRITE WAIT "+ Result);
		Thread.sleep(Result);		
		FileInputStream fis = null ;XSSFWorkbook workbook = null;XSSFSheet sheet=null;

		String FileName = System.getProperty("user.dir")+"/DataProvider/TESTDATA_RESULTS"+CommonStaticVariables.ReportStartTime+".xlsx";

		if(new File(FileName).exists()) {
			fis= new FileInputStream(new File(FileName));
			workbook = new XSSFWorkbook (fis);
			sheet = workbook.getSheet("TESTDATA");
		}else {
			workbook = new XSSFWorkbook ();
			sheet = workbook.createSheet("TESTDATA");
		}


		//		FileInputStream fis = new FileInputStream(new File(FileName));
		//		XSSFWorkbook workbook = new XSSFWorkbook (fis);
		//		XSSFSheet sheet = workbook.getSheet("TESTDATA");
		XSSFRow row = sheet.createRow(Integer.parseInt(report.CurrentRowOfExecution));
		//XSSFRow row1 = sheet.createRow(Integer.parseInt(row));
		XSSFCell cell1 = row.createCell(0);
		cell1.setCellValue(OrderID);
		cell1 = row.createCell(1);
		cell1.setCellValue(CustomerType);
		cell1 = row.createCell(2);
		cell1.setCellValue(RowID);

		if(new File(FileName).exists()) {fis.close();}
		//		fis.close();
		FileOutputStream fos =new FileOutputStream(new File(FileName));
		workbook.write(fos);
		fos.close();
		System.out.println("Done");


	}
	public static synchronized void TestDataWriteDataExcelPlan(String prop, String plan_From_List, String currentRowOfExecution)throws Exception {
		//Random Sleep
		Random r = new Random();
		int Low = 100;
		int High = 1100;
		int Result = r.nextInt(High-Low) + Low;System.out.println("WXCEL WRITE WAIT "+ Result);
		Thread.sleep(Result);

		FileInputStream fis = null ;XSSFWorkbook workbook = null;XSSFSheet sheet=null;

		String FileName = System.getProperty("user.dir")+"/DataProvider/TESTDATA_RESULTS"+CommonStaticVariables.ReportStartTime+".xlsx";

		if(new File(FileName).exists()) {
			fis= new FileInputStream(new File(FileName));
			workbook = new XSSFWorkbook (fis);
			sheet = workbook.getSheet("TESTDATA");
		}else {
			workbook = new XSSFWorkbook ();
			sheet = workbook.createSheet("TESTDATA");
		}

		//		FileInputStream fis = new FileInputStream(new File(FileName));
		//		XSSFWorkbook workbook = new XSSFWorkbook (fis);
		//		XSSFSheet sheet = workbook.getSheet("TESTDATA");
		XSSFRow row = sheet.getRow(Integer.parseInt(currentRowOfExecution));
		//XSSFRow row1 = sheet.createRow(Integer.parseInt(row));
		XSSFCell cell1 = row.createCell(3);
		cell1.setCellValue(prop);
		cell1 = row.createCell(4);
		cell1.setCellValue(plan_From_List);


		if(new File(FileName).exists()) {fis.close();}
		//		fis.close();
		FileOutputStream fos =new FileOutputStream(new File(FileName));
		workbook.write(fos);
		fos.close();
		System.out.println("Done");


	}

	public static synchronized void WriteSRFDetails(String SheetName, Map<String, String> SRF_MAP)throws Exception {
		//Random Sleep
		Random r = new Random();
		int Low = 100;
		int High = 1100;
		int Result = r.nextInt(High-Low) + Low;System.out.println("WXCEL WRITE WAIT "+ Result);
		Thread.sleep(Result);	
		FileInputStream fis = null ;XSSFWorkbook workbook = null;

		String FileName = System.getProperty("user.dir")+"/DataProvider/SRF_RESULTS_"+CommonStaticVariables.ReportStartTime+".xlsx";

		if(new File(FileName).exists()) {
			fis= new FileInputStream(new File(FileName));
			workbook = new XSSFWorkbook (fis);

		}else {
			workbook = new XSSFWorkbook ();
		}


		XSSFSheet sheet = workbook.createSheet(SheetName);

		Iterator it = SRF_MAP.entrySet().iterator();
		int RowCounter = 0;
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry)it.next();
			System.out.println(pair.getKey() + " = " + pair.getValue());
			XSSFRow row = sheet.createRow(RowCounter);
			XSSFCell cell1 = row.createCell(0);
			cell1.setCellValue(pair.getKey().toString());
			cell1 = row.createCell(1);
			cell1.setCellValue(pair.getValue().toString());
			it.remove(); // avoids a ConcurrentModificationException
			RowCounter++;
		}

		if(new File(FileName).exists()) {fis.close();}
		FileOutputStream fos =new FileOutputStream(new File(FileName));
		workbook.write(fos);
		fos.close();
		System.out.println("Done");


	}

	public static Sheet Excel(String filename, String sheetname) throws Exception {
		Sheet sheet = null;
		try {

			WorkbookSettings settings = new WorkbookSettings();


			settings.setNamesDisabled(true);
			settings.setFormulaAdjust(true);


			Workbook workbook = Workbook.getWorkbook(new File(filename), settings);
			sheet = workbook.getSheet(sheetname);
		} catch (Exception e) {

			e.printStackTrace();
		}

		if (sheet == null) {

		}
		return sheet;
	}



	public static WritableWorkbook CreateWorkBook() throws IOException{
		WritableWorkbook myFirstWbook = null;
		String EXCEL_FILE_LOCATION = System.getProperty("user.dir")+"/DataProvider/TESTDATA_RESULTS"+Reusables.getdateFormat("dd_MM_yy_hh_mm_ss", 0)+".xls";


		try{		
			myFirstWbook = Workbook.createWorkbook(new File(EXCEL_FILE_LOCATION));

		}catch(Exception e){
			e.printStackTrace();
		}
		return myFirstWbook;
	}


	public static void writeWorkBook(WritableWorkbook myFirstWbook) throws Exception{

		myFirstWbook.write();

	}
	public static void closeWorkBook(WritableWorkbook myFirstWbook) throws IOException{
		if (myFirstWbook != null) {
			try {
				myFirstWbook.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static WritableSheet writeHeader(WritableSheet excelSheet,String header) throws Exception{
		int TempcontentCounter=0;
		for(String Tempcontent : header.split(",")){
			System.out.println(TempcontentCounter+"==="+Tempcontent);
			Label label = new Label(TempcontentCounter, 0, Tempcontent);
			excelSheet.addCell(label);
			TempcontentCounter++;
		}
		return excelSheet;
	}


	public static void fileWrite(String Filename , String Contents) throws Exception {

		File file = new File(Filename);
		FileOutputStream fop = new FileOutputStream(file);

		if (!file.exists()) {
			file.createNewFile();
		}

		// get the content in bytes
		byte[] contentInBytes = Contents.getBytes();

		fop.write(contentInBytes);
		fop.flush();
		fop.close();

		System.out.println("Done");
	}
	public static synchronized String GET_IMEI_SIM_DETAILS(String SheetName)throws Exception {
		String returnValue="";	
		FileInputStream fis = null ;XSSFWorkbook workbook = null;XSSFSheet sheet=null;XSSFRow row=null;

		String FileName = System.getProperty("user.dir")+"/DataProvider/TESTDATA_INPUT.xlsx";

		if(new File(FileName).exists()) {
			fis= new FileInputStream(new File(FileName));
			workbook = new XSSFWorkbook (fis);
			sheet = workbook.getSheet(SheetName);
		}

		int rownum = sheet.getLastRowNum();
		for(int count=1;count<=rownum;count++) {
			row = sheet.getRow(count);
			if( row.getCell(1).toString().equalsIgnoreCase("YES")) {
				returnValue = row.getCell(0).toString();
				row.getCell(1).setCellValue("NO");
				
				//remove '
				
				break;
			}
		}

		if(new File(FileName).exists()) {fis.close();}
		FileOutputStream fos =new FileOutputStream(new File(FileName));
		workbook.write(fos);
		fos.close();
		System.out.println("Done");
		return returnValue;
	}


}