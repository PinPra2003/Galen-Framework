package com.WebActions;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.Engine.ExceptionHandlers;
import com.Engine.LoadEnvironment;
import com.Engine.Reporter;
import com.SharedModules.Constants;
import com.galenframework.api.Galen;
import com.galenframework.api.GalenPageDump;
import com.galenframework.reports.GalenTestInfo;
import com.galenframework.reports.model.LayoutReport;
import com.relevantcodes.extentreports.LogStatus;

public class WebActions extends LoadEnvironment implements Constants {

	public WebDriver driver;
	//	public Selenium selenium;
	public Reporter Report;
	public int SMALL_TIMEOUT = Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("SMALL_TIMEOUT"));
	public int LOOP_TIMEOUT = Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_TIMEOUT"));
	public int LOW_LOOP_TIMEOUT = Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOW_LOOP_TIMEOUT"));	
	public int LARGE_TIMEOUT = Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LARGE_TIMEOUT"));
	public int SMALL_LOOP_TIMEOUT = Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("SMALL_LOOP_TIMEOUT"));
	public static int empty_int = 999;

	public WebActions() {

	}

	public WebActions(WebDriver Driver, Reporter report) {
		driver = Driver;
		Report = report;

	}

	public void AssertIsTrue(boolean condition, String testname, String whatYouAreLookingFor) throws Exception {

		try {
			Assert.assertTrue(condition, "Please refer to the screeen shot " + testname + ".jpg for more details");
			Report.ReporterLog(whatYouAreLookingFor + " is found", LogStatus.PASS);
		} catch (Exception exception) {
			Report.ReporterLog(whatYouAreLookingFor + " is not found", LogStatus.FAIL, driver);
			Report.TESTPASSED = false;
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage());
		}
	}

	public boolean elementExistsinDOM(String element, int localTimeout) {
		if (waitForElementinDOM(getElementFromLoc(element), localTimeout) != null) {
			return true;
		} else {
			return false;
		}
	}

	public WebElement waitForElementinDOM(By elementId, int timeoutInSeconds) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, timeoutInSeconds * 3);

			wait.until(ExpectedConditions.presenceOfElementLocated(elementId));
			return driver.findElement(elementId);
		} catch (Exception e) {
			System.out.println("element not found " + elementId + " Error message:" + e.getMessage());
			return null;
		}

	}

	public void SpecCheck(String SpecFile, String... DeviceList) throws Exception {
		Report.fnReportInfo("SPEC CHECK CARRIED OUT FOR "+driver.getCurrentUrl()+" with spec file "+SpecFile);

		try {
			if (DeviceList.length > 0) {
				for (String Devices : DeviceList) {
					System.out.println(Devices);
					int height = 0, width = 0;
					switch (Devices.toUpperCase()) {
					case "DESKTOP":
						driver.manage().window().maximize();
						width=driver.manage().window().getSize().getWidth();height=driver.manage().window().getSize().getHeight();
						break;
					case "TABLET_IPAD_L":
						width = 768;
						height = 1024;
						driver.manage().window().setSize(new Dimension(width, height));
						break;
					case "TABLET_IPAD_P":
					case "TABLET":
						width = 1024;
						height = 768;
						driver.manage().window().setSize(new Dimension(width, height));
						break;
					case "MOBILE_IPHONE6_L":
						width = 667;
						height = 375;
						driver.manage().window().setSize(new Dimension(width, height));
						break;
					case "MOBILE_IPHONE6_P":
					case "MOBILE":
						width = 375;
						height = 667;
						driver.manage().window().setSize(new Dimension(width, height));
						break;

					}
					System.out.println(System.getProperty("user.dir")+ 
							"/Specification/" + SpecFile);
					LayoutReport layoutReport = Galen.checkLayout(driver,System.getProperty("user.dir")+ 
							"/Specification/" + SpecFile,
							Arrays.asList(Devices.toUpperCase()));
					// Creating an object that will contain the information
					// about the test
					GalenTestInfo test = GalenTestInfo.fromString(SpecFile + " on "+Devices+" mode ");

					// Adding layout report to the test report
					test.getReport().layout(layoutReport, "Layout check carried out on : " +Devices + " with resolution : Width = "+width + " and Height ="+ height);
					Report.GALENTEST.add(test);
				}
			}
		} catch (Exception exception) {
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage(),driver);
		}
	}

	public void SpecCheck(String TestName, boolean SpecCheck ,boolean PageDump, String SpecFile, String... DeviceList) throws Exception {
		Report.fnReportInfo("SPEC CHECK CARRIED OUT FOR "+driver.getCurrentUrl()+" with spec file "+SpecFile);

		try {
			String SpecFilePath = getSpecPath(GalenSpecFileFolder, SpecFile);
			//Need to Externalise
			if (DeviceList.length > 0) {
				for (String Devices : DeviceList) {
					System.out.println(Devices);
					int height = 0, width = 0;
					switch (Devices.toUpperCase()) {
					case "DESKTOP":
						driver.manage().window().maximize();
						width=driver.manage().window().getSize().getWidth();height=driver.manage().window().getSize().getHeight();
						break;
					case "TABLET_IPAD_L":
						width = 768;
						height = 1024;
						driver.manage().window().setSize(new Dimension(width, height));
						break;
					case "TABLET_IPAD_P":
					case "TABLET":
						width = 1024;
						height = 768;
						driver.manage().window().setSize(new Dimension(width, height));
						break;
					case "MOBILE_IPHONE6_L":
						width = 667;
						height = 375;
						driver.manage().window().setSize(new Dimension(width, height));
						break;
					case "MOBILE_IPHONE6_P":
					case "MOBILE":
						width = 375;
						height = 667;
						driver.manage().window().setSize(new Dimension(width, height));
						break;

					}
					System.out.println(SpecFilePath);

					if(SpecCheck) {
						LayoutReport layoutReport = Galen.checkLayout(driver,SpecFilePath,Arrays.asList(Devices.toUpperCase()));
						// Creating an object that will contain the information about the test
						GalenTestInfo test = GalenTestInfo.fromString(TestName + " on "+Devices+" mode ");

						// Adding layout report to the test report
						test.getReport().layout(layoutReport, "Layout check carried out on : " +Devices + " with resolution : Width = "+width + " and Height ="+ height);
						Report.GALENTEST.add(test);
					}
					if(PageDump) {
						//Page Dump
						try {
							String ReportLocation = Report.ScreenshotLocation+"/PageDump/"+SpecFile.substring(0, SpecFile.length()-6)+"/"+Devices;//Changed
							GalenPageDump GPD = new GalenPageDump(SpecFile);//Changed
							GPD.dumpPage(driver,SpecFilePath,ReportLocation);
						}catch(Exception e){
							e.printStackTrace();
						}
					}
					driver.manage().window().maximize();
				}
			}
		} catch (Exception exception) {
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage(),driver);
		}
	}

	
	public void SpecCheck(String SpecFile, String DeviceName, boolean Tocheck) {
		/* PROVIDE THE SYSTEM VARIABLE FOR RWD TESTING */
		if (System.getProperty("RWD_TESTING") != null && Boolean.valueOf(System.getProperty("RWD_TESTING"))) {

			try {
				LayoutReport layoutReport = Galen.checkLayout(driver, "Specifications/" + SpecFile + DeviceName,
						Arrays.asList(DeviceName.toUpperCase()));
				// Creating an object that will contain the information about
				// the test
				GalenTestInfo test = GalenTestInfo.fromString(SpecFile);
				// Adding layout report to the test report
				test.getReport().layout(layoutReport, "check layout on " + DeviceName + " device");
				Report.GALENTEST.add(test);
			} catch (Exception exception) {
				exception.printStackTrace();
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), exception.getMessage());
			}
		}
	}

	// Function that waits till the loading wheel vanishes
	public void fnWaitTillLoadingWheelVanishes() {
		WebDriverWait mylocalWait = new WebDriverWait(driver, LOOP_TIMEOUT);
		mylocalWait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//*[@id='loadingBar']")));
	}

	public static By getElementFromLoc(String target) {
		StringBuffer element = new StringBuffer(target);
		if (target.startsWith("//") || target.startsWith("(//")) {
			return (By.xpath(element.toString()));
		}
		if (target.startsWith("xpath=") || target.startsWith("XPATH=")) {
			element.delete(0, 6);
			return (By.xpath(element.toString()));
		}
		if (target.startsWith("id=") || target.startsWith("ID=")) {
			element.delete(0, 3);
			return (By.id(element.toString()));
		}
		if (target.startsWith("name=") || target.startsWith("NAME=")) {
			element.delete(0, 5);
			return (By.name(element.toString()));
		}
		if (target.startsWith("css=") || target.startsWith("CSS=")) {
			element.delete(0, 4);
			return (By.cssSelector(element.toString()));
		}
		if (target.startsWith("link=") || target.startsWith("LINK=")) {
			element.delete(0, 5);
			return (By.linkText(element.toString()));
		}
		if (target.startsWith("tagname=") || target.startsWith("TAGNAME=")) {
			element.delete(0, 8);
			return (By.tagName(element.toString()));
		}
		if (target.startsWith("classname=") || target.startsWith("CLASSNAME=")) {
			element.delete(0, 10);
			return (By.className(element.toString()));
		}
		return null;
	}

	public WebElement waitForElement(By elementId, int LOOP_TIMEOUT) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, LOOP_TIMEOUT);

			wait.until(ExpectedConditions.visibilityOfElementLocated(elementId));
			return driver.findElement(elementId);
		} catch (Exception exception) {
			System.out.println("element not found " + elementId + " Error message:" + exception.getMessage());
			return null;
		}

	}//

	public boolean DoesElementExists(String element) {
		try {
			By byElement = getElementFromLoc(element);
			if (waitForElementToAppear(byElement, SMALL_LOOP_TIMEOUT)) {
				WebElement Newelement = driver.findElement(byElement);
				if (Newelement.isDisplayed()) {
					return true;
				} else {
					return false;
				}

			}

		} catch (Exception exception) {
			// ExceptionHandlers.FinalExceptionHandler(Report, new
			// Object(){}.getClass().getEnclosingMethod().getName(),exception.getMessage());
			return false;
		}
		return false;
	}

	public void waitForElementToDisappear(String element, int LOOP_TIMEOUT) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, LOOP_TIMEOUT * 10);

			wait.until(ExpectedConditions.invisibilityOfElementLocated(getElementFromLoc(element)));
			System.out.println("element disappeared " + element);
		} catch (Exception exception) {
			System.out.println("element not found " + element + " Error message:" + exception.getMessage());
		}

	}

	/*
	 * public boolean waitForCondition(ExpectedConditions custCondition, String
	 * condition) { try {
	 * 
	 * myWait.until((Predicate<WebDriver>) custCondition);
	 * System.out.println(condition+" : achieved");
	 * 
	 * return true; } catch (Exception exception) {
	 * System.out.println(condition); return false; }
	 * 
	 * }
	 */

	// /Waits for a webelement and returns true if found or false if not found
	// /<Returns> True if element is found in the given time or returns false
	// /<Parameter elementId > the id of the element we are looking for
	// /<Parameter LOOP_TIMEOUT> number of seconds to wait for the element
	public boolean waitForElementToAppear(By elementId, int time) {
		if (waitForElement(elementId, time) != null) {
			return true;
		} else {
			return false;
		}
	}

	public void VerifyElementAppearAndClickUntilDisappear(String element, String elementname)
			throws InterruptedException {
		int i;
		for (i = 0; i < 50 && waitForElementToAppear(element, 1); i++) {
			try {
				driver.findElement(getElementFromLoc(element)).click();
				Thread.sleep(1000);
			} catch (Exception exception) {
			}
		}
		if (i == 50) {
			Report.fnReportFailAndTerminateTest("Element still present", elementname + " still appears in the page",
					driver);
		}

		else {
			Report.fnReportPass("Clicked on " + elementname);
		}
	}

	public boolean waitForElementToAppear(String element, int time) {
		if (waitForElement(getElementFromLoc(element), time) != null) {
			return true;
		} else {
			return false;
		}
	}

	public boolean waitForTableRefresh(By elementId, int time) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, time * 3);
			// wait.until(ExpectedConditions.invisibilityOfElementLocated(By
			// .xpath("//*[@id='loadingBar']")));
			wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOfElementLocated(elementId)));

			return true;
		} catch (Exception exception) {
			System.out.println("element not found " + elementId + " Error message:" + exception.getMessage());
			return false;
		}
	}

	public void VerifyElementPresentAndAssertClick(String TargetElement, String elementname, String ResultantElement)
			throws Exception {
		int i = 0;
		while (i == 0) {
			for (int second = 0;; second++) {
				if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
					Report.ReporterLog(elementname + " link is not found", LogStatus.FAIL);
					ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
					}.getClass().getEnclosingMethod().getName(), elementname);
				}
				try {
					By byElement = getElementFromLoc(TargetElement);
					if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {

						Report.ReporterLog(elementname + " is found", LogStatus.PASS);
						WebElement WE = driver.findElement(byElement);
						Thread.sleep(200);
						// selenium.click(xpath);
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", WE);
						driver.findElement(byElement).click();
						isAlertPresent();

						Report.ReporterLog("Clicked on " + elementname, LogStatus.PASS);

						break;
					}
				} catch (Exception exception) {
					System.out.println("-----------------------------------------------------------------------");
					System.out.println(exception.getLocalizedMessage());
					System.out.println("-----------------------------------------------------------------------");

					Report.ReporterLog(elementname + " link is not found", LogStatus.FAIL);

					ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
					}.getClass().getEnclosingMethod().getName(), elementname);
					i = 1;

				}
				// Thread.sleep(1000);
			}
			try {
				driver.findElement(getElementFromLoc(ResultantElement));
				i = 1;
			} catch (Exception exception) {
				System.out.println("Trying to click on Target Element");
			}
		}
	}

	public boolean elementExists(String element, int localLOOP_TIMEOUT) {
		if (waitForElement(getElementFromLoc(element), localLOOP_TIMEOUT) != null) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isAlertPresent() throws Exception {
		boolean result = true;

		try {
			final WebDriverWait myCustWait = new WebDriverWait(driver, LOOP_TIMEOUT);
			try {
				myCustWait.until(ExpectedConditions.not(ExpectedConditions.alertIsPresent()));
				result = false;
			} catch (Exception exception) {
				System.out.println("Checking for Alert box...");
				myCustWait.until(ExpectedConditions.alertIsPresent());
				String alertText = driver.switchTo().alert().getText();
				Report.fnReportWarning(alertText, driver);
				if(alertText.matches("(?s)Are you sure you want to(.*)")){
					driver.switchTo().alert().accept();
					result = true;
				} else {
					System.out.println("Alert box is found");
					driver.switchTo().alert().accept();
					myCustWait.until(ExpectedConditions.not(ExpectedConditions.alertIsPresent()));
					result = true;
				}
			}
		} catch (NoAlertPresentException exceptionx) {
			System.out.println("catchNoAlert");
			result = false;
		} // catch
		return result;
	}

	public void VerifyElementPresentAndType(String element, String elementname, String content) {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {

				Report.ReporterLog(element+"---"+elementname + " link is not found", LogStatus.FAIL);

				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname,driver);
			}
			try {

				waitUntilElementClickable(element);

				By byElement = getElementFromLoc(element);
				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
					// selenium.type(xpath, content);
					driver.findElement(byElement).clear();
					driver.findElement(byElement).sendKeys(content);

					Report.fnReportPass(elementname + " text box is found and " + content + " is entered");
					break;
				}
				Thread.sleep(1000);
			} catch (Exception exception) {
			}
		}
	}

	public void VerifyElementPresentAndClearType(String element, String elementname, String content) {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {

				Report.ReporterLog(elementname + " link is not found", LogStatus.FAIL);

				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname,driver);
			}
			try {
				By byElement = getElementFromLoc(element);
				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
					// selenium.type(xpath, content);
					driver.findElement(byElement).clear();
					driver.findElement(byElement).sendKeys(content);
					Report.fnReportPass(elementname + " text box is found and " + content + " is entered");

					break;
				}
			} catch (Exception exception) {
			}
		}
	}

	public void VerifyElementPresentIsChecked(String element, String elementname) throws Exception {
		// for (int second = 0;; second++) {
		while (true) {
			// if (second >=
			// Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER")))
			// {
			//
			// Report.ReporterLog(elementname + " check box is not found",
			// "Fail", Report.rownumber);
			//
			// ExceptionHandlers.FinalExceptionHandler(Report, new
			// Object(){}.getClass().getEnclosingMethod().getName(),elementname);
			// }
			try {
				By byElement = getElementFromLoc(element);
				WebElement checkBox = driver.findElement(byElement);
				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
					if (checkBox.isSelected()) {
						WebElement WE = driver.findElement(byElement);
						Thread.sleep(200);
						// selenium.click(xpath);
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", WE);
					}

					break;
				}
			} catch (Exception exception) {

			}
			// Thread.sleep(1000);
		}
	}

	/**
	 * 
	 * DEPRICATED METHOD
	 * 
	 * @param element
	 * @param elementname
	 * @param content
	 */
	// public void VerifyElementPresentAndJType(String element,
	// String elementname, String content) throws Exception {
	// for (int second = 0;; second++) {
	// if (second >=
	// Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER")))
	// {
	//
	// Report.ReporterLog(elementname + " link is not found", LogStatus.FAIL
	// );
	//
	// ExceptionHandlers.FinalExceptionHandler(Report, new
	// Object(){}.getClass().getEnclosingMethod().getName(),elementname);
	// }
	// try {
	// By byElement = getElementFromLoc(element);
	// if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
	// selenium.type(element, content);
	// Report.fnReportPass(elementname + " text box is found and "+ content + "
	// is entered");
	//
	// break;
	// }
	// } catch (Exception exception) {
	// }}}

	public void VerifyElementPresentAndSelect(String element, String elementname, String content) {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
				Report.ReporterLog(elementname + " drop down is not found", LogStatus.FAIL);
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);
			}
			try {
				By byElement = getElementFromLoc(element);
				WebElement WE = driver.findElement(byElement);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", WE);
				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
					WebElement selectElm = driver.findElement(byElement);
					Select select = new Select(selectElm);
					select.selectByVisibleText(content);
					Report.fnReportPass(elementname + " text box is found and " + content + " is entered");

					break;
				}
			} catch (Exception exception) {
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), exception.getMessage());
			}
		}
	}

	public void VerifyElementPresentAndSelect(String element, String elementname, int Option) {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {

				Report.ReporterLog(elementname + " drop down is not found", LogStatus.FAIL);

				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);
			}
			try {
				By byElement = getElementFromLoc(element);
				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
					WebElement selectElm = driver.findElement(byElement);
					Select select = new Select(selectElm);
					select.selectByIndex(Option);
					Thread.sleep(10000);
					String SelectedValue = select.getFirstSelectedOption().getText();
					Report.fnReportPass(elementname + " drop down is found and " + SelectedValue + " is entered");
					break;
				}
			} catch (Exception exception) {
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), exception.getMessage());
			}
		}
	}

	public List<WebElement> VerifyElementPresentAndGetElementList(String element) {
		try {
			By byElement = getElementFromLoc(element);
			List<WebElement> ElementList = driver.findElements(byElement);

			return ElementList;
		} catch (Exception exception) {
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage());
		}
		return null;
	}
	public String VerifyElementPresentAndGetText(String element,
			String elementname,boolean... Continue) {
		String returnText="";
		if(waitForElementToAppear(element, LOOP_TIMEOUT)){
			List<WebElement> we=driver.findElements(getElementFromLoc(element));
			returnText=we.get(0).getText();
			Report.fnReportPass("Element "+elementname+" is found and the Text is "+returnText, driver);
		}else{
			if(Continue.length>0&& Continue[0]){
				Report.fnReportFail("Element "+elementname+" is not found", driver);
				return "";
			}else{
				Report.fnReportFailAndTerminateTest("Element "+elementname+" is not found", "Element "+elementname+" is not found", driver);
			}

		}
		return returnText.replaceAll("^,", "").replaceAll("^Â", "");
	}

	public String VerifyElementPresentAndGetSingleTextUsingJS(String element, String elementname) {
		String returnText = "";

		for (int StaleCount = 1; StaleCount < 4; StaleCount++) {
			try {
				By byElement = getElementFromLoc(element);
				WebElement WE = driver.findElement(byElement);
				// if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {

				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", WE);
				String text = driver.findElement(byElement).getText();
				return text.trim();
				// }
			} catch (Exception exception) {
				if (StaleCount == 3) {
					return "NA";
				} else {
					continue;
				}
			}
		}
		return returnText.replaceAll("^,", "");
	}

	public String VerifyElementPresentAndGetTextByJS(String element, String elementName) {
		for (int StaleCount = 1; StaleCount < 4; StaleCount++) {
			try {
				By byElement = getElementFromLoc(element);
				// if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				WebElement webElement = driver.findElement(byElement);

				// js.executeScript("return arguments[0].text", webElement);
				// String sText = js.executeScript("return
				// document.documentElement.innerText;").toString();
				String text = js.executeScript("return arguments[0].value;", webElement).toString();
				return text.trim();
				// }
			} catch (Exception exception) {
				if (StaleCount == 3) {
					return "";
				} else {
					continue;
				}
			}
		}
		return null;
	}

	public String VerifyElementPresentAndGetTextForSelect(String element, String elementname) throws Exception {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {

				Report.ReporterLog(elementname + "is not found", LogStatus.FAIL);

				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);
			}
			for (int StaleCount = 1; StaleCount < 4; StaleCount++) {
				try {
					By byElement = getElementFromLoc(element);
					if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
						// String text = selenium.getText(xpath);
						String text = driver.findElement(byElement).getText();
						return text;
					}
				} catch (Exception exception) {
					if (StaleCount == 3) {
						return "";
					} else {
						continue;
					}
				}
			}
		}
	}

	public String VerifyElementPresentAndGetAttribute(String element, String Attribute) throws Exception {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
				Report.ReporterLog(Attribute + "is not found", LogStatus.FAIL);
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), element);
			}
			try {
				By byElement = getElementFromLoc(element);
				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
					String text = null;
					try {
						text = driver.findElement(byElement).getAttribute(Attribute);
					} catch (Exception exception) {
						Report.fnReportFailAndTerminateTest("Attribute not found",
								"Attribute " + Attribute + " is not found", driver);
					}
					//
					return text.trim();
				}
			} catch (Exception exception) {
				return "";
			}
		}
	}

	public String VerifyElementPresentAndGetAttributeWithoutException(String element, String Attribute)
			throws Exception {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
				Report.ReporterLog(Attribute + "is not found", LogStatus.FAIL);
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), element);
			}
			try {
				By byElement = getElementFromLoc(element);
				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
					String text = null;
					try {
						text = driver.findElement(byElement).getAttribute(Attribute);
					} catch (Exception e) {
						return "NA";
					}
					//
					return text.trim();
				}
			} catch (Exception e) {
				return "NA";
			}
			// Thread.sleep(100);
		}

	}

	public String VerifyElementPresentAndGetAttributeUsingJS(String element, String Attribute) throws Exception {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
				Report.ReporterLog(Attribute + " is not found", LogStatus.FAIL);
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), element);
			}
			try {
				By byElement = getElementFromLoc(element);
				WebElement elementId = driver.findElement(byElement);
				JavascriptExecutor js = (JavascriptExecutor) driver;
				String checkedState = js
						.executeScript("return arguments[0].getAttribute('" + Attribute + "');", elementId).toString();
				System.out.println("checkedState : " + checkedState);
				return checkedState.trim();

			} catch (Exception exception) {
				// return "";
			}
		}
	}

	/**
	 * DEPRICATED METHOD
	 * 
	 * @param element
	 * @param elementname
	 * @return
	 * @throws Exception
	 */
	//	public String VerifyElementPresentAndGetValue(String element, String elementname) throws Exception {
	//		for (int second = 0;; second++) {
	//			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
	//				Report.ReporterLog(elementname + "is not found", LogStatus.FAIL);
	//
	//				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
	//				}.getClass().getEnclosingMethod().getName(), elementname);
	//			}
	//			try {
	//				By byElement = getElementFromLoc(element);
	//				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
	//					String text = selenium.getValue(element);
	//					return text;
	//				}
	//			} catch (Exception exception) {
	//				return "";
	//			}
	//			// Thread.sleep(1000);
	//		}
	//	}

	public String VerifyElementPresentAndGetclass(String element, String elementname) throws Exception {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {

				Report.ReporterLog(elementname + "is not found", LogStatus.FAIL);

				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);
			}
			try {
				By byElement = getElementFromLoc(element);
				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
					// String text = selenium.getValue(xpath);
					String text = driver.findElement(byElement).getAttribute("class");

					return text;
				}
			} catch (Exception exception) {
				return "";
			}
			// Thread.sleep(1000);
		}
	}

	/*
	 * Method Name: MouseOver Description: This method is used to mouse over the
	 * element for a few seconds. xpath of the required element is passed for
	 * mouse over
	 */
	public void MouseOver(String element) throws Exception {
		Actions builder = new Actions(driver);
		try {
			By byElement = getElementFromLoc(element);
			System.out.println("before mousehover");
			WebElement tagElement = driver.findElement(byElement);
			builder.moveToElement(tagElement).build().perform();
			Thread.sleep(1000);
			System.out.println("after mousehover");
		} catch (Exception exception) {
			Report.fnReportFailAndTerminateTest(element, "Exception while mouse hover : " + element, driver);
		}
	}

	// //Gets the text of the selected option from the dropdown
	public String GetTheSelectedOption(By element) {
		try {
			WebElement webElement = waitForElement(element, LOOP_TIMEOUT);
			Select select = new Select(webElement);
			String text = select.getFirstSelectedOption().getText();
			return text;
		} catch (Exception exception) {
			return "";
		}
	}

	public int GetElementSizeByXpath(String element) {
		try {

			By byElement = getElementFromLoc(element);
			if (waitForElementToAppear(byElement, LARGE_TIMEOUT)) {
				List<WebElement> allAddresses = driver.findElements(byElement);
				return allAddresses.size();
			} else {
				System.out.println("No Such Element to fetch the list");
			}
		} catch (NullPointerException npe) {

		} catch (Exception exception) {

		}
		return 0;
	}

	public boolean VerifyElementPresentAndGetCheckBoxStatus(String element, String elementname) throws Exception {
		try {
			By byElement = getElementFromLoc(element);
			if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
				WebElement checkBox = driver.findElement(byElement);
				return checkBox.isSelected();
			} else {
				Report.ReporterLog(elementname + " link is not found", LogStatus.FAIL, driver);

				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);
			}
		} catch (Exception exception) {
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), elementname);
		}
		return false;
	}

	public void VerifyElementPresentAndClickFirst(String element, String elementname) {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {

				Report.ReporterLog(elementname + " is not found", LogStatus.FAIL, driver);

				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);
			}
			try {
				By byElement = getElementFromLoc(element);
				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
					Thread.sleep(200);
					// selenium.click(xpath);
					// WebElement WE=driver.findElement(byElement);
					List<WebElement> WE = driver.findElements(byElement);
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", WE.get(0));
					((JavascriptExecutor) driver)
					.executeScript("javascript:window.scrollTo(" + WE.get(0).getLocation().getX() + ","
							+ (WE.get(0).getLocation().getY() - Report.EXECUTION_OFFSET) + ");");
					// highlightElement(driver.findElement(byElement));
					// unhighlightElement(driver.findElement(byElement));
					WE.get(0).click();
					Report.fnReportPass(elementname + " is found and Clicked");
					break;
				}
			} catch (Exception exception) {
				/*System.out.println("-----------------------------------------------------------------------");
				System.out.println(exception.getLocalizedMessage());
				System.out.println("-----------------------------------------------------------------------");

				Report.ReporterLog(elementname + " link is not found", LogStatus.FAIL);

				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);*/

			}
			// Thread.sleep(1000);
		}
	}

	// -- Function which waits for the presence of the web element and clicks
	public void VerifyElementPresentAndClick(String element, String elementname) {
		System.out.println("element "+element);
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname + " button is not found", driver);
			}
			try {

				By byElement = getElementFromLoc(element);
				WebElement WE = driver.findElement(byElement);
				// (JavascriptExecutor) driver).executeScript("window.scrollTo("
				// + WE.getLocation().getX() + ","+
				// (WE.getLocation().getY()-Report.EXECUTION_OFFSET) + ");");
				System.out.println("EXECUTION_OFFSET is " + Report.EXECUTION_OFFSET);

				((JavascriptExecutor)
						driver).executeScript("arguments[0].scrollIntoView(true);",WE);
				((JavascriptExecutor) driver).executeScript("javascript:window.scrollTo(" + WE.getLocation().getX()
						+ "," + (WE.getLocation().getY() - Report.EXECUTION_OFFSET) + ");");

				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
					Thread.sleep(1000);
					// selenium.click(xpath);
					// WebElement WE=driver.findElement(byElement);
					while (!WE.isDisplayed()) {
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", WE);
					}
					// highlightElement(driver.findElement(byElement));
					// unhighlightElement(driver.findElement(byElement));
					try {
						driver.findElement(byElement).click();
					} catch (WebDriverException exception) {
						// Actions Ac=new Actions(driver);
						// Ac.moveToElement(WE,0,-100);
						System.out.println(exception.getMessage());
						if (exception.getMessage().contains("Element is not clickable")) {
							WE.sendKeys("");
						}
						// Ac.click().perform();
					}
					Report.fnReportPass(elementname + " is found and Clicked");
					break;
				}
			} catch (Exception exception) {
				//				exception.printStackTrace();
				/**
				 * Commented the below Lines as the loop should continue until
				 * Loop exceeds LOOP_COUNTER
				 **/
				// ExceptionHandlers.FinalExceptionHandler(Report, new
				// Object(){}.getClass().getEnclosingMethod().getName(),exception.getMessage(),driver);
				// System.out
				// .println("-----------------------------------------------------------------------");
				// System.out.println(exception.getLocalizedMessage());
				// System.out
				// .println("-----------------------------------------------------------------------");
				//
				//
				// Report.ReporterLog(elementname + " link is not found",
				// LogStatus.FAIL,driver);
				//
				// ExceptionHandlers.FinalExceptionHandler(Report, new
				// Object(){}.getClass().getEnclosingMethod().getName(),elementname,driver);

			}
			// Thread.sleep(1000);
		}
	}






	public void VerifyElementPresentAndClick_JavaScript(String element, String elementname) {
		System.out.println("element "+element);
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname + " button is not found", driver);
			}
			try {
				By byElement = getElementFromLoc(element);
				WebElement WE = driver.findElement(byElement);
				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
					try {

						JavascriptExecutor executor = (JavascriptExecutor)driver;
						executor.executeScript("arguments[0].click();", WE);


					} catch (WebDriverException exception) {
						System.out.println(exception.getMessage());
						if (exception.getMessage().contains("Element is not clickable")) {
							WE.sendKeys("");
						}
					}
					Report.fnReportPass(elementname + " is found and Clicked");
					break;
				}
			} catch (Exception exception) {
			}
		}
	}
	public void VerifyElementPresentAndClickAppointment(String element, String elementname) {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
				Report.ReporterLog(elementname + " is not found", LogStatus.FAIL, driver);
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname, driver);
			}
			try {

				By byElement = getElementFromLoc(element);
				WebElement WE = driver.findElement(byElement);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", WE);
				if (waitForElementToAppear(byElement, 1)) {
					Thread.sleep(200);
					while (!WE.isDisplayed()) {
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", WE);
					}
					try {
						driver.findElement(byElement).click();
					} catch (WebDriverException e) {
						if (e.getMessage().contains("Element is not clickable")) {
							WE.sendKeys("");
						}
					}
					Report.fnReportPass(elementname + " is found and Clicked");
					break;
				}
			} catch (Exception e) {
				// System.out.println(e.getLocalizedMessage());
				// Report.ReporterLog(elementname + " link is not found",
				// LogStatus.FAIL,driver);
				// ExceptionHandlers.FinalExceptionHandler(Report, new
				// Object(){}.getClass().getEnclosingMethod().getName(),elementname,driver);
			}
		}
	}

	public boolean VerifyElementPresentAndSelectFromDropDown(String element, String elementValue) throws Exception {
		By byElement = getElementFromLoc(element);
		// if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
		WebElement selectElement = driver.findElement(byElement);
		Select select = new Select(selectElement);

		List<WebElement> allOptions = select.getOptions();

		for (WebElement ele : allOptions) {
			String mainString = ele.getText();
			if (mainString.equalsIgnoreCase(elementValue)) {
				// select.selectByVisibleText(mainString);
				select.selectByValue(mainString);
				Report.fnReportPass(elementValue + " is found and selected");
				return true;
			} else {
				continue;
			}
		}
		// }
		return false;
	}

	// -- Function which waits for the presence of the web element and hover on
	// element
	public void VerifyElementPresentAndHover(String element, String elementname) throws Exception {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {

				Report.ReporterLog(elementname + " link is not found", LogStatus.FAIL);

				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);
			}
			try {
				By byElement = getElementFromLoc(element);
				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {

					Report.ReporterLog(elementname + " is found", LogStatus.PASS);
					Thread.sleep(200);
					// selenium.click(xpath);
					Actions action = new Actions(driver);
					WebElement we = driver.findElement(byElement);
					action.moveToElement(we).perform();
					Report.ReporterLog("Hovered over " + elementname, LogStatus.PASS);
					break;
				}
			} catch (Exception exception) {
				System.out.println("-----------------------------------------------------------------------");
				System.out.println(exception.getLocalizedMessage());
				System.out.println("-----------------------------------------------------------------------");

				Report.ReporterLog(elementname + " link is not found", LogStatus.FAIL);

				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);

			}
			// Thread.sleep(1000);
		}
	}

	// -- function to check the option box
	public void VerifyElementPresentAndClickOption(String element, String elementname) throws Exception {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {

				Report.ReporterLog(elementname + " check box is not found", LogStatus.FAIL);

				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);
			}
			try {
				By byElement = getElementFromLoc(element);
				WebElement checkBox = driver.findElement(byElement);
				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
					int i = 0;
					while (!checkBox.isSelected()) {
						checkBox.click();
						i = i + 1;
						if (i == 5) {
							break;
						}
					}
					if (!checkBox.isSelected()) {
						Report.ReporterLog("Failed to set the check box " + elementname, LogStatus.FAIL);

						ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
						}.getClass().getEnclosingMethod().getName(), elementname);
					} else {

						Report.ReporterLog(elementname + " option box is found clicked ", LogStatus.PASS);
						break;
					}
				}
			} catch (Exception exception) {
				Report.ReporterLog("Failed to set the check box " + elementname, LogStatus.FAIL);

				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);
			}
			// Thread.sleep(1000);
		}
	}

	// -- function to get all elements
	public List<WebElement> VerifyElementPresentAndGetElements(String element, String elementname) throws Exception {
		List<WebElement> elementsList = new ArrayList<WebElement>();
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {

				Report.ReporterLog(elementname + "is not found", LogStatus.FAIL);

				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);
			}
			try {
				By byElement = getElementFromLoc(element);
				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
					elementsList = driver.findElements(byElement);

					Report.ReporterLog(elementname + " is found", LogStatus.PASS);
					return elementsList;
				}
			} catch (Exception exception) {
				return null;
			}
			// Thread.sleep(1000);
		}
	}

	// -- function to check/uncheck the check box
	public void VerifyElementPresentAndCheck(String element, String elementname, boolean setCheck) {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {

				Report.ReporterLog(elementname + " check box is not found", LogStatus.FAIL);

				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);
			}
			try {
				By byElement = getElementFromLoc(element);
				WebElement checkBox = driver.findElement(byElement);
				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
					if (setCheck && !checkBox.isSelected()) {
						checkBox.click();
					} else if (!setCheck && checkBox.isSelected()) {
						checkBox.click();
					}
					Report.ReporterLog(elementname + " check box is found and set to " + setCheck, LogStatus.PASS);
					break;
				}
			} catch (Exception exception) {
				Report.ReporterLog("Failed to set the check box " + elementname, LogStatus.FAIL);

				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);
			}
			// Thread.sleep(1000);
		}
	}

	public boolean VerifyElementDisabled(String element, String elementname) throws Exception {
		try {
			if (VerifyElementPresent(element, elementname)) {
				if (driver.findElement(getElementFromLoc(element)).isEnabled()) {
					Report.ReporterLog(elementname + " is Enabled", LogStatus.FAIL);
					ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
					}.getClass().getEnclosingMethod().getName(), elementname);
				} else {
					Report.ReporterLog(elementname + " is Disabled", LogStatus.PASS);

				}
				return true;
			}
		} catch (Exception exception) {
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage());
		}
		return false;
	}

	public int getElementCount(String element, String elementname) throws Exception {
		int count = 0;
		try {
			By byElement = getElementFromLoc(element);
			driver.findElements(byElement);
			if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
				List<WebElement> WE = driver.findElements(byElement);
				count = WE.size();
			}
		} catch (Exception exception) {
			Report.ReporterLog(elementname + " is not found", LogStatus.FAIL, driver);

			Report.TESTPASSED = false;
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), elementname);
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage());
		}
		return count;
	}

	// -- Function which waits for the presence of the web element
	public boolean VerifyElementPresent(String element, String elementname, boolean... termainate) throws Exception {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
				Report.TESTPASSED = false;
				Report.ReporterLog(elementname + " is not found", LogStatus.FAIL, driver);
				if (termainate.length > 0 && termainate[0]) {
					ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
					}.getClass().getEnclosingMethod().getName(), elementname);
				}
				break;
			}
			try {
				By byElement = getElementFromLoc(element);
				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {

					highlightElement(driver.findElement(byElement));
					Report.fnReportPass("ELEMENT FOUND " + element, driver);
					unhighlightElement(driver.findElement(byElement));
					break;
				}
			} catch (Exception exception) {
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), exception.getMessage());
			}

		}
		return false;
	}

	public boolean VerifyElementPresentByJavaScriptExecuor(String element, String elementname) throws Exception {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
				Report.ReporterLog(elementname + " is not found", LogStatus.FAIL);
				Report.TESTPASSED = false;
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);
				break;
			}
			try {
				if (second == 0) {
					By byElement = getElementFromLoc(element);
					WebElement testelement = driver.findElement(byElement);
					JavascriptExecutor js = (JavascriptExecutor) driver;
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", testelement);
					if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
						js.executeScript("arguments[0].click();", testelement);
					}
				}
			} catch (Exception exception) {
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), exception.getMessage());
			}
		}
		return false;
	}

	public boolean VerifyElementPresentByJavaScriptExecuorWithoutREPORT(String element, String elementname)
			throws Exception {

		try {

			By byElement = getElementFromLoc(element);
			WebElement testelement = driver.findElement(byElement);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", testelement);
			if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
				js.executeScript("arguments[0].click();", testelement);
			}
		} catch (Exception exception) {
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage());
		}
		Thread.sleep(1000);

		return false;
	}

	public boolean VerifyElementSelected(String element, String elementname) throws Exception {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
				Report.ReporterLog(elementname + " is not found", LogStatus.FAIL);
				Report.TESTPASSED = false;
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);
				break;
			}
			try {
				if (second == 0) {
					By byElement = getElementFromLoc(element);
					WebElement testelement = driver.findElement(byElement);
					JavascriptExecutor js = (JavascriptExecutor) driver;
					String scrollHeight = js.executeScript("return document.body.scrollHeight", testelement).toString();
					for (int scrollCount = 0; scrollCount < Integer.parseInt(scrollHeight); scrollCount++) {
						String scrollJS = "window.scrollBy(0," + Integer.toString(scrollCount) + ")";
						js.executeScript(scrollJS, testelement);
						if (testelement.isEnabled() && !testelement.isSelected()) {
							js.executeScript("arguments[0].click();", testelement);

							Thread.sleep(500);
							break;
						}
					}
				}
			} catch (Exception exception) {
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), exception.getMessage());
			}
			Thread.sleep(1000);
		}
		return false;
	}

	public boolean VerifyElementPresentScrollByExecutor(String element, String elementname) throws Exception {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
				Report.ReporterLog(elementname + " is not found", LogStatus.FAIL);
				Report.TESTPASSED = false;
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);
				break;
			}
			try {
				By byElement = getElementFromLoc(element);
				WebElement testelement = driver.findElement(byElement);

				JavascriptExecutor js = (JavascriptExecutor) driver;
				// String height = js.executeScript("return
				// document.body.scrollHeight", testelement).toString();

				js.executeScript("window.scrollBy(0,100)", testelement);// document.body.scrollHeight
			} catch (Exception exception) {
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), exception.getMessage());
			}
			Thread.sleep(1000);
		}
		return false;
	}

	public boolean VerifyElementPresent(String element, String elementname, boolean Terminate) throws Exception {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
				Report.ReporterLog(elementname + " is not found", LogStatus.FAIL);

				if (Terminate) {
					ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
					}.getClass().getEnclosingMethod().getName(), elementname);
				}
			}
			try {
				By byElement = getElementFromLoc(element);
				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
					Report.ReporterLog(elementname + " is found==", LogStatus.PASS);
					break;
				}
			} catch (Exception exception) {
			}
			Thread.sleep(1000);
		}
		return true;
	}

	public boolean VerifyElementRefreshed(String element, String elementname) throws Exception {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
				Report.ReporterLog(elementname + " is not found", LogStatus.FAIL);
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);
			}
			try {
				By byElement = getElementFromLoc(element);
				if (waitForTableRefresh(byElement, LOOP_TIMEOUT)) {

					Report.ReporterLog(elementname + " is found", LogStatus.PASS);

					break;
				}
			} catch (Exception exception) {
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), exception.getMessage());
			}

		}
		return false;
	}

	// -- Function which waits for the Absence of the web element
	public boolean VerifyElementNotPresent(String element, String elementname) throws Exception {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
				Report.ReporterLog(elementname + " link is not found", LogStatus.PASS);
				break;
			}
			try {
				By byElement = getElementFromLoc(element);
				if (waitForElementToAppear(byElement, LOW_LOOP_TIMEOUT)) {
					Report.ReporterLog(elementname + " is found", LogStatus.FAIL);
					ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
					}.getClass().getEnclosingMethod().getName(), elementname);
				}
			} catch (Exception exception) {
			}
			Thread.sleep(1000);
		}
		return false;
	}

	// -- Function which waits for the presence of the web element and verifies
	// the presence of text
	public String VerifyElementAndTextPresent(String element, String elementname) throws Exception {
		String Str_verifyText = "";
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {

				Report.ReporterLog(elementname + " link is not found , Instead found:" + Str_verifyText,
						LogStatus.FAIL);

				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), elementname);
			}
			try {
				By byElement = getElementFromLoc(element);
				if (waitForElementToAppear(byElement, LOOP_TIMEOUT)) {
					Str_verifyText = driver.findElement(byElement).getText()
							.trim();
					if (Str_verifyText.toLowerCase().contains(elementname.toLowerCase())||elementname.toLowerCase().contains(Str_verifyText.toLowerCase())) {
						Report.ReporterLog(elementname + " is found", LogStatus.PASS);
						break;
					}
				}
			} catch (Exception exception) {
				exception.printStackTrace();
			}
			// Thread.sleep(1000);
		}
		return Str_verifyText;
	}

	public void waitTillAjaxbyJqueryIsComplete() {
		while (true) // Handle LOOP_TIMEOUT somewhere
		{
			System.out.println(((JavascriptExecutor) driver).executeScript("return jQuery.active == 0"));
			boolean ajaxIsComplete;
			ajaxIsComplete = (Boolean) (((JavascriptExecutor) driver).executeScript("return jQuery.active == 0"));
			if (ajaxIsComplete)
				break;
		}

	}

	// Function to wait till the title is available
	public void fnWaitTillTitle(String strTitle) throws Exception {
		try {
			WebDriverWait myCustWait = new WebDriverWait(driver, LOOP_TIMEOUT);
			myCustWait.until(ExpectedConditions.titleIs(strTitle));
			Report.fnReportPass(strTitle, driver);
		} catch (Exception exception) {
			Report.fnReportFailAndTerminateTest(strTitle, "Waiting for Page title for too long", driver);
		}
	}

	//	public void VerifyElementPresentAndJType(String element, String elementname, String content) throws Exception {
	//		for (int second = 0;; second++) {
	//			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
	//
	//				Report.ReporterLog(elementname + " link is not found , Instead found:" + element, LogStatus.FAIL);
	//
	//				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
	//				}.getClass().getEnclosingMethod().getName(), elementname);
	//			}
	//			try {
	//				By byElement = getElementFromLoc(element);
	//				if (waitForElementToAppear(byElement,
	//						Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_TIMEOUT")))) {
	//					selenium.type(element, content);
	//					Report.fnReportPass(elementname + " text box is found and " + content + " is entered");
	//
	//					break;
	//				}
	//			} catch (Exception e) {
	//			}
	//		}
	//	}

	public boolean highlightElement(WebElement elem) {

		try {
			JavascriptExecutor js = (JavascriptExecutor) this.driver;

			js.executeScript(
					"arguments[0].style.outlineStyle='solid';arguments[0].style.outlineWidth='5px';arguments[0].style.outlineColor='yellow';",
					new Object[] { elem });
			return true;
		} catch (Exception exception) {
			return false;
		}

	}

	public boolean VerifyElementPresentAndGetCheckBoxEnableDisableStatus(String element, String elementname)
			throws Exception {
		for (int second = 0;; second++) {
			if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {

			}
			try {
				By byElement = getElementFromLoc(element);
				WebElement checkBox = driver.findElement(byElement);
				if (waitForElementToAppear(byElement,
						Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_TIMEOUT")))) {
					if (checkBox.isDisplayed()) {
						return checkBox.isEnabled();
					} else {
						return checkBox.isEnabled();
					}
				}
			} catch (Exception exception) {
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), exception.getMessage());
			}
		}
	}

	public boolean unhighlightElement(WebElement elem) {

		try {
			JavascriptExecutor js = (JavascriptExecutor) this.driver;

			js.executeScript("arguments[0].style.outlineStyle='none';", new Object[] { elem });
			return true;
		} catch (Exception exception) {
			return false;
		}
	}

	public void openNewTab()

	{
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "t");
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(0));

	}

	public void donotLoad()

	{
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.ESCAPE);
	}

	public void openfirstNewTab()

	{
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "1");
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(0));

	}

	public boolean VerifyElementEnabled(String element, String elementname) throws Exception {

		boolean Element = true;
		try {
			if (VerifyElementPresent(element, elementname)) {
				if (driver.findElement(getElementFromLoc(element)).isEnabled()) {
					Report.ReporterLog(elementname + " is found", LogStatus.PASS);

					System.out.println("Element Enabled");
					Element = true;
					System.out.println(Element);

				} else {
					Report.ReporterLog(elementname + " link is not found , Instead found:" + element, LogStatus.FAIL);

					System.out.println("Element Disabled");
					Element = false;
				}
			}
		} catch (Exception e) {
		}
		Thread.sleep(1000);
		return Element;
	}

	public WebElement VerifyElementPresentAndGetElement(String element) {
		By byElement = getElementFromLoc(element);
		WebElement W = driver.findElement(byElement);
		return W;
	}

	public void waitUntilElementClickable(String locator) {
		try {

			waitForElementToAppear(locator, LARGE_TIMEOUT);
			final WebDriverWait myCustWait = new WebDriverWait(driver, LARGE_TIMEOUT);
			waitForElementToAppear(locator, LARGE_TIMEOUT);
			myCustWait.until(ExpectedConditions.elementToBeClickable( getElementFromLoc(locator)));
			Report.fnReportInfo("Locator: "+locator +" is clickable");
		}catch(Exception exception) {
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage(),driver);
		}
	}




	/**
	 * GET SRF FUNCTION 
	 */

	public String getSRFDetails(WebDriver TDriver,String Appletname) {
		String element = "";
		try {
			element = (String) ((JavascriptExecutor) TDriver)
					.executeScript(
							"var View = SiebelApp.S_App.GetActiveView();"
									+"var Applet = View.GetApplet('"+Appletname+"');"
									+"var Controls = Applet.GetControls();"
									+"var CtrlList= {};"
									+"for(c in Controls){"
									+"CtrlList[c]=Controls[c].GetInputName();"
									+"}"
									+"return JSON.stringify(CtrlList);");

			//System.out.println(element);
			//			element.replaceAll("{","");
			//			element.replaceAll("}","");
			System.out.println("Appletname = "+Appletname+"  VALUES =="+element);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return element;
	}

	private static String getSpecPath(String directoryName,String FileName) {
		File directory = new File(directoryName);
		String FilePath="";
		// Get all the files from a directory.
		File[] fList = directory.listFiles();
		for (File file : fList) {
			if (file.isFile()) {
				if(file.getName().equalsIgnoreCase(FileName)) {
					System.out.println("SPEC FILE PATH === "+file.getAbsolutePath());
					FilePath=file.getAbsolutePath();
					break;
				}
			} else if (file.isDirectory()) {
				getSpecPath(file.getAbsolutePath(),FileName);
			}
		}
		return FilePath;
	}
}
