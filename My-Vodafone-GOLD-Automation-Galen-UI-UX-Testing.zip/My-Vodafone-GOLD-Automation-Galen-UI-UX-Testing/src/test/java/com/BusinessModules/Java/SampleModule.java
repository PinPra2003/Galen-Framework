package com.BusinessModules.Java;

import org.openqa.selenium.WebDriver;

import com.Engine.ExceptionHandlers;
import com.Engine.Reporter;
import com.Enumerations.Generic.DesktopTabletMobile;
import com.WebActions.WebActions;
import com.WebObjectRepository.ObjectRepo;

public class SampleModule extends WebActions implements ObjectRepo {
	public WebDriver driver;
	public Reporter Report;
	public DesktopTabletMobile Mode = null;

	public SampleModule(WebDriver Driver, Reporter report, DesktopTabletMobile mode) {
		super(Driver, report);
		driver = Driver;
		Report = report;
		Mode = mode;
	}

	/************************************************************************************************
	 * Navigation Functions *
	 ***********************************************************************************************/

	public void SampleFunction() throws Exception {
		try {
			driver.get("https://www.google.com.au");
			switch (Mode) {

			case DESKTOP:
				Report.fnReportPageBreak("CASE RUNNING IN DESKTOP MODE", driver);
				break;
			case MOBILE:
				Report.fnReportPageBreak("CASE RUNNING IN MOBILE MODE", driver);
				break;
			case TABLET:
				Report.fnReportPageBreak("CASE RUNNING IN TABLET MODE", driver);
				break;
			default:
				break;			

			}
		} catch (Exception e) {
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), e.getMessage());
		}
	}

	public void Navigate_To_URL(String URL) throws Exception {
		switch (Mode) {

		case DESKTOP:
			driver.get(URL);
			
			if(isAlertPresent()) {
				driver.switchTo().alert();
				Thread.sleep(10000);
			}
			Report.fnReportPageBreak("Navigated to URL -> "+URL, driver);
			break;
		case MOBILE:

			break;
		case TABLET:

			break;
		default:
			break;			

		}

	}

	public void Click_Projects_Tab() {
		switch (Mode) {

		case DESKTOP:
			VerifyElementPresentAndClick(DESKTOP_XPATH_Projects_Tab, "Projects TAB");
			Report.fnReportPageBreak("Projects Tab Clicked", driver);
			break;
		case MOBILE:

			break;
		case TABLET:

			break;
		default:
			break;			

		}

	}

	public void Click_Download_Tab() {
		switch (Mode) {

		case DESKTOP:
			VerifyElementPresentAndClick(DESKTOP_XPATH_Download_Tab, "Downloads TAB");
			Report.fnReportPageBreak("Download Tab Clicked", driver);
			break;
		case MOBILE:

			break;
		case TABLET:

			break;
		default:
			break;			

		}

	}

	public void Search(String content) {
		switch (Mode) {

		case DESKTOP:
			VerifyElementPresentAndType(DESKTOP_XPATH_Searchbox, "SEARCH BOX", content);
			Report.fnReportPageBreak("Search Box Typed", driver);
			break;
		case MOBILE:

			break;
		case TABLET:

			break;
		default:
			break;			

		}

	}

	public void Click_Documentation_Tab() {
		switch (Mode) {

		case DESKTOP:
			VerifyElementPresentAndClick(DESKTOP_XPATH_Documentation_Tab, "Documentation TAB");
			Report.fnReportPageBreak("Documentation clicked", driver);
			break;
		case MOBILE:

			break;
		case TABLET:

			break;
		default:
			break;			

		}

	}

	public void ClickGoButton() {
		switch (Mode) {

		case DESKTOP:
			VerifyElementPresentAndClick(DESKTOP_XPATH_Searchbox_Submit, "Submit Button");
			Report.fnReportPageBreak("Go Button Clicked", driver);
			
			Report.fnReportPageBreak("AFTER GO BUTTON SEARCH RESULTS PAGE", driver);
			break;
		case MOBILE:

			break;
		case TABLET:

			break;
		default:
			break;			

		}

	}


}