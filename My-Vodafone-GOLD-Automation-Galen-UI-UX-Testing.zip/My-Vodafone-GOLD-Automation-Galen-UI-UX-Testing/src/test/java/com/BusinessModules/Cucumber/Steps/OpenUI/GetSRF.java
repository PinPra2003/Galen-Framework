package com.BusinessModules.Cucumber.Steps.OpenUI;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import com.BusinessModules.Cucumber.Commons.BaseClass;
import com.Engine.LoadEnvironment;
import com.Engine.Reporter;
import com.SharedModules.Constants;
import com.Utils.WriteExcel;
import com.WebActions.WebActions;
import com.WebObjectRepository.ObjectRepo_OpenUI_SRF;

public class GetSRF implements ObjectRepo_OpenUI_SRF,Constants{
	//BaseClass baseClass;
	WebDriver driver;
	Reporter Report;

	Map<String, String> DATA_MAP;
	WebActions WA;

	public GetSRF(BaseClass Bclass) {
		//baseClass= Bclass;
		driver=Bclass.driver;Report = Bclass.Report;DATA_MAP=Bclass.DATA_MAP;WA=Bclass.WA;
	}

	public GetSRF(WebDriver driver, Reporter report, Map<String,String> DATA_MAP) {

		this.driver=driver;this.Report = report;this.DATA_MAP=DATA_MAP;this.WA= new WebActions(driver,report);
		
	}

	public void GetSRFDetails(String PageName) {

		try {
			if(LoadEnvironment.EnvironmentDataMap.get("SRFValues").equalsIgnoreCase("1")) {
				String Element = ""; 
				Map<String, String> SRF_MAP = new HashMap<String, String>();;
				
				WA.waitUntilElementClickable(OpenUI_HELP);
				WA.VerifyElementPresentAndClick(OpenUI_HELP, OpenUI_HELP);
				WA.waitUntilElementClickable(OpenUI_AboutView);
				WA.VerifyElementPresentAndClick(OpenUI_AboutView, OpenUI_AboutView);

				WA.waitUntilElementClickable(OpenUI_Applets);
				String AppletData = WA.VerifyElementPresentAndGetAttribute(OpenUI_Applets,"title");
				//System.out.println(AppletData);
				WA.waitUntilElementClickable(OpenUI_AppletsOKButton);
				WA.VerifyElementPresentAndClick(OpenUI_AppletsOKButton, OpenUI_AppletsOKButton);

				//Process Applets
				AppletData = AppletData.replaceAll("Applet\\[\\d\\]: ", "");
				AppletData = AppletData.replaceAll("; ", ";");
				AppletData = AppletData.replaceAll(";\\$", "");
				System.out.println("AFTER PROCESSING   "+AppletData);
				System.out.println("==================================================================");
				System.out.println("PAGE NAME : "+PageName);
				for(String appletDataPart :AppletData.split(";") ) {
					Element = WA.getSRFDetails(driver, appletDataPart);
					Element = Element.replaceAll("\"","");
					Element = Element.replaceAll("\\{","");
					Element = Element.replaceAll("\\}","");
					System.out.println(Element);
					if(!Element.equalsIgnoreCase(""))
						for(String E : Element.split(",")){
							System.out.println(E.split(":")[0]+" = "+ E.split(":")[1]);
							SRF_MAP.put(E.split(":")[0], E.split(":")[1]);
						}
				}
				System.out.println("==================================================================");
				WriteExcel.WriteSRFDetails(PageName, SRF_MAP);

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



}
