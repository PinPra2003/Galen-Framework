package com.BusinessModules.Cucumber.Steps;

import com.BusinessModules.Cucumber.Commons.BaseClass;
import com.WebObjectRepository.ObjectRepo;

import cucumber.api.java.en.Then;

public class StepDefn implements ObjectRepo{
	
	BaseClass baseClass;
	public StepDefn(BaseClass Bclass) {
		baseClass= Bclass;
	}
	
	@Then("^Search \"([^\"]*)\"$")
	public void search(String content) throws Throwable {
		baseClass.Report.fnReportPageBreak("Search", baseClass.driver);
		baseClass.WA.VerifyElementPresentAndType(DESKTOP_XPATH_Searchbox, "SEARCH BOX", baseClass.getData(content));
	}

	@Then("^ClickGoButton$")
	public void clickgobutton() throws Throwable {
		baseClass.Report.fnReportPageBreak("Go Button", baseClass.driver);
		baseClass.WA.VerifyElementPresentAndClick(DESKTOP_XPATH_Searchbox_Submit, "Submit Button");
	}
}