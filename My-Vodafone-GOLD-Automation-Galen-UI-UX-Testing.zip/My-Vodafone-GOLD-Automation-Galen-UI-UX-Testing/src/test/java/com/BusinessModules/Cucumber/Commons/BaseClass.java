package com.BusinessModules.Cucumber.Commons;

import java.util.Map;

import org.openqa.selenium.WebDriver;

import com.Engine.CucumberSetup;

import com.WebActions.WebActions;

/**
 * @author Karthik Kannan
 *
 */
public class BaseClass extends CucumberSetup{
	public BaseClass(){
	System.out.println("IN B CONST");	
	}

	public WebActions WA;
	public WebDriver driver;
	public Map<String, String> DATA_MAP;
	public String dataMapName		= Thread.currentThread().getName();
	public String WorkBook			= Thread.currentThread().getName().split(",")[0];
	public String WorkSheet			= Thread.currentThread().getName().split(",")[1];
	public String RowNumber			= Thread.currentThread().getName().split(",")[2];

	/**
	 * @param Data
	 * @return
	 */
	public String getData(String Data) {
		String ReturnData = Data;
		ReturnData = DATA_MAP.get(Data);
		if (ReturnData == null) {
			ReturnData = Data;
		}
		return ReturnData;
	}

}
