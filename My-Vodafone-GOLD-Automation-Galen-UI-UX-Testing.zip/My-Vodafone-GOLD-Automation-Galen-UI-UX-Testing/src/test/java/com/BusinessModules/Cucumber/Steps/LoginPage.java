package com.BusinessModules.Cucumber.Steps;

import java.util.Map;

import org.openqa.selenium.WebDriver;


import com.BusinessModules.Cucumber.Commons.BaseClass;

import com.Engine.LoadEnvironment;
import com.Engine.Reporter;
import com.WebActions.WebActions;
import com.WebObjectRepository.ObjectRepo;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class LoginPage implements ObjectRepo{
	//BaseClass baseClass;
	WebDriver driver;
	Reporter Report;

	Map<String, String> DATA_MAP;
	WebActions WA;

	public LoginPage(BaseClass Bclass) {
		//baseClass= Bclass;
		driver=Bclass.driver;Report = Bclass.Report;DATA_MAP=Bclass.DATA_MAP;WA=Bclass.WA;
	}

	public LoginPage(WebDriver driver, Reporter report, Map<String,String> DATA_MAP, WebActions WA) {
		this.driver=driver;this.Report = report;this.DATA_MAP=DATA_MAP;this.WA=WA;
	}

	@Given("^The user is on the Siebel login screen$")
	public void theUserIsOnTheSiebelLoginScreen() throws Throwable {
		driver.get(LoadEnvironment.EnvironmentDataMap.get("CRM_URL"));
	}

	@Then("^The user enters the login username$")
	public void theUserEntersTheLoginUsername() throws Throwable {
		WA.VerifyElementPresentAndType(XPATH_USERNAME, "SIEBEL USER NAME", LoadEnvironment.EnvironmentDataMap.get("CRM_UserName"));
	}

	@Then("^The user enters the login password$")
	public void theUserEntersTheLoginPassword() throws Throwable {
		WA.VerifyElementPresentAndType(XPATH_PASSWORD, "SIEBEL PASSWORD", LoadEnvironment.EnvironmentDataMap.get("CRM_Password"));
	}

	@Then("^The user clicks on the login button$")
	public void theUserClicksOnTheLoginButton() throws Throwable {
		WA.VerifyElementPresentAndClick(XPATH_LoginButton, "LOGIN BUTTON");
	}
	@And("^The user is on the home screen$")
	public void theUserIsOnTheHomeScreen() throws Throwable {
		if(driver.getCurrentUrl().contains("Home+Page+View")){
			System.out.println("-------------Home URL Loading-------------");
		}
		if(WA.waitForElementToAppear(XPATH_TAB_LINK.replaceAll("<<TAB>>", "Home"), Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("MEDIUM_TIMEOUT")))){
			Report.fnReportPageBreak("Home Screen", driver);
		}
	}

}
