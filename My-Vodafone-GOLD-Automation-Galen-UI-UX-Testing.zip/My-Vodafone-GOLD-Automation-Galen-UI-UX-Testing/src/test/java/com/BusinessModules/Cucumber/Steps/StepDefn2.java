package com.BusinessModules.Cucumber.Steps;

import com.BusinessModules.Cucumber.Commons.BaseClass;
import com.WebObjectRepository.ObjectRepo;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class StepDefn2 implements ObjectRepo{
	
	BaseClass baseClass;
	public StepDefn2(BaseClass Bclass) {
		baseClass= Bclass;
	}
	
	
	@Given("^Navigate_To_URL \"([^\"]*)\"$")
	public void navigate_to_url(String arg1) throws Throwable {
		baseClass.driver.get("http://www.seleniumhq.org");
		
	   
	}

	@Then("^Click_Projects_Tab$")
	public void click_projects_tab() throws Throwable {
		baseClass.Report.fnReportPageBreak("Projects Tab", baseClass.driver);
		baseClass.WA.VerifyElementPresentAndClick(DESKTOP_XPATH_Projects_Tab, "Projects TAB");
	}

	@Then("^Click_Download_Tab$")
	public void click_download_tab() throws Throwable {
		baseClass.Report.fnReportPageBreak("Click_Download_Tab ", baseClass.driver);
		baseClass.WA.VerifyElementPresentAndClick(DESKTOP_XPATH_Download_Tab, "Downloads TAB");
	}

	@Then("^Click_Documentation_Tab$")
	public void click_documentation_tab() throws Throwable {
		baseClass.Report.fnReportPageBreak("Click_Documentation_Tab", baseClass.driver);
		baseClass.WA.VerifyElementPresentAndClick(DESKTOP_XPATH_Documentation_Tab, "Documentation TAB");
	}


}