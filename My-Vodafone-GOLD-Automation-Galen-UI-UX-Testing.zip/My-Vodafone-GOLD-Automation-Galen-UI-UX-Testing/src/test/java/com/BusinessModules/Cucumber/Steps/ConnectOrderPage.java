package com.BusinessModules.Cucumber.Steps;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.Engine.Reporter;
import com.WebActions.WebActions;
import com.BusinessModules.Cucumber.Commons.BaseClass
;
import com.Engine.LoadEnvironment;
import com.WebObjectRepository.ObjectRepo;
import com.relevantcodes.extentreports.LogStatus;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class ConnectOrderPage implements ObjectRepo{
	//BaseClass baseClass;
	WebDriver driver;
	Reporter Report;

	Map<String, String> DATA_MAP;
	WebActions WA;

	public ConnectOrderPage(BaseClass Bclass) {
		//baseClass= Bclass;
		driver=Bclass.driver;Report = Bclass.Report;DATA_MAP=Bclass.DATA_MAP;WA=Bclass.WA;
	}

	public ConnectOrderPage(WebDriver driver, Reporter report, Map<String,String> DATA_MAP, WebActions WA) {
		this.driver=driver;this.Report = report;this.DATA_MAP=DATA_MAP;this.WA=WA;
	}


	@Then("^The user clicks on the \"([^\"]*)\" Tab from top menu$")
	public void theUserClicksOnTheSomethingTabFromTopMenu(String tabName) throws Throwable {
		WA.VerifyElementPresentAndClick(XPATH_TAB_LINK.replaceAll("<<TAB>>", tabName), tabName + "Tab");
		WA.waitForElementToAppear(XPATH_TAB_ISACTIVE_CHECK.replaceAll("<<TAB>>", tabName),Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LARGE_TIMEOUT")));
		Report.ReporterLog("Clicked on Connection", LogStatus.INFO, driver);
	}

	@Then("^The user clicks on the \"([^\"]*)\" from siebel tool bar$")
	public void theUserClicksOnTheSomethingFromSiebelToolBar(String Toolbar_option) throws Throwable {
		WA.VerifyElementPresentAndClick(XPATH_TOOLBAR_OPTIONS.replaceAll("<<OPTION>>", Toolbar_option), Toolbar_option );
		Report.ReporterLog("Clicked on Tasks from tool bar", LogStatus.INFO, driver);
	}

	@Then("^The user clicks on \"([^\"]*)\" from task list$")
	public void theUserClicksOnSomethingFromTaskList(String taskName) throws Throwable {
		WA.waitForElementToAppear(XPATH_CONNECT_NBN_FROM_TASKS, Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LARGE_TIMEOUT")));
		WA.VerifyElementPresentAndClick(XPATH_CONNECT_NBN_FROM_TASKS, "Connect NBN from Task");
		Report.ReporterLog("Clicked on Connect NBN from task list", LogStatus.INFO, driver);

	}


	@And("^The user is on \"([^\"]*)\" Page$")
	public void theUserIsOnSomethingPage(String taskName) throws Throwable {
		WA.waitForElementToAppear(XPATH_TASK_PAGE_VERIFY.replaceAll("<<TASK NAME>>", taskName), Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LARGE_TIMEOUT")));
		Report.fnReportPageBreak("Connect NBN Page", driver);
	}

	@Then("^Retrive \"([^\"]*)\"$")
	public void retriveSomething(String retrive) throws Throwable {
		switch(retrive){
		case "Order Number":
			WA.waitForElementToAppear(XPATH_ORDER_NUMBER, Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LARGE_TIMEOUT")));
			WebElement W = WA.VerifyElementPresentAndGetElement(XPATH_ORDER_NUMBER);
			System.out.println(W);
			break;
		case "Session Id":
			WA.waitForElementToAppear(XPATH_SESSION_ID, Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LARGE_TIMEOUT")));

			break;
		}
	}


}
