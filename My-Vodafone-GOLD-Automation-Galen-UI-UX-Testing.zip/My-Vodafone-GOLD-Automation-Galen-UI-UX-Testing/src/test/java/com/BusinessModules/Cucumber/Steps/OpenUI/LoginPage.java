package com.BusinessModules.Cucumber.Steps.OpenUI;

import java.util.Map;
import org.openqa.selenium.WebDriver;
import com.BusinessModules.Cucumber.Commons.BaseClass;
import com.Engine.ExceptionHandlers;
import com.Engine.LoadEnvironment;
import com.Engine.Reporter;
import com.WebActions.WebActions;
import com.WebObjectRepository.ObjectRepo_OpenUI_TBUI;


public class LoginPage implements ObjectRepo_OpenUI_TBUI{
	//BaseClass baseClass;
	WebDriver driver;
	Reporter Report;

	Map<String, String> DATA_MAP;
	WebActions WA;


	public LoginPage(BaseClass Bclass) {
		//baseClass= Bclass;
		driver=Bclass.driver;Report = Bclass.Report;DATA_MAP=Bclass.DATA_MAP;WA=Bclass.WA;
	}

	public LoginPage(WebDriver driver, Reporter report, Map<String,String> DATA_MAP) {
		this.driver=driver;this.Report = report;this.DATA_MAP=DATA_MAP;this.WA= new WebActions(driver,report);
	}

	public void Login(String Username,String Password) {
		try {
			/******** GALEN INTEGRATION ***********/
//			String Devices = "DESKTOP,TABLET";
			WA.VerifyElementPresentAndType(OpenUI_USERNAME, "UserName", Username);
			WA.VerifyElementPresentAndType(OpenUI_PASSWORD, "Password",Password);
//			WA.SpecCheck("Login.gspec", Devices.split(","));
			WA.VerifyElementPresentAndClick(OpenUI_LOGIN, "login button");
		}catch(Exception exception) {
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage(),driver);
		}
	}

	public void Navigate() {
		try {
			driver.get(LoadEnvironment.EnvironmentDataMap.get("LAUNCHURL"));
			Report.fnReportInfo("NAVIGATED TO URL " + LoadEnvironment.EnvironmentDataMap.get("LAUNCHURL") , driver);
			/******** GALEN INTEGRATION ***********/
//			String Devices = "MOBILE_IPHONE6_P";
//			WA.SpecCheck("Login2.gspec", Devices.split(","));
		}catch(Exception exception) {
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage(),driver);
		}	

	}


}
