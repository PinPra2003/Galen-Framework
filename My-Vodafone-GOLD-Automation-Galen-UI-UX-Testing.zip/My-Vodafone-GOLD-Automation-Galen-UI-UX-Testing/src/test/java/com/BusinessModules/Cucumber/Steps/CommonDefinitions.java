package com.BusinessModules.Cucumber.Steps;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Set;

import com.BusinessModules.Cucumber.Commons.BaseClass;
import com.Engine.LoadEnvironment;
import com.WebActions.WebActions;
import com.WebObjectRepository.ObjectRepo;
import com.relevantcodes.extentreports.LogStatus;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class CommonDefinitions implements ObjectRepo{

	BaseClass baseClass;

	public CommonDefinitions(BaseClass baseClass) {
		this.baseClass= baseClass;
	}

	@Before
	public void before(Scenario scenario) {

		System.out.println("-------------------------@BEFORE  "+Thread.currentThread().getName().split(",")[2]+" ----------------");	
		baseClass.WorkBook			= Thread.currentThread().getName().split(",")[0];
		baseClass.WorkSheet			= Thread.currentThread().getName().split(",")[1];
		baseClass.RowNumber			= Thread.currentThread().getName().split(",")[2];

		System.out.println("scenario name  --> "+scenario.getName().toString());

		baseClass.DATA_MAP = baseClass.CreateDataMap(baseClass.RowNumber, baseClass.WorkBook, baseClass.WorkSheet);
		baseClass.Report=baseClass.CreateReport(scenario.getName().toString().toUpperCase(), baseClass.RowNumber);
		//baseClass.driver = baseClass.CreateDriver(baseClass.DATA_MAP.get("BROWSER"), baseClass.DATA_MAP.get("MODE"));


		baseClass.driver = baseClass.WhereToExecute(baseClass.DATA_MAP.get("BROWSER"),
				LoadEnvironment.EnvironmentDataMap.get("CRM_URL"), 
				baseClass.set_ModeResolution(baseClass.DATA_MAP.get("MODE")));
		baseClass.Report.fnReportInfo("TEST CASE STARTED IN "+ baseClass.DATA_MAP.get("BROWSER") + " BROWSER AND IN "+baseClass.DATA_MAP.get("MODE")+" MODE");
		baseClass.WA = new WebActions(baseClass.driver, baseClass.Report);



		for (String Tag : scenario.getSourceTagNames())
			baseClass.Report.EXTENTTEST.assignCategory(Tag);

		baseClass.Report.EXTENTTEST.setDescription("Executing Scenario " + scenario.getName());
		try {
			baseClass.Report.EXTENTTEST.assignAuthor(
					"IP:" + InetAddress.getLocalHost() + " HostName:" + InetAddress.getLocalHost().getHostName());
		} catch (UnknownHostException e) {
			baseClass.Report.ReporterLog("Author of execution not set due to " + e.getMessage(), LogStatus.INFO);

		}
	}
	@After
	public void tearDown() throws Exception {
		System.out.println("-------------------------@after  "+Thread.currentThread().getName().split(",")[2]+" ----------------");	
		if (baseClass.Report.TESTPASSED) {
			baseClass.Report.ReporterLog("TEST PASSED", LogStatus.PASS);
		} else {
			baseClass.Report.ReporterLog("TEST FAILED", LogStatus.FAIL);
		}
		if (System.getProperty("REPORT_APPEND") != null
				&& System.getProperty("REPORT_APPEND").equalsIgnoreCase("TRUE")) {
			// CommonStaticVariables.EXTENTTESTREPORT would be closed in
			// @AfterSuite
			baseClass.Report.EXTENTTESTREPORT.endTest(baseClass.Report.EXTENTTEST);
			baseClass.Report.EXTENTTESTREPORT.flush();
		} else {
			baseClass.Report.EXTENTTESTREPORT.endTest(baseClass.Report.EXTENTTEST);
			baseClass.Report.EXTENTTESTREPORT.flush();
			baseClass.Report.EXTENTTESTREPORT.close();
		}
		// Closing and Quitting the Driver instance
		if (baseClass.driver != null) {
			baseClass.driver.close();baseClass.driver.quit();
		} else {
			System.out.println(
					baseClass.Report.CurrentRowOfExecution + "   --------------------DRIVER IS NULL----------------------");
		}

	}


	public void changeTohttp() {
		String getURL = "";
		String newURL = "";
		try {
			System.out.println("http");
			getURL = baseClass.WA.driver.getCurrentUrl();
			newURL = getURL.replace("https", "http");
			baseClass.WA.driver.get(newURL);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void Switch_Window(String... Window_to_switch) {
		String parentWindow = baseClass.WA.driver.getWindowHandle();
		Set<String> handles = baseClass.WA.driver.getWindowHandles();
		for (String windowHandle : handles) {
			if (Window_to_switch.length > 0) {
				if (windowHandle.contains(Window_to_switch[0])) {
					baseClass.WA.driver.switchTo().window(windowHandle);
					break;
				}
			} else {
				if (!windowHandle.equals(parentWindow)) {
					baseClass.WA.driver.switchTo().window(windowHandle);
					break;
				}
			}
		}
	}



	public String RetrieveParamter(String Data) {
		String ReturnData = System.getProperty(Data);
		if (ReturnData == null) {
			ReturnData = LoadEnvironment.EnvironmentDataMap.get(Data);
			if (ReturnData == null) {
				ReturnData = baseClass.DATA_MAP.get(Data);
			}
		}
		if (ReturnData == null) {
			ReturnData = Data;
		}
		return ReturnData;
	}

	

}