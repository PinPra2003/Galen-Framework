package com.BusinessModules.Cucumber.Steps.OpenUI;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.BusinessModules.Cucumber.Commons.BaseClass;
import com.Engine.ExceptionHandlers;
import com.Engine.Reporter;
import com.SharedModules.Constants;
import com.Utils.ReadExcelSheet;
import com.Utils.WriteExcel;
import com.WebActions.WebActions;
import com.WebObjectRepository.ObjectRepo_OpenUI_TBUI;
import com.google.common.collect.Multimap;




public class TBUI_Flow implements ObjectRepo_OpenUI_TBUI,Constants{
	//BaseClass baseClass;
	WebDriver driver;
	Reporter Report;
	Map<String, String> DATA_MAP;
	WebActions WA;

	GetSRF SRF;

	public TBUI_Flow(BaseClass Bclass) {
		//baseClass= Bclass;
		driver=Bclass.driver;Report = Bclass.Report;DATA_MAP=Bclass.DATA_MAP;WA=Bclass.WA;
		SRF = new GetSRF(driver, Report, DATA_MAP);
	}

	public TBUI_Flow(WebDriver driver, Reporter report, Map<String,String> DATA_MAP) {
		this.driver=driver;this.Report = report;this.DATA_MAP=DATA_MAP;this.WA= new WebActions(driver,report);
		SRF = new GetSRF(driver, Report, DATA_MAP);
	}

	public void CustomerDetails_TBUI(String CustomerSegment, String BusinessCustomertype, String ABN) {

		System.out.println(CustomerSegment);
		try {

			WA.waitUntilElementClickable(OpenUI_HomeSelected);
			SRF.GetSRFDetails("Customer Details");

			//Connect Postpaid
			WA.waitUntilElementClickable(OpenUI_TBUI_ConnectPostpaid);
			WA.VerifyElementPresentAndClick(OpenUI_TBUI_ConnectPostpaid,OpenUI_TBUI_ConnectPostpaid);
			WA.waitUntilElementClickable(OpenUI_TBUI_NextButton);

			SRF.GetSRFDetails("Customer Details 1");


			//			WA.getSRFDetails(driver, "VF Capture Customer Details Toggle Form Applet – TBUI");
			//			WA.getSRFDetails(driver, "VF Task Playbar Applet - Top");
			//			WA.getSRFDetails(driver, "VF Task Session Form Applet – TBUI");



			if(CustomerSegment.equalsIgnoreCase("Consumer")){
				//Customer Details
				WA.VerifyElementPresentAndType(OpenUI_TBUI_CustomerSegment,OpenUI_TBUI_CustomerSegment,"Consumer");
				WA.waitUntilElementClickable(OpenUI_TBUI_CAPIN);
				WA.VerifyElementPresentAndType(OpenUI_TBUI_CAPIN,OpenUI_TBUI_CAPIN,TESTDATA_CAPIN);

				WA.waitUntilElementClickable(OpenUI_TBUI_CAPIN);
				WA.VerifyElementPresentAndType(OpenUI_TBUI_CAPIN,OpenUI_TBUI_CAPIN,TESTDATA_CAPIN);		
			}else if (CustomerSegment.equalsIgnoreCase("Business")){
				// Customer Details
				WA.VerifyElementPresentAndType(OpenUI_TBUI_CustomerSegment,OpenUI_TBUI_CustomerSegment,"Business");

				WA.waitUntilElementClickable(OpenUI_TBUI_CAPIN);
				WA.VerifyElementPresentAndType(OpenUI_TBUI_CAPIN,OpenUI_TBUI_CAPIN,TESTDATA_CAPIN);


				WA.waitUntilElementClickable(OpenUI_TBUI_CAPIN);
				WA.VerifyElementPresentAndType(OpenUI_TBUI_CAPIN,OpenUI_TBUI_CAPIN,TESTDATA_CAPIN);

				WA.waitUntilElementClickable(OpenUI_TBUI_ABNorACN);
				WA.VerifyElementPresentAndType(OpenUI_TBUI_ABNorACN,OpenUI_TBUI_ABNorACN, ABN);


				WA.VerifyElementPresentAndType(OpenUI_TBUI_TradingAs,OpenUI_TBUI_TradingAs,TESTDATA_TradingAs);
				WA.VerifyElementPresentAndType(OpenUI_TBUI_TradingDate,OpenUI_TBUI_TradingDate,TESTDATA_TradingDate);
				WA.VerifyElementPresentAndType(OpenUI_TBUI_Company_Name_Label,OpenUI_TBUI_Company_Name_Label,TESTDATA_TradingCompany);
				WA.VerifyElementPresentAndType(OpenUI_TBUI_ABNorACN,OpenUI_TBUI_ABNorACN, ABN);

				//				WA.VerifyElementPresentAndClick(OpenUI_TBUI_ValidateABNorACN,OpenUI_TBUI_ValidateABNorACN);
				//				if(WA.VerifyElementPresent("//span[text()='ABR Enquiry']/following-sibling::button", "ABR Close Button", false)) {
				//					System.out.println("ABN SEARCH NOT FOUND CLICKING CLOSE BUTTONm");
				//					WA.VerifyElementPresentAndClick_JavaScript("//span[text()='ABR Enquiry']/following-sibling::button","Close Button");
				//					WA.VerifyElementPresentAndClearType(OpenUI_TBUI_ABNorACN,OpenUI_TBUI_ABNorACN, ABN);
				//					WA.VerifyElementPresentAndClearType(OpenUI_TBUI_CAPIN,OpenUI_TBUI_CAPIN,TESTDATA_CAPIN);
				//					WA.VerifyElementPresentAndClick(OpenUI_TBUI_ValidateABNorACN,OpenUI_TBUI_ValidateABNorACN);
				//				}
				//				WA.waitUntilElementClickable(OpenUI_TBUI_Pick);
				//				WA.VerifyElementPresentAndClick(OpenUI_TBUI_Pick,OpenUI_TBUI_Pick);


				WA.VerifyElementPresentAndType(OpenUI_TBUI_CustomerType,OpenUI_TBUI_CustomerType, BusinessCustomertype);
				WA.VerifyElementPresentAndType( OpenUI_TBUI_IndustryType,OpenUI_TBUI_IndustryType, "Business Services - Other");
				WA.VerifyElementPresentAndType(OpenUI_TBUI_EmployeeRange,OpenUI_TBUI_EmployeeRange, "10-49");
				//Decision Maker
				WA.VerifyElementPresentAndType(OpenUI_TBUI_DecisionMaker,OpenUI_TBUI_DecisionMaker, "Y");
			}else{
				System.out.println("Please Mention the customer type");
			}
			//Contact Details

			WA.VerifyElementPresentAndType(OpenUI_TBUI_Title,OpenUI_TBUI_Title,"Mr");
			driver.findElement(By.xpath(OpenUI_TBUI_Title1)).sendKeys(Keys.TAB);
			WA.VerifyElementPresentAndType(OpenUI_TBUI_DOB,OpenUI_TBUI_DOB,"16/05/1988");
			WA.VerifyElementPresentAndType(OpenUI_TBUI_FirstName,OpenUI_TBUI_FirstName,"AUTOMATION BUFFET");
			WA.VerifyElementPresentAndType(OpenUI_TBUI_LastName,OpenUI_TBUI_LastName,"Approve");
			WA.VerifyElementPresentAndType(OpenUI_TBUI_ContactNumber,OpenUI_TBUI_ContactNumber,"61402362515");		    
			WA.VerifyElementPresentAndType(OpenUI_TBUI_Email,OpenUI_TBUI_Email,"61402362515@test.com");

			// Address Information

			WA.VerifyElementPresentAndType(OpenUI_TBUI_Address,OpenUI_TBUI_Address,"Level 7  40 Mount Street, NORTH SYDNEY  NSW  2060");
			Thread.sleep(2000);
			//			Robot robot = new Robot();
			//			robot.keyPress(KeyEvent.VK_BACK_SPACE);
			//			Thread.sleep(2*1000);
			//			robot.keyPress(KeyEvent.VK_DOWN);
			//			robot.keyPress(KeyEvent.VK_ENTER);
			driver.findElement(By.xpath(OpenUI_TBUI_Address)).sendKeys(Keys.BACK_SPACE);
			driver.findElement(By.xpath(OpenUI_TBUI_Address)).sendKeys(Keys.DOWN);
			driver.findElement(By.xpath(OpenUI_TBUI_Address)).sendKeys(Keys.ENTER);
			//			WA.VerifyElementPresentAndClick(OpenUI_TBUI_Address,OpenUI_TBUI_Address);

			//Coverage Check
			WA.VerifyElementPresentAndClick(OpenUI_TBUI_CoverageCheckRequired, "CoverageCheck Check Box");
			//	WA.VerifyElementPresentAndClick(OpenUI_TBUI_CoverageCheckBitton,OpenUI_TBUI_CoverageCheckBitton);

			//Next
			Report.fnReportPageBreak("CustomerDetails_TBUI Page", driver);
			WA.waitUntilElementClickable(OpenUI_TBUI_NextButton);
			WA.VerifyElementPresentAndClick(OpenUI_TBUI_NextButton,OpenUI_TBUI_NextButton);	

			boolean alertpresent= WA.isAlertPresent();
			if(alertpresent==true){
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), "ALERT PRESENT ", driver);

				//				System.out.println("Alert present and the value is:  "+alertpresent);
				//				WA.waitUntilElementClickable(OpenUI_TBUI_CAPIN);
				//				WA.VerifyElementPresentAndType(OpenUI_TBUI_CAPIN,OpenUI_TBUI_CAPIN,TESTDATA_CAPIN);
				//				WA.waitUntilElementClickable(OpenUI_TBUI_NextButton);
				//				WA.VerifyElementPresentAndClick( OpenUI_TBUI_NextButton,OpenUI_TBUI_NextButton); 
			}
		} catch (Exception exception) {
			exception.printStackTrace();
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage()+" Occured in CustomerDetails_TBUI Function",driver);
		}


	}

	public void Add_Identity() {
		try {

			WA.waitUntilElementClickable(OpenUI_TBUI_Identification_New);	
			SRF.GetSRFDetails("Indentification Page");
			Report.fnReportPageBreak("Add_Identity Page START", driver);

			WA.waitUntilElementClickable(OpenUI_TBUI_Identification_New);

			//Add Identity

			WA.VerifyElementPresentAndClick(OpenUI_TBUI_Identification_New,OpenUI_TBUI_Identification_New);

			WA.waitUntilElementClickable(OpenUI_TBUI_IDTypeOne);
			List<WebElement> IDType = driver.findElements(By.xpath("//*[contains(@aria-labelledby,'Id_Type')]"));
			System.out.println(IDType.size());
			int IDs = IDType.size()-1;
			System.out.println(IDs);
			if(IDType.size()>1){
				System.out.println("If Conditions");
				Thread.sleep(WA.LOOP_TIMEOUT*1000);
				IDType.get(IDs).sendKeys("Driver's Licence");
				Thread.sleep(WA.LOOP_TIMEOUT*1000);
				IDType.get(IDs).sendKeys(Keys.ENTER);
				IDType.get(IDs).sendKeys(Keys.TAB);
			}
			else{
				System.out.println("Else Conditions");
				IDType.get(0).sendKeys("Driver's Licence");
				Thread.sleep(WA.LOOP_TIMEOUT*1000);
				IDType.get(0).sendKeys(Keys.ENTER);
				IDType.get(0).sendKeys(Keys.TAB);
			}

			char[] alphaNumeric = "1234567890abcdefghijklmnopqrstuvwxyz".toCharArray();
			StringBuilder identity1 = new StringBuilder();
			StringBuilder identity2 = new StringBuilder();
			Random randomAN = new Random();
			for (int i = 0; i < 10; i++) {
				char id1 = alphaNumeric[randomAN.nextInt(alphaNumeric.length)];
				char id2 = alphaNumeric[randomAN.nextInt(alphaNumeric.length)];
				identity1.append(id1);
				identity2.append(id2);
			}
			String idType1 = identity1.toString();
			String idType2 = identity2.toString();

			List<WebElement> RefNums = driver.findElements(By.xpath("//*[contains(@aria-labelledby,'Id_Reference_Number')]"));
			System.out.println(RefNums.size());
			int RFs = RefNums.size()-1;
			if(RefNums.size()>1){
				RefNums.get(RFs).sendKeys(idType1);
				RefNums.get(0).sendKeys(Keys.TAB);
			}
			else{
				RefNums.get(0).sendKeys(idType1);
				RefNums.get(0).sendKeys(Keys.TAB);
			}

			driver.findElement(By.xpath(OpenUI_TBUI_IDExpiryOne1)).sendKeys(Keys.TAB);
			WA.VerifyElementPresentAndType(OpenUI_TBUI_IDStateOfIssueOne,OpenUI_TBUI_IDStateOfIssueOne,"NSW");
			driver.findElement(By.xpath(OpenUI_TBUI_IDStateOfIssueOne1)).sendKeys(Keys.TAB);
			// WA.type(OpenUI_TBUI_IDCountryOfIssueOne,"Australia");
			Thread.sleep(WA.LOOP_TIMEOUT*1000);


			//Add Identity 2
			WA.VerifyElementPresentAndClick(OpenUI_TBUI_Identification_New,OpenUI_TBUI_Identification_New);

			System.out.println("\n Add Identity 2");

			//  WA.clickAnElementByXpath(OpenUI_TBUI_IDTypeOne1);

			List<WebElement> IDType2 = driver.findElements(By.xpath("//*[contains(@aria-labelledby,'Id_Type')]"));


			System.out.println(IDType2.size());
			int IDs2 = IDType2.size()-1;
			System.out.println(IDs2);
			if(IDType2.size()>1){
				System.out.println("If Conditions");
				//IDType2.get(IDs2).sendKeys("Passport");
				Thread.sleep(WA.LOOP_TIMEOUT*1000);
				//IDType2.get(IDs2).sendKeys(Keys.ENTER);
				//IDType2.get(IDs2).sendKeys(Keys.TAB);
				driver.findElement(By.xpath("//*[@id='1_Id_Type']")).sendKeys(Keys.ENTER);
				driver.findElement(By.xpath("//*[@id='1_Id_Type']")).sendKeys(Keys.TAB);
			}
			else{
				System.out.println("Else Conditions");
				Thread.sleep(WA.LOOP_TIMEOUT*1000);
				driver.findElement(By.xpath("//*[@id='1_Id_Type']")).sendKeys("Passport");
				//IDType2.get(0).sendKeys("Passport");
				Thread.sleep(WA.LOOP_TIMEOUT*1000);
				//IDType2.get(0).sendKeys(Keys.ENTER);
				//IDType2.get(0).sendKeys(Keys.TAB);
				driver.findElement(By.xpath("//*[@id='1_Id_Type']")).sendKeys(Keys.ENTER);
				driver.findElement(By.xpath("//*[@id='1_Id_Type']")).sendKeys(Keys.TAB);

			}
			List<WebElement> RefNums2 = driver.findElements(By.xpath("//*[contains(@aria-labelledby,'Id_Reference_Number')]"));
			System.out.println(RefNums2.size());
			int RFs2 = RefNums2.size()-1;

			if(RefNums2.size()>1){
				// RefNums2.get(RFs2).sendKeys(idType2);
				// RefNums2.get(0).sendKeys(Keys.TAB);
				driver.findElement(By.xpath("//*[@id='1_Id_Reference_Number']")).sendKeys(idType2);
				//driver.findElement(By.xpath("//*[@id='1_Id_Reference_Number']")).sendKeys(Keys.ENTER);
				driver.findElement(By.xpath("//*[@id='1_Id_Reference_Number']")).sendKeys(Keys.TAB);
			}
			else{
				// RefNums2.get(0).sendKeys(idType2);
				// RefNums2.get(0).sendKeys(Keys.TAB);
				driver.findElement(By.xpath("//*[@id='1_Id_Reference_Number']")).sendKeys(idType2);
				//driver.findElement(By.xpath("//*[@id='1_Id_Reference_Number']")).sendKeys(Keys.ENTER);
				driver.findElement(By.xpath("//*[@id='1_Id_Reference_Number']")).sendKeys(Keys.TAB);
			}

			Thread.sleep(WA.LOOP_TIMEOUT*1000);
			driver.findElement(By.xpath(OpenUI_TBUI_IDExpiryOne1)).sendKeys(Keys.TAB);
			driver.findElement(By.xpath(OpenUI_TBUI_IDStateOfIssueOne1)).sendKeys(Keys.TAB);
			WA.VerifyElementPresentAndType(OpenUI_TBUI_IDCountryOfIssueOne,OpenUI_TBUI_IDCountryOfIssueOne,"Australia");		

			Report.fnReportPageBreak("ADD IDENTITY COMPLETE", driver);

		}catch(Exception exception) {
			exception.printStackTrace();
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage()+" Occured in ADD Identity Function",driver);
		}

	}

	public void ID_Scan() {
		Report.fnReportPageBreak("ID_Scan start", driver);
		WA.waitUntilElementClickable(OpenUI_TBUI_IDScanningNew);
		WA.VerifyElementPresentAndClick(OpenUI_TBUI_IDScanningNew,OpenUI_TBUI_IDScanningNew);
		WA.VerifyElementPresentAndType(OpenUI_TBUI_IDScanning,OpenUI_TBUI_IDScanning,"Scanner Not Working");	

		//Next
		WA.waitUntilElementClickable(OpenUI_TBUI_NextButton);
		WA.VerifyElementPresentAndClick(OpenUI_TBUI_NextButton,OpenUI_TBUI_NextButton);
		Report.fnReportPageBreak("ID_Scan COMPLETE", driver);
	}

	public void Credit_Check(String CustomerSegment,String BusinessCustomerType) {
		System.out.println(CustomerSegment);System.out.println(BusinessCustomerType);
		try {
			WA.waitUntilElementClickable(OpenUI_TBUI_Employment_Status);
			SRF.GetSRFDetails("Credit Check Page");
			//Credit Check Details

			//Consumer
			/****** AS ONLY ONE TYPE IS COMING ******************/
			if(CustomerSegment.equalsIgnoreCase("Consumer")){
				//				WA.waitUntilElementClickable(OpenUI_TBUI_Employment_Status);
				//				Thread.sleep(WA.LOOP_TIMEOUT*1000);
				//				WA.VerifyElementPresentAndClick(OpenUI_TBUI_Employment_Status,OpenUI_TBUI_Employment_Status);
				//				WA.VerifyElementPresentAndType(OpenUI_TBUI_Employment_Status,OpenUI_TBUI_Employment_Status,"Other");
				//				Thread.sleep(WA.LOOP_TIMEOUT*1000);
				//				WA.VerifyElementPresentAndClick(OpenUI_TBUI_Occupation,OpenUI_TBUI_Occupation);
				//				WA.VerifyElementPresentAndType(OpenUI_TBUI_Occupation,OpenUI_TBUI_Occupation,"Beneficiary");
				//				Thread.sleep(WA.LOOP_TIMEOUT*1000);
				//				//driver.findElement(By.xpath(OpenUI_TBUI_Occupation1)).sendKeys(Keys.DOWN);
				//				driver.findElement(By.xpath(OpenUI_TBUI_Occupation1)).sendKeys(Keys.ENTER);
				//				driver.findElement(By.xpath(OpenUI_TBUI_Occupation1)).sendKeys(Keys.ENTER);
				//				WA.waitUntilElementClickable(OpenUI_TBUI_YearAtCurrentAddress);
				//				WA.VerifyElementPresentAndType(OpenUI_TBUI_YearAtCurrentAddress,OpenUI_TBUI_YearAtCurrentAddress,"2");
				//				WA.waitUntilElementClickable(OpenUI_TBUI_Current_Address);
				//				WA.VerifyElementPresentAndType(OpenUI_TBUI_Current_Address,OpenUI_TBUI_Current_Address,TESTDATA_Address);
				//				Thread.sleep(WA.LOOP_TIMEOUT*1000);
				//				driver.findElement(By.xpath(OpenUI_TBUI_Current_Address1)).sendKeys(Keys.TAB);
				//				Thread.sleep(WA.LOOP_TIMEOUT*1000);
				//				WA.VerifyElementPresentAndClick(OpenUI_TBUI_Current_Address_OK,OpenUI_TBUI_Current_Address_OK);
				//				WA.VerifyElementPresentAndType(OpenUI_TBUI_Residential_Status,OpenUI_TBUI_Residential_Status,"Owner");
				//				WA.VerifyElementPresentAndType(OpenUI_TBUI_Permanent_Resident,OpenUI_TBUI_Permanent_Resident,"Y");
				//				

				//Employment
				WA.waitUntilElementClickable(OpenUI_TBUI_Employment_Status);
				Thread.sleep(WA.LOOP_TIMEOUT*1000);
				WA.VerifyElementPresentAndClick(OpenUI_TBUI_Employment_Status,OpenUI_TBUI_Employment_Status);
				WA.VerifyElementPresentAndType(OpenUI_TBUI_Employment_Status,OpenUI_TBUI_Employment_Status,"Full Time");
				Thread.sleep(WA.LOOP_TIMEOUT*1000);
				WA.VerifyElementPresentAndClick(OpenUI_TBUI_Occupation,OpenUI_TBUI_Occupation);
				WA.VerifyElementPresentAndType(OpenUI_TBUI_Occupation,OpenUI_TBUI_Occupation,"Professional");
				Thread.sleep(WA.LOOP_TIMEOUT*1000);
				driver.findElement(By.xpath(OpenUI_TBUI_Occupation1)).sendKeys(Keys.ENTER);
				driver.findElement(By.xpath(OpenUI_TBUI_Occupation1)).sendKeys(Keys.ENTER);
				//Address selection
				WA.waitUntilElementClickable(OpenUI_TBUI_Current_Address);
				WA.VerifyElementPresentAndType(OpenUI_TBUI_Current_Address,OpenUI_TBUI_Current_Address,TESTDATA_Address);
				Thread.sleep(WA.LOOP_TIMEOUT*1000);
				driver.findElement(By.xpath(OpenUI_TBUI_Current_Address1)).sendKeys(Keys.TAB);
				Thread.sleep(WA.LOOP_TIMEOUT*1000);
				WA.VerifyElementPresentAndClick(OpenUI_TBUI_Current_Address_OK,OpenUI_TBUI_Current_Address_OK);
				//Years At Address
				WA.waitUntilElementClickable(OpenUI_TBUI_YearAtCurrentAddress);
				WA.VerifyElementPresentAndType(OpenUI_TBUI_YearAtCurrentAddress,OpenUI_TBUI_YearAtCurrentAddress,"15");

				//Residential Status 
				WA.VerifyElementPresentAndType(OpenUI_TBUI_Residential_Status,OpenUI_TBUI_Residential_Status,"Owner");
				WA.VerifyElementPresentAndType(OpenUI_TBUI_Permanent_Resident,OpenUI_TBUI_Permanent_Resident,"Y");

				//Current Employer
				WA.VerifyElementPresentAndType(OpenUI_TBUI_CurrentEmployer,OpenUI_TBUI_CurrentEmployer,"TEST");
				WA.VerifyElementPresentAndType(OpenUI_TBUI_EmployerContactPhone,OpenUI_TBUI_EmployerContactPhone,"61466332255");
				WA.VerifyElementPresentAndType(OpenUI_TBUI_YearswithCurrentEmployer,OpenUI_TBUI_YearswithCurrentEmployer,"10");

			}else if(CustomerSegment.equalsIgnoreCase("Business")){
				if(BusinessCustomerType.equalsIgnoreCase("Sole Trader")) {
					WA.waitUntilElementClickable(OpenUI_TBUI_Employment_Status);
					Thread.sleep(WA.LOOP_TIMEOUT*1000);
					WA.VerifyElementPresentAndClick(OpenUI_TBUI_Employment_Status,OpenUI_TBUI_Employment_Status);
					WA.VerifyElementPresentAndType(OpenUI_TBUI_Employment_Status,OpenUI_TBUI_Employment_Status,"Self-Employed");
					Thread.sleep(WA.LOOP_TIMEOUT*1000);
					WA.VerifyElementPresentAndClick(OpenUI_TBUI_Occupation,OpenUI_TBUI_Occupation);
					WA.VerifyElementPresentAndType(OpenUI_TBUI_Occupation,OpenUI_TBUI_Occupation,"Professional");

					Thread.sleep(WA.LOOP_TIMEOUT*1000);
					driver.findElement(By.xpath(OpenUI_TBUI_Occupation1)).sendKeys(Keys.ENTER);
					driver.findElement(By.xpath(OpenUI_TBUI_Occupation1)).sendKeys(Keys.ENTER);
					WA.waitUntilElementClickable(OpenUI_TBUI_YearAtCurrentAddress);
					WA.VerifyElementPresentAndType(OpenUI_TBUI_YearAtCurrentAddress,OpenUI_TBUI_YearAtCurrentAddress,"15");

					WA.waitUntilElementClickable(OpenUI_TBUI_Current_Address);
					WA.VerifyElementPresentAndType(OpenUI_TBUI_Current_Address,OpenUI_TBUI_Current_Address,TESTDATA_Address);
					Thread.sleep(WA.LOOP_TIMEOUT*1000);
					driver.findElement(By.xpath(OpenUI_TBUI_Current_Address1)).sendKeys(Keys.TAB);
					Thread.sleep(WA.LOOP_TIMEOUT*1000);
					WA.VerifyElementPresentAndClick(OpenUI_TBUI_Current_Address_OK,OpenUI_TBUI_Current_Address_OK);

					WA.VerifyElementPresentAndType(OpenUI_TBUI_Residential_Status,OpenUI_TBUI_Residential_Status,"Owner");
					WA.VerifyElementPresentAndType(OpenUI_TBUI_Permanent_Resident,OpenUI_TBUI_Permanent_Resident,"Y");

					WA.VerifyElementPresentAndType(OpenUI_TBUI_CurrentEmployer,OpenUI_TBUI_CurrentEmployer,"TEST");
					WA.VerifyElementPresentAndType(OpenUI_TBUI_TimeinCurrentEmployer,OpenUI_TBUI_TimeinCurrentEmployer,"10");

					WA.VerifyElementPresentAndType(OpenUI_TBUI_IntendedUsage,OpenUI_TBUI_IntendedUsage,"Private");


				}else {
					WA.waitUntilElementClickable(OpenUI_TBUI_YearAtCurrentAddress);
					WA.VerifyElementPresentAndType(OpenUI_TBUI_YearAtCurrentAddress,OpenUI_TBUI_YearAtCurrentAddress,"2");
					WA.waitUntilElementClickable(OpenUI_TBUI_Current_Address);
					WA.VerifyElementPresentAndType(OpenUI_TBUI_Current_Address,OpenUI_TBUI_Current_Address,TESTDATA_Address);
					Thread.sleep(WA.LOOP_TIMEOUT*1000);
					driver.findElement(By.xpath(OpenUI_TBUI_Current_Address1)).sendKeys(Keys.TAB);
					Thread.sleep(WA.LOOP_TIMEOUT*1000);
					WA.VerifyElementPresentAndClick(OpenUI_TBUI_Current_Address_OK,OpenUI_TBUI_Current_Address_OK);
					WA.waitUntilElementClickable(OpenUI_TBUI_NumberOfLocations);
					WA.VerifyElementPresentAndType(OpenUI_TBUI_NumberOfLocations,OpenUI_TBUI_NumberOfLocations,"2");
					WA.VerifyElementPresentAndType(OpenUI_TBUI_ApplicantJobDetails,OpenUI_TBUI_ApplicantJobDetails,"General Manager");
					WA.VerifyElementPresentAndType(OpenUI_TBUI_TradingAddress,OpenUI_TBUI_TradingAddress,TESTDATA_Address);
					Thread.sleep(WA.LOOP_TIMEOUT*1000);
					driver.findElement(By.xpath(OpenUI_TBUI_TradingAddress1)).sendKeys(Keys.TAB);
					WA.waitUntilElementClickable(OpenUI_TBUI_TradingAddress_OK);
					WA.VerifyElementPresentAndClick(OpenUI_TBUI_TradingAddress_OK,OpenUI_TBUI_TradingAddress_OK);
				}
				Thread.sleep(WA.LOOP_TIMEOUT*1000);
			}


			//Handset List
			WA.waitUntilElementClickable(OpenUI_TBUI_HandSet_New);
			WA.VerifyElementPresentAndClick( OpenUI_TBUI_HandSet_New,OpenUI_TBUI_HandSet_New);
			WA.waitUntilElementClickable(OpenUI_TBUI_HandSet_Query);

			Thread.sleep(WA.LOOP_TIMEOUT*3*1000);
			WA.VerifyElementPresentAndClick( OpenUI_TBUI_HandSet_Query,OpenUI_TBUI_HandSet_Query);
			WebDriverWait wait=new WebDriverWait(driver, 3);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			alert.accept();

			WA.waitUntilElementClickable(OpenUI_TBUI_HandSet_Name);
			WA.VerifyElementPresentAndType(OpenUI_TBUI_HandSet_Name,OpenUI_TBUI_HandSet_Name,"APPLE");
			driver.findElement(By.xpath(OpenUI_TBUI_HandSet_Name1)).sendKeys(Keys.TAB);
			WA.waitUntilElementClickable(OpenUI_TBUI_HandSet_OK);
			Thread.sleep(WA.LOOP_TIMEOUT*1000);
			WA.VerifyElementPresentAndClick( OpenUI_TBUI_HandSet_OK,OpenUI_TBUI_HandSet_OK);

			//Credit Check Authorisation
			Thread.sleep(WA.LOOP_TIMEOUT*3*1000);
			WA.waitUntilElementClickable(OpenUI_TBUI_HandSet_Authorisation);
			WA.VerifyElementPresentAndCheck(OpenUI_TBUI_HandSet_Authorisation, OpenUI_TBUI_HandSet_Authorisation, true);
			//WA.VerifyElementPresentAndClick( OpenUI_TBUI_HandSet_Authorisation,OpenUI_TBUI_HandSet_Authorisation);
			Thread.sleep(WA.LOOP_TIMEOUT*1000);
			WA.VerifyElementPresentAndClick( OpenUI_TBUI_HandSet_Authorisation,OpenUI_TBUI_HandSet_Authorisation);
			WA.VerifyElementPresentAndCheck(OpenUI_TBUI_HandSet_Authorisation, OpenUI_TBUI_HandSet_Authorisation, true);
			//Submit Credit Check
			WA.waitUntilElementClickable(OpenUI_TBUI_Credit_Check_Submit);
			WA.VerifyElementPresentAndClick( OpenUI_TBUI_Credit_Check_Submit,OpenUI_TBUI_Credit_Check_Submit);
//			WA.VerifyElementDisabled(OpenUI_TBUI_Credit_Check_Submit, OpenUI_TBUI_Credit_Check_Submit);
			//Next
			WA.waitUntilElementClickable(OpenUI_TBUI_NextButton);
			Thread.sleep(WA.LOOP_TIMEOUT*1000);
			WA.waitUntilElementClickable(OpenUI_TBUI_NextButton);
			WA.VerifyElementPresentAndClick( OpenUI_TBUI_NextButton,OpenUI_TBUI_NextButton);
			WA.VerifyElementPresentAndClick( OpenUI_TBUI_NextButton,OpenUI_TBUI_NextButton);

			boolean alertpresent= WA.isAlertPresent();
			if(alertpresent==true){
				ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
				}.getClass().getEnclosingMethod().getName(), "ALERT PRESENT ", driver);
			}
			Report.fnReportPageBreak("Credit Check COMPLETE", driver);

		}catch(Exception exception) {
			exception.printStackTrace();
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage()+" Occured in Credit_Checkty Function",driver);
		}
	}

	public String Billing_Options(String CustomerType) {
		String orderNo ="";String RowID="";
		try {

			WA.waitUntilElementClickable(OpenUI_TBUI_Billing_BSB);
			SRF.GetSRFDetails("Billing Page");
			WA.VerifyElementPresentAndType(OpenUI_TBUI_Billing_BSB,OpenUI_TBUI_Billing_BSB,"012605");
			WA.VerifyElementPresentAndClick(OpenUI_TBUI_Billing_BSB_Search,OpenUI_TBUI_Billing_BSB_Search);
			WA.waitUntilElementClickable(OpenUI_TBUI_Billing_BankDetails_BSB);
			WA.VerifyElementPresentAndClick(OpenUI_TBUI_Billing_BankDetails_BSB,OpenUI_TBUI_Billing_BankDetails_BSB);
			WA.VerifyElementPresentAndType(OpenUI_TBUI_Billing_BankDetails_BSB,OpenUI_TBUI_Billing_BankDetails_BSB,"012605");
			Thread.sleep(WA.LOOP_TIMEOUT*1000);
			WA.VerifyElementPresentAndClick(OpenUI_TBUI_Billing_BSB_Go,OpenUI_TBUI_Billing_BSB_Go);
			WA.waitUntilElementClickable(OpenUI_TBUI_Billing_BSB_Pick);
			WA.VerifyElementPresentAndClick(OpenUI_TBUI_Billing_BSB_Pick,OpenUI_TBUI_Billing_BSB_Pick);
			WA.waitUntilElementClickable(OpenUI_TBUI_Billing_Account_Edit);
			WA.VerifyElementPresentAndClick(OpenUI_TBUI_Billing_Account_Edit,OpenUI_TBUI_Billing_Account_Edit);
			WA.waitUntilElementClickable(OpenUI_TBUI_Billing_Account_Number);
			WA.VerifyElementPresentAndType(OpenUI_TBUI_Billing_Account_Number,OpenUI_TBUI_Billing_Account_Number,"78678678");
			WA.VerifyElementPresentAndClick(OpenUI_TBUI_Billing_Account_Number_OK,OpenUI_TBUI_Billing_Account_Number_OK);
			WA.waitUntilElementClickable(OpenUI_TBUI_Billing_Account_Name);
			WA.VerifyElementPresentAndType(OpenUI_TBUI_Billing_Account_Name,OpenUI_TBUI_Billing_Account_Name,"TestC");
			Thread.sleep(WA.LOOP_TIMEOUT*1000);

			orderNo = WA.VerifyElementPresentAndGetAttribute(OpenUI_TBUI_OrderID,"value");
			RowID = WA.VerifyElementPresentAndGetAttribute(OpenUI_TBUI_CustomerRowID,"value");
			System.out.println("Order Number : "+orderNo);Report.fnReportInfo("ORDER ID == "+orderNo);
			System.out.println("RowID : "+RowID);Report.fnReportInfo("RowID  == "+RowID);
			WriteExcel.TestDataWriteDataExcel(orderNo,CustomerType,RowID,Report);

			WA.waitUntilElementClickable(OpenUI_TBUI_NextButton);
			WA.VerifyElementPresentAndClick(OpenUI_TBUI_NextButton,OpenUI_TBUI_NextButton);

			Report.fnReportPageBreak("Billing Page COMPLETE", driver);

		}catch(Exception exception) {
			exception.printStackTrace();
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage()+" Occured in Credit_Checkty Function",driver);
		}
		return(orderNo+","+RowID);
	}

	public void PauseOrder() {
		WA.waitUntilElementClickable(OpenUI_TBUI_PauseButton);
		WA.VerifyElementPresentAndClick(OpenUI_TBUI_PauseButton,OpenUI_TBUI_PauseButton);
	}

	public void ApproveCreditCheck(String OrderID) {

	}

	public void Plan_Selection(Multimap<String, String> pLAN_MAP, String Connection_type) {
		try {

			WA.waitUntilElementClickable(OpenUI_TBUI_Proposition_Add);
			SRF.GetSRFDetails("Plan Proposition Selection Page");
			WebDriverWait myDynamicElement = new WebDriverWait(driver, 120);
			String Prop = "";
			String Plan = "";
			int i = 1;
			Set keySet = pLAN_MAP.keySet();
			Iterator keyIterator = keySet.iterator();
			while (keyIterator.hasNext() ) {
				String key = (String) keyIterator.next();
				List<String> values = (List) pLAN_MAP.get( key );
				for(String plan_From_List : values) {
					Prop = key.toString();
					Plan = plan_From_List;
					System.out.println(Prop+"--"+plan_From_List);
					WriteExcel.TestDataWriteDataExcelPlan(Prop,plan_From_List,Report.CurrentRowOfExecution);
					Thread.sleep(1000);
					try{
						WA.waitUntilElementClickable(OpenUI_TBUI_Proposition_Add);

						WA.waitUntilElementClickable(OpenUI_TBUI_Proposition_Query);
						WA.VerifyElementPresentAndClick(OpenUI_TBUI_Proposition_Query,OpenUI_TBUI_Proposition_Query);

						WA.waitUntilElementClickable(OpenUI_TBUI_Proposition_Query_Type);
						WA.VerifyElementPresentAndType(OpenUI_TBUI_Proposition_Query_Type, OpenUI_TBUI_Proposition_Query_Type, Prop);


						WA.waitUntilElementClickable(OpenUI_TBUI_Proposition_Query_Go);
						WA.VerifyElementPresentAndClick(OpenUI_TBUI_Proposition_Query_Go,OpenUI_TBUI_Proposition_Query_Go);

						WA.waitUntilElementClickable(OpenUI_TBUI_Proposition_Add);
						WA.VerifyElementPresentAndClick(OpenUI_TBUI_Proposition_Add,OpenUI_TBUI_Proposition_Add);
						Thread.sleep(3000);


						//*********Check Properties**************************************

						if(i>=1)
						{
							WA.waitUntilElementClickable("//*[@id='"+i+"']/td[8]");
							driver.findElement(By.xpath("//*[@id='"+i+"']/td[8]")).click();

						}

						WA.waitUntilElementClickable(OpenUI_TBUI_Customize);
						WA.VerifyElementPresentAndClick(OpenUI_TBUI_Customize,OpenUI_TBUI_Customize);

						Thread.sleep(2000);


						//Selecting Plan
						WA.waitUntilElementClickable(OpenUI_DOMAINSELECT2);
						WA.VerifyElementPresentAndSelect(OpenUI_DOMAINSELECT2,OpenUI_DOMAINSELECT2, Plan);
						Thread.sleep(2000);

						//Data Option
						WA.waitUntilElementClickable(OpenUI_DataOption);
						WA.VerifyElementPresentAndClick(OpenUI_DataOption, OpenUI_DataOption);
						Thread.sleep(3000);			   

						//Raise Order
						WA.waitUntilElementClickable(OpenUI_RaiseOrder);
						WA.VerifyElementPresentAndClick(OpenUI_RaiseOrder,OpenUI_RaiseOrder); ;
						System.out.println("Raise Order button VerifyElementPresentAndClicked");

						//Sharing Selection
						String Sharing =DATA_MAP.get("SHARING");
						System.out.println("Sharing Required ?? : "+Sharing);
						if(Sharing.equalsIgnoreCase("No")){
							myDynamicElement.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='"+i+"']/td[contains(@id,'Sharing_Option')]/img")));
							myDynamicElement.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='"+i+"']/td[contains(@id,'Sharing_Option')]/img")));	
							driver.findElement(By.xpath("//*[@id='"+i+"']/td[contains(@id,'Sharing_Option')]/img")).click();
							System.out.println("Deselected Sharing");

						}else{
							System.out.println("Sharing Already Selected!!");
						}

						//Connection Type - SIM ONLY
						if(Connection_type.equalsIgnoreCase("SIM Only")){
							myDynamicElement.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='"+i+"']/td[8]/../td[6]")));
							myDynamicElement.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='"+i+"']/td[8]/../td[6]")));
							////							if(i>1){
							////								Thread.sleep(3000);
							////								driver.findElement(By.xpath("//*[@id='"+i+"']/td[8]/../td[7]")).click();
							////								System.out.println("VerifyElementPresentAndClicked Stock Indicator");
							////								Thread.sleep(2000);
							////								driver.findElement(By.xpath("//*[@id='"+i+"']/td[8]/../td[6]")).click();
							////								Thread.sleep(1000);
							////								driver.findElement(By.xpath("//*[@id='"+i+"_Connection_Type_icon']")).click();
							////								driver.findElement(By.xpath("//*[@id='"+i+"_Connection_Type']")).sendKeys(Keys.DOWN);
							////								driver.findElement(By.xpath("//*[@id='"+i+"_Connection_Type']")).sendKeys(Keys.DOWN);
							////								driver.findElement(By.xpath("//*[@id='"+i+"_Connection_Type']")).sendKeys(Keys.ENTER);
							////							}
							//							driver.findElement(By.xpath("//*[@id='"+i+"']/td[8]/../td[6]")).click();
							//							System.out.println("VerifyElementPresentAndClicked Connection Type ");
							//							driver.findElement(By.xpath("//*[@id='"+i+"_Connection_Type']")).clear();
							//							driver.findElement(By.xpath("//*[@id='"+i+"_Connection_Type']")).sendKeys(Connection_type);
							//							System.out.println("Typed Connection type: " + Connection_type);
							//							Thread.sleep(1000);
							//							driver.findElement(By.xpath("//*[@id='"+i+"_Connection_Type']")).sendKeys(Keys.ENTER);

							System.out.println("VerifyElementPresentAndClicked Connection Type ");
							WA.waitUntilElementClickable("//*[@id='"+i+"_Connection_Type']");
							driver.findElement(By.xpath("//*[@id='"+i+"_Connection_Type']")).clear();
							driver.findElement(By.xpath("//*[@id='"+i+"_Connection_Type']")).sendKeys(Connection_type);
							System.out.println("Typed Connection type: " + Connection_type);
							driver.findElement(By.xpath("//*[@id='"+i+"_Connection_Type']")).sendKeys(Keys.ENTER);

						}

						//Connection Type - PLAN AND DEVICE
						if(Connection_type.equalsIgnoreCase("Plan and Device")){
							String IMEI =WriteExcel.GET_IMEI_SIM_DETAILS("IMEI"); 
							WA.waitUntilElementClickable("//*[@id='"+i+"']/td[contains(@aria-labelledby,'VF_IMEI_TBUI')]");
							driver.findElement(By.xpath("//*[@id='"+i+"']/td[contains(@aria-labelledby,'VF_IMEI_TBUI')]")).click();
							System.out.println("VerifyElementPresentAndClicked IMEI");
							driver.findElement(By.xpath("//*[@id='"+i+"_VF_IMEI_TBUI']")).sendKeys(IMEI);
							Report.fnReportInfo("Typed IMEI : " + IMEI);
							Thread.sleep(1000);
							driver.findElement(By.xpath("//*[@id='"+i+"_VF_IMEI_TBUI']")).sendKeys(Keys.TAB);
						}


						//SIM Selection					
						String SIM = WriteExcel.GET_IMEI_SIM_DETAILS("SIM"); 
						WA.waitUntilElementClickable("//*[@id='"+i+"']/td[contains(@aria-labelledby,'VF_SIM_TBUI')]");
						driver.findElement(By.xpath("//*[@id='"+i+"']/td[contains(@aria-labelledby,'VF_SIM_TBUI')]")).click();
						System.out.println("VerifyElementPresentAndClicked SIM");
						driver.findElement(By.xpath("//*[@id='"+i+"_VF_SIM_TBUI']")).sendKeys(SIM);
						Report.fnReportInfo("Typed SIM : " + SIM);
						int count_alert=-1;
						Thread.sleep(1000);
						driver.findElement(By.xpath("//*[@id='"+i+"_VF_SIM_TBUI']")).sendKeys(Keys.TAB);

						do{
							boolean alertpresent= WA.isAlertPresent();
							if(alertpresent==true){
								
								System.out.println("Alert present and the value is:  "+alertpresent);
								WA.isAlertPresent();
								count_alert++;
								System.out.println("value of count_alert"+count_alert);
								SIM =  WriteExcel.GET_IMEI_SIM_DETAILS("SIM"); 
								driver.findElement(By.xpath("//*[@id='"+i+"']/td[contains(@aria-labelledby,'VF_SIM_TBUI')]")).click();
								System.out.println("VerifyElementPresentAndClicked SIM");

								driver.findElement(By.xpath("//*[@id='"+i+"_VF_SIM_TBUI']")).sendKeys(SIM);
								System.out.println("Typed SIM : " + SIM);
								Thread.sleep(1000);
								driver.findElement(By.xpath("//*[@id='"+i+"_VF_SIM_TBUI']")).sendKeys(Keys.TAB);
							}else{
								System.out.println("SIM Allocated Successfully!!");
								break;
							}

						}while (count_alert<=5);


						//MSISDN SELECTION
//						String MSISDN = WriteExcel.GET_IMEI_SIM_DETAILS("MSISDN"); 
						driver.findElement(By.xpath("//*[@id='"+i+"']/td[contains(@aria-labelledby,'VF_MSISDN_TBUI')]")).click();
						Thread.sleep(1000);
						driver.findElement(By.xpath("//*[@id='"+i+"_VF_MSISDN_TBUI_icon']")).click();
						System.out.println("VerifyElementPresentAndClicked MSISDN Search");
						Thread.sleep(3000);
						driver.findElement(By.xpath("//*[@title-preserved='New MSISDN']//*[@id='1']/td[2]")).click();
						System.out.println("VerifyElementPresentAndClicked MSISDN - Search popup");
						Thread.sleep(1000);
						driver.findElement(By.xpath("//*[@id='1_MSISDN']")).sendKeys("614*");
						System.out.println("Typed 614*");

						WA.VerifyElementPresentAndClick(OpenUI_TBUI_MSISDN_Go,OpenUI_TBUI_MSISDN_Go);
						WA.waitUntilElementClickable(OpenUI_TBUI_MSISDN_Pick);	
						WA.VerifyElementPresentAndClick(OpenUI_TBUI_MSISDN_Pick,OpenUI_TBUI_MSISDN_Pick);

						//Notification MSISDN
						if(i>=2){
							WA.VerifyElementPresentAndClick(OpenUI_TBUI_Notification_MSISDN_mark,OpenUI_TBUI_Notification_MSISDN_mark);
						}

					}catch(Exception exception){
						exception.printStackTrace();
						System.out.println("\n Xpath : " + i + " - Not Available!!.. Continuing... ");
						ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
						}.getClass().getEnclosingMethod().getName(), exception.getMessage()+" Occured in Credit_Checkty Function",driver);
					}
					i++;
				}

			}

//			WA.waitUntilElementClickable(OpenUI_TBUI_NextButton);	
//			WA.VerifyElementPresentAndClick(OpenUI_TBUI_NextButton,OpenUI_TBUI_NextButton);
		}catch(Exception exception) {
			exception.printStackTrace();
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage()+" Occured in Propoisition Selection Function",driver);
		}
	}

	public void ManagePaymentPlan() {
		if(WA.elementExists(OpenUI_TBUI_MPP_Title, WA.LARGE_TIMEOUT)) {
			int counter = 1;
			while(WA.elementExists("//td[contains(@id,'"+counter+"_Outline_Number')]", WA.LARGE_TIMEOUT)) {
				WA.VerifyElementPresentAndClick("//td[contains(@id,'"+counter+"_Outline_Number')]", "MPP Line Item");
				WA.VerifyElementPresentAndType(OpenUI_TBUI_MPP_ContractMonths, "OpenUI_TBUI_MPP_ContractMonths", "12");
				counter++;
			}

		}

	}

	public void SharingSetup(String Sharing) {
		try {

			System.out.println("Sharing Required?? : "+Sharing);
			if(Sharing.equalsIgnoreCase("Yes")){
				WA.waitUntilElementClickable(OpenUI_TBUI_External_Reference);	
				WA.VerifyElementPresentAndClick(OpenUI_TBUI_Selection_Group_Label,OpenUI_TBUI_Selection_Group_Label);
				WA.VerifyElementPresentAndClick(OpenUI_TBUI_Edit_Group_Name,OpenUI_TBUI_Edit_Group_Name);
				WA.VerifyElementPresentAndType(OpenUI_TBUI_Edit_Group_Name,OpenUI_TBUI_Edit_Group_Name,"Work");

				WA.waitUntilElementClickable(OpenUI_TBUI_NextButton);
				WA.VerifyElementPresentAndClick(OpenUI_TBUI_NextButton,OpenUI_TBUI_NextButton);
			}
		}catch(Exception exception) {
			exception.printStackTrace();
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage()+" Occured in Credit_Checkty Function",driver);
		}
	}

	public void OrderSubmission() {
		WA.waitUntilElementClickable(OpenUI_TBUI_Generate_Contract);	
		WA.VerifyElementPresentAndClick(OpenUI_TBUI_Generate_Contract,OpenUI_TBUI_Generate_Contract);
		WA.VerifyElementPresentAndClick(OpenUI_TBUI_Paperless_Reason,OpenUI_TBUI_Paperless_Reason);
		WA.VerifyElementPresentAndType(OpenUI_TBUI_Paperless_Reason,OpenUI_TBUI_Paperless_Reason,"Manual Signature Requested");
		//Include Generate contract PDF if required!!
		WA.waitUntilElementClickable(OpenUI_TBUI_Submit);
		WA.VerifyElementPresentAndClick(OpenUI_TBUI_Submit,OpenUI_TBUI_Submit);
		//Include Validation after submitting the Order

	}






}
