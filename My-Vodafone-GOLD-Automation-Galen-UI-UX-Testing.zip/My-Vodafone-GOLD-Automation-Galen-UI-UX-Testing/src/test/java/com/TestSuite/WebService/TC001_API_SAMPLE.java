package com.TestSuite.WebService;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import com.Engine.LoadEnvironment;
import com.Engine.Reporter;
import com.Engine.SeleniumSetup;
import com.SharedModules.Constants;
import com.Utils.DataProviderExcelReader;
import com.WebService.REST;
import com.relevantcodes.extentreports.LogStatus;


public class TC001_API_SAMPLE extends SeleniumSetup implements Constants {

	@DataProvider(name = "TC001_API_SAMPLE",parallel=true)
	public Object[][] DATA() throws Exception {
		DataProviderExcelReader DP = new DataProviderExcelReader();
		return DP.getExcelData(InputSheet, LoadEnvironment.EnvironmentDataMap.get("API"),"TC001_API_SAMPLE"); // Get data object
	}

	//TESTCASE
	@Test(groups = { "SalesRegression" }, dataProvider = "TC001_API_SAMPLE", invocationCount=1,threadPoolSize=50)
	public void TC001_API_SAMPLE_TestCase(String SCRIPT_ID, String ROW) throws Exception {

		/******************MANDATORY FUNCTION DON NOT DELETE*******************************/
		Map<String, String> DATA_MAP = CreateDataMap(ROW, InputSheet, LoadEnvironment.EnvironmentDataMap.get("API"));
		Reporter TestReporter  = CreateReport(SCRIPT_ID, ROW,DATA_MAP.get("TEST CASE NAME"));
		/**********************************/
		 
		
		
		REST Rest = new REST(TestReporter);
		Map<String, String> HEADERS = new HashMap<String, String>();

		//Create Headers
		HEADERS.put("Content-Type", DATA_MAP.get("Content-Type"));
		HEADERS.put("x-api-key", DATA_MAP.get("x-api-key"));
		HEADERS.put("PLIB", DATA_MAP.get("PLIB"));

		TestReporter.fnReportPass("REQUEST URL IS "+DATA_MAP.get("URL"));
		TestReporter.fnReportPass("REQUEST METHOD IS "+DATA_MAP.get("METHOD"));
		TestReporter.fnReportPass("REQUEST HEADERS IS "+HEADERS);
		TestReporter.fnReportPass("REQUEST PRAMETERS IS "+ DATA_MAP.get("PARAMETERS"));

		Map<String,String> reposneMap = Rest.sendRESTRequest(DATA_MAP.get("URL"), DATA_MAP.get("METHOD"), HEADERS, DATA_MAP.get("PARAMETERS"));
		
		TestReporter.fnReportInfo("<b><strong>RESPONSE CODE OBTAINED FROM SERBER "+reposneMap.get("RESPONSE_CODE")+"</b></strong>");
		TestReporter.fnReportInfo("<b><strong>RESPONSE TYPE OBTAINED FROM SERVER IS "+reposneMap.get("RESPONSE_TYPE")+"</b></strong>");
		TestReporter.fnReportInfo("<b><strong>RESPONSE STRING OBTAINED FROM SERVER IS "+reposneMap.get("RESPONSE_MESSAGE")+"</b></strong>");





		//MANDATORY MODULE
		CloseReportsandDriver(TestReporter);

	}

	/******************MANDATORY FUNCTION DON NOT DELETE*******************************/
	@Override
	@AfterMethod
	public void tearDown() throws Exception {
		System.out.println("Tear down complete");

	}
	public static void CloseReportsandDriver(Reporter Report) {
		if (Report.TESTPASSED) {
			Report.ReporterLog("TEST PASSED", LogStatus.PASS);
		} else {
			Report.ReporterLog("TEST FAILED", LogStatus.FAIL);
		}
		if (System.getProperty("REPORT_APPEND") != null
				&& System.getProperty("REPORT_APPEND").equalsIgnoreCase("TRUE")) {
			// CommonStaticVariables.EXTENTTESTREPORT would be closed in
			// @AfterSuite
			Report.EXTENTTESTREPORT.endTest(Report.EXTENTTEST);
			Report.EXTENTTESTREPORT.flush();
		} else {
			Report.EXTENTTESTREPORT.endTest(Report.EXTENTTEST);
			Report.EXTENTTESTREPORT.flush();
			Report.EXTENTTESTREPORT.close();
		}
		
	}
	/**********************************/
}