package com.TestSuite.WebService;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import com.Engine.LoadEnvironment;
import com.Engine.Reporter;
import com.Engine.SeleniumSetup;
import com.SharedModules.Constants;
import com.Utils.DataProviderExcelReader;
import com.Utils.Reusables;
import com.WebService.REST;
import com.relevantcodes.extentreports.LogStatus;


public class TC002_API_With_Template extends SeleniumSetup implements Constants {

	@DataProvider(name = "TC001_API_SAMPLE",parallel=true)
	public Object[][] DATA() throws Exception {
		DataProviderExcelReader DP = new DataProviderExcelReader();
		return DP.getExcelData(InputSheet, LoadEnvironment.EnvironmentDataMap.get("API"),"TC001_API_SAMPLE"); // Get data object
	}

	//TESTCASE
	@Test(groups = { "SalesRegression" }, dataProvider = "TC001_API_SAMPLE", invocationCount=1,threadPoolSize=50)
	public void TC001_API_SAMPLE_TestCase(String SCRIPT_ID, String ROW) throws Exception {

		/******************MANDATORY FUNCTION DON NOT DELETE*******************************/
		Map<String, String> DATA_MAP = CreateDataMap(ROW, InputSheet, LoadEnvironment.EnvironmentDataMap.get("API"));
		Reporter TestReporter  = CreateReport(SCRIPT_ID, ROW,DATA_MAP.get("TEST CASE NAME"));TestReporter.TestType="TESTDATA";
		/**********************************/

		REST Rest = new REST(TestReporter);
		Map<String, String> HEADERS = new HashMap<String, String>();
		Map<String, String> VALIDATIONS = new HashMap<String, String>();
		boolean noTemplate=true;String Parameters = "";

		//Retrive Template
		if(!DATA_MAP.get("TemplateName").equalsIgnoreCase("NA")) {
			Parameters = Reusables.GetFileContents(System.getProperty("user.dir")+"/Templates/"+DATA_MAP.get("TemplateName"));
			noTemplate = false;
		}else {
			System.err.println(DATA_MAP.get("TemplateName"));
		}

		//Create Header and Parameter Map
		for (Map.Entry<String, String> entry : DATA_MAP.entrySet())		{
			if(entry.getKey().startsWith("HEADER_")) {
				HEADERS.put(entry.getKey().substring(7),entry.getValue());
			}
			if(entry.getKey().startsWith("PARAMETER_") && (!entry.getValue().equalsIgnoreCase("NA"))) {
				//Create Body Content
				if(noTemplate==true) {
					Parameters = Parameters+entry.getKey().substring(10)+"="+ entry.getValue()+"&";
				}else {
					Parameters = Parameters.replaceAll("<<"+entry.getKey().substring(10)+">>", entry.getValue());
				}
			}

			if(entry.getKey().startsWith("VALIDATION_") && (!entry.getValue().equalsIgnoreCase("NA"))) {
				VALIDATIONS.put(entry.getKey().substring(11),entry.getValue());
			}
		}

		//Trim Paramters
		if((noTemplate==true) &&(!Parameters.equalsIgnoreCase("")) &&(Parameters!=null)) {
			Parameters = Parameters.substring(0, Parameters.length()-1);
		}else {
			System.err.println("IN NOTEM<PLATE IS FALSE");
			System.out.println(Parameters);
			//Parameters = Parameters.trim();
		}


		TestReporter.fnReportPass("REQUEST URL IS "+DATA_MAP.get("URL"));
		TestReporter.fnReportPass("REQUEST METHOD IS "+DATA_MAP.get("METHOD"));
		TestReporter.fnReportPass("REQUEST HEADERS IS "+HEADERS);
		TestReporter.fnReportPass("REQUEST PRAMETERS IS "+ Parameters);


		Map<String,String> reposneMap = Rest.sendRESTRequest(DATA_MAP.get("URL"), DATA_MAP.get("METHOD"), HEADERS, DATA_MAP.get("PARAMETERS"));
		TestReporter.fnReportInfo("<b><strong>RESPONSE CODE OBTAINED FROM SERBER "+reposneMap.get("RESPONSE_CODE")+"</b></strong>");
		TestReporter.fnReportInfo("<b><strong>RESPONSE TYPE OBTAINED FROM SERVER IS "+reposneMap.get("RESPONSE_TYPE")+"</b></strong>");
		TestReporter.fnReportInfo("<b><strong>RESPONSE STRING OBTAINED FROM SERVER IS "+reposneMap.get("RESPONSE_MESSAGE")+"</b></strong>");



		//Validations
		for (Map.Entry<String, String> entry : VALIDATIONS.entrySet()){
			String KeyValPair[] = entry.getValue().split("\\|");
			String reportingValidationHeader = entry.getKey();

			if(Rest.RestValidation(reposneMap.get("RESPONSE_MESSAGE"), KeyValPair[0], KeyValPair[1]))
				//if(Rest.RestValidation(Parameters, KeyValPair[0], KeyValPair[1]))
				TestReporter.fnReportPass("<b>Validation : "+reportingValidationHeader +"is present with value " + KeyValPair[1] + " in the response</b>");
			else
				TestReporter.fnReportFail("<b><font color=red> Validation : "+reportingValidationHeader +"is NOT present with value " + KeyValPair[1] + " in the response</font></b>");

		}


		//MANDATORY MODULE
		CloseReportsandDriver(TestReporter);

	}

	/******************MANDATORY FUNCTION DON NOT DELETE*******************************/
	@Override
	@AfterMethod
	public void tearDown() throws Exception {
		System.out.println("Tear down complete");

	}
	public static void CloseReportsandDriver(Reporter Report) {
		if (Report.TESTPASSED) {
			Report.ReporterLog("TEST PASSED", LogStatus.PASS);
		} else {
			Report.ReporterLog("TEST FAILED", LogStatus.FAIL);
		}
		if (System.getProperty("REPORT_APPEND") != null
				&& System.getProperty("REPORT_APPEND").equalsIgnoreCase("TRUE")) {
			// CommonStaticVariables.EXTENTTESTREPORT would be closed in
			// @AfterSuite
			Report.EXTENTTESTREPORT.endTest(Report.EXTENTTEST);
			Report.EXTENTTESTREPORT.flush();
		} else {
			Report.EXTENTTESTREPORT.endTest(Report.EXTENTTEST);
			Report.EXTENTTESTREPORT.flush();
			Report.EXTENTTESTREPORT.close();
		}

	}
	/**********************************/
}