

package com.TestSuite.JAVASample;

import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.BusinessModules.Java.SampleModule;
import com.Engine.LoadEnvironment;
import com.Engine.SeleniumSetup;
import com.Enumerations.Generic.DesktopTabletMobile;
import com.SharedModules.Constants;
import com.Utils.DataProviderExcelReader;


public class SampleTestCase extends SeleniumSetup implements Constants {

	/**
	 * Data Provider returns SCRIPT_ID and ROW where the SCRIPT_ID exists in
	 * mentioned sheets
	 * 
	 * @return
	 * @throws Exception
	 */
	@DataProvider(name = "TC001",parallel=false)
	// Data Provider name
	public Object[][] DATA() throws Exception {
		
		DataProviderExcelReader DP = new DataProviderExcelReader();
		return DP.getExcelData(InputSheet, LoadEnvironment.EnvironmentDataMap.get("Samplesheet"),
				"TC001"); // Get data object
	}

	/**
	 * Test method name will be taken for Extent Report. Please mention a valid
	 * method name Test should contain TestPreProcessing for driver and report
	 * instantiation
	 * 
	 * @return
	 * @throws Exception
	 */
	@Test(groups = { "SalesRegression" }, dataProvider = "TC001", singleThreaded=true)
	public void TC01SBBNewlinePostCodeOnly_(String SCRIPT_ID, String ROW) throws Exception {
		

		Map<String, String> DATA_MAP = TestPreProcessing(SCRIPT_ID, ROW, InputSheet,LoadEnvironment.EnvironmentDataMap.get("Samplesheet"));
		DesktopTabletMobile DTM = DesktopTabletMobile.valueOf(DATA_MAP.get("MODE").split("_")[0]);
		
	
		SampleModule SM = new SampleModule(driver, Report, DTM);
		
		Report.fnReportPass("TEST COMMENCED SUCCESSFULLY", driver);
		Report.fnReportInfo("TEST COMMENCED SUCCESSFULLY", driver);
		
		SM.SampleFunction();
		
		Report.fnReportPageBreak("TEST COMMENCED SUCCESSFULLY", driver);
		
		
		

	}

}