

package com.TestSuite.JAVASample;

import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.BusinessModules.Java.SampleModule;
import com.Engine.LoadEnvironment;
import com.Engine.SeleniumSetup;
import com.Enumerations.Generic.DesktopTabletMobile;
import com.SharedModules.Constants;
import com.Utils.DataProviderExcelReader;


public class TC002_Sample_Testcase extends SeleniumSetup implements Constants {

	/**
	 * Data Provider returns SCRIPT_ID and ROW where the SCRIPT_ID exists in
	 * mentioned sheets
	 * 
	 * @return
	 * @throws Exception
	 */
	@DataProvider(name = "TC002_Sample_Testcase",parallel=false)
	// Data Provider name
	public Object[][] DATA() throws Exception {
		DataProviderExcelReader DP = new DataProviderExcelReader();
		return DP.getExcelData(InputSheet, LoadEnvironment.EnvironmentDataMap.get("Samplesheet"),"TC002_Sample_Testcase"); // Get data object
	}

	/**
	 * Test method name will be taken for Extent Report. Please mention a valid
	 * method name Test should contain TestPreProcessing for driver and report
	 * instantiation
	 * 
	 * @return
	 * @throws Exception
	 */
	@Test(groups = { "SalesRegression" }, dataProvider = "TC002_Sample_Testcase", singleThreaded=true)
	public void TC002_Sample_Testcase_TestCase(String SCRIPT_ID, String ROW) throws Exception {
		/****************************/
		//Objects and Data Map
		Map<String, String> DATA_MAP = TestPreProcessing(SCRIPT_ID, ROW, InputSheet,LoadEnvironment.EnvironmentDataMap.get("Samplesheet"));
		DesktopTabletMobile DTM = DesktopTabletMobile.valueOf(DATA_MAP.get("MODE").split("_")[0]);

		SampleModule SM = new SampleModule(driver, Report, DTM);
		/****************************/


		SM.Navigate_To_URL("http://www.seleniumhq.org/");

		SM.Click_Projects_Tab();

		SM.Click_Download_Tab();

		SM.Click_Documentation_Tab();

		SM.Search(DATA_MAP.get("SEARCHDATA"));

		SM.ClickGoButton();






	}

}