package com.TestSuite.RWDTesting;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.Engine.CommonStaticVariables;
import com.Engine.Reporter;
import com.Engine.SeleniumSetup;
import com.SharedModules.Constants;
import com.WebActions.WebActions;
import com.galenframework.api.GalenPageDump;
import com.galenframework.config.GalenConfig;
import com.galenframework.reports.HtmlReportBuilder;
import com.relevantcodes.extentreports.LogStatus;


public class TC013_PospaidAllUsages_DetailedUsages_Complex extends SeleniumSetup implements Constants {

	/**
	 * Test method name will be taken for Extent Report. Please mention a valid
	 * method name Test should contain TestPreProcessing for driver and report
	 * instantiation
	 * 
	 * @return
	 * @throws Exception
	 */
	@Test(groups = { "SalesRegression" }, invocationCount=1,threadPoolSize=3)
	public void TC001_Sample_Testcase_TestCase() throws Exception {

		/******************MANDATORY FUNCTION DON NOT DELETE*******************************/

		Reporter TestReporter  = CreateReport("SPEC_CHECK_001", "1","SPEC_CHECK_001");TestReporter.TestType="TESTDATA";
		WebDriver TestDriver = CreateDriver("CHROME", TestReporter, "", set_ModeResolution("DESKTOP"));
		System.setProperty("galen.config.file",GalenConfigFile);
		/**********************************/
		//Objects
		WebActions WA = new WebActions(TestDriver, TestReporter);

		/******************************************************/
		//Login
		TestDriver.get("https://env02.sit.my.services.vodafone.com.au");
		WA.VerifyElementPresentAndType("//input[@id='userid']", "USER ID", "61402139217");
		WA.VerifyElementPresentAndType("//input[@id='password']", "password", "Password@1");
		WA.VerifyElementPresentAndClick("//input[@id='loginButton']", "Login Button");

		//NAVIGATION -1 to Purchase Page
		TestDriver.get("https://env02.sit.my.services.vodafone.com.au/datausage");
		Thread.sleep(20000);
	//	WA.waitUntilPageReady();
		WA.waitUntilElementClickable("//div[contains(text(),'View detailed usage')]/parent::button[1],'View detailed usage')]");
//		WA.waitUntilElementClickable("//button[contains(text(),'Browse Add-ons and Boosters')]");
//		WA.waitUntilElementClickable("//div[contains(text(),'Swap my SIM')]");
		//WA.SpecCheck("Product and services Page", true, "Products_Services_Your_Plan_Summary_landingpage.gspec", DeviceList_Array); // Galen Test	
		//WA.SpecCheck("Data usage detail", true, "PostpaidAllUsages_DetailedUsage_ComplexSharing.gspec", DeviceList_Array); // Galen Test

				//View detailed usage
				WA.VerifyElementPresentAndClick("//div[contains(text(),'View detailed usage')]/parent::button[1]", "View detailed usage");
				WA.waitUntilElementClickable("//*[@id=\"app\"]/div/div/section/div/div[1]/div[1]/div[1]");
				WA.SpecCheck("Detailed usage Page after clicking View detailed usage -1",true, false, "PostpaidAllUsages_DetailedUsage_ComplexSharing.gspec", DeviceList_Array); // Galen Test	
		//	
		//		//show more
		//		WA.VerifyElementPresentAndClick("//*[@id=\"app\"]/div/section/div/div/div/div/div[2]/button[1]", "Show more");
		//		WA.VerifyElementNotPresent("//button[contains(text(),'Show more')]", "Show more");
		//		WA.SpecCheck("Purchase History Page after clicking show more -2", false, "Purchase_History_Positive Scenario_past_3months.gspec", DeviceList_Array); // Galen Test	

		//expand chevron

//		for(WebElement W : WA.VerifyElementPresentAndGetElementList("//div[starts-with(@class,'accordion')]//div[starts-with(@style,'color')]")) 
//			//WA.VerifyElementPresentAndClick("//div[starts-with(@class,'accordion')]//div[starts-with(@style,'color')]", "chevron");
//			W.click();
//		WA.SpecCheck("Purchase History Page", false, "PurchaseHistory_Positive_Purchasedetails.gspec", DeviceList_Array); // Galen Test

		/******************MANDATORY FUNCTION DON NOT DELETE*******************************/
		CloseReportsandDriver(TestDriver,TestReporter);
		/**********************************/
	}


	/******************MANDATORY FUNCTION DON NOT DELETE*******************************/
	@Override
	@AfterMethod
	public void tearDown() throws Exception {
		System.out.println("Tear down complete");

	}
	public static void CloseReportsandDriver(WebDriver driver, Reporter Report) throws IOException {
		if (Report.TESTPASSED) {
			Report.ReporterLog("TEST PASSED", LogStatus.PASS);
		} else {
			Report.ReporterLog("TEST FAILED", LogStatus.FAIL);
		}
		if (System.getProperty("REPORT_APPEND") != null
				&& System.getProperty("REPORT_APPEND").equalsIgnoreCase("TRUE")) {
			// CommonStaticVariables.EXTENTTESTREPORT would be closed in
			// @AfterSuite
			Report.EXTENTTESTREPORT.endTest(Report.EXTENTTEST);
			Report.EXTENTTESTREPORT.flush();
		} else {
			Report.EXTENTTESTREPORT.endTest(Report.EXTENTTEST);
			Report.EXTENTTESTREPORT.flush();
			Report.EXTENTTESTREPORT.close();
		}

		// Closing and Quitting the Driver instance
		if (driver != null) {
			driver.close();driver.quit();
		} else {
			System.out.println(
					Report.CurrentRowOfExecution + "   --------------------DRIVER IS NULL----------------------");
		}
		//Galen Report
		try{
			new HtmlReportBuilder().build(Report.GALENTEST, CommonStaticVariables.CurrentReportingLocation+"/TC006_PurchaseHistory_Positive");//Changed
		}catch(Exception exception) {
			exception.printStackTrace();
		}
	}
	/**********************************/
}