package com.TestSuite.RWDTesting;

public class TEMP {

	public static void main(String[] args) {
		int i=0;int j =0;
		String[] A = {"H1","H2","H3"};
		String SPACE = "   ";
		for(i=0;i<3;i++) {
			for(j=0;j<3;j++) {
				if((i==1&&j==1)||(i==1&&j==2)||(i==2&&j==1)||(i==2&&j==2)) {
					System.out.print(SPACE+"  |");
				}else {
					if(j==0)
						System.out.print(A[i]+SPACE+"|");
					else
						System.out.print(A[j]+SPACE+"|");		
				}

			}
			System.out.println();System.out.print("_______________");System.out.println();

		}


	}

}
