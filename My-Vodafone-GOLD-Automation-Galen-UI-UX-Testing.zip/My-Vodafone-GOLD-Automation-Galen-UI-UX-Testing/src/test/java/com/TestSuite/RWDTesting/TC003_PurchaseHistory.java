package com.TestSuite.RWDTesting;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.Engine.CommonStaticVariables;
import com.Engine.Reporter;
import com.Engine.SeleniumSetup;
import com.SharedModules.Constants;
import com.WebActions.WebActions;
import com.galenframework.api.GalenPageDump;
import com.galenframework.config.GalenConfig;
import com.galenframework.reports.HtmlReportBuilder;
import com.relevantcodes.extentreports.LogStatus;


public class TC003_PurchaseHistory extends SeleniumSetup implements Constants {

	/**
	 * Test method name will be taken for Extent Report. Please mention a valid
	 * method name Test should contain TestPreProcessing for driver and report
	 * instantiation
	 * 
	 * @return
	 * @throws Exception
	 */
	@Test(groups = { "SalesRegression" }, invocationCount=1,threadPoolSize=3)
	public void TC001_Sample_Testcase_TestCase() throws Exception {

		/******************MANDATORY FUNCTION DON NOT DELETE*******************************/

		Reporter TestReporter  = CreateReport("SPEC_CHECK_001", "1","SPEC_CHECK_001");TestReporter.TestType="TESTDATA";
		WebDriver TestDriver = CreateDriver("CHROME", TestReporter, "", set_ModeResolution("DESKTOP"));

		/**********************************/
		//Objects
		WebActions WA = new WebActions(TestDriver, TestReporter);
		String GalenConfigFile = System.getProperty("user.dir")+"/PropertyFiles/GenericProperties/GalenConfig.properties";
		/******************************************************/
		//Login
		TestDriver.get("https://env02.sit.my.services.vodafone.com.au");
		WA.VerifyElementPresentAndType("//input[@id='userid']", "USER ID", "61402141404");
		WA.VerifyElementPresentAndType("//input[@id='password']", "password", "Password@1");
		WA.VerifyElementPresentAndClick("//input[@id='loginButton']", "Login Button");
		TestDriver.get("http://env02.sit.my.services.vodafone.com.au/purchase");
		WA.waitUntilElementClickable("//button[contains(text(),'Show more')]");

		//Galen Test
		System.setProperty("galen.config.file",GalenConfigFile);
		GalenConfig GC = GalenConfig.getConfig();
		System.out.println(GC.getProperties());
		WA.SpecCheck("Purchase History_Desktop1_Negative Scenario.gspec", DeviceList.split(","));

		//Page Dump
		try {
			String SpecPage = System.getProperty("user.dir")+"/Specification/Purchase History_Desktop1_Negative Scenario.gspec";
			String ReportLocation = CommonStaticVariables.CurrentReportingLocation+"/Purchase History_Desktop1_Negative_Scenario";
			GalenPageDump GPD = new GalenPageDump("USAGE_HISTORY");
			GPD.dumpPage(TestDriver,SpecPage,ReportLocation);
		}catch(Exception e){
			e.printStackTrace();
		}

		/******************MANDATORY FUNCTION DON NOT DELETE*******************************/
		CloseReportsandDriver(TestDriver,TestReporter);
		/**********************************/

	}


	/******************MANDATORY FUNCTION DON NOT DELETE*******************************/
	@Override
	@AfterMethod
	public void tearDown() throws Exception {
		System.out.println("Tear down complete");

	}
	public static void CloseReportsandDriver(WebDriver driver, Reporter Report) throws IOException {
		if (Report.TESTPASSED) {
			Report.ReporterLog("TEST PASSED", LogStatus.PASS);
		} else {
			Report.ReporterLog("TEST FAILED", LogStatus.FAIL);
		}
		if (System.getProperty("REPORT_APPEND") != null
				&& System.getProperty("REPORT_APPEND").equalsIgnoreCase("TRUE")) {
			// CommonStaticVariables.EXTENTTESTREPORT would be closed in
			// @AfterSuite
			Report.EXTENTTESTREPORT.endTest(Report.EXTENTTEST);
			Report.EXTENTTESTREPORT.flush();
		} else {
			Report.EXTENTTESTREPORT.endTest(Report.EXTENTTEST);
			Report.EXTENTTESTREPORT.flush();
			Report.EXTENTTESTREPORT.close();
		}

		// Closing and Quitting the Driver instance
		if (driver != null) {
			driver.close();driver.quit();
		} else {
			System.out.println(
					Report.CurrentRowOfExecution + "   --------------------DRIVER IS NULL----------------------");
		}
		//Galen Report
		try{
			new HtmlReportBuilder().build(Report.GALENTEST, CommonStaticVariables.CurrentReportingLocation+"/TC003_PurchaseHistory/galen-html-reports");
		}catch(Exception exception) {
			exception.printStackTrace();
		}
	}
	/**********************************/
}