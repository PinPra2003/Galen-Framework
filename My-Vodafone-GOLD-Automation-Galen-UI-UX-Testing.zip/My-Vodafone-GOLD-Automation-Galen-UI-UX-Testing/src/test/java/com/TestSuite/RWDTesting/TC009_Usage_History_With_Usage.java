package com.TestSuite.RWDTesting;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.Engine.CommonStaticVariables;
import com.Engine.Reporter;
import com.Engine.SeleniumSetup;
import com.SharedModules.Constants;
import com.WebActions.WebActions;
import com.galenframework.api.GalenPageDump;
import com.galenframework.config.GalenConfig;
import com.galenframework.reports.HtmlReportBuilder;
import com.relevantcodes.extentreports.LogStatus;


public class TC009_Usage_History_With_Usage extends SeleniumSetup implements Constants {

	/**
	 * Test method name will be taken for Extent Report. Please mention a valid
	 * method name Test should contain TestPreProcessing for driver and report
	 * instantiation
	 * 
	 * @return
	 * @throws Exception
	 */
	@Test(groups = { "SalesRegression" }, invocationCount=1,threadPoolSize=3)
	public void TC001_Sample_Testcase_TestCase() throws Exception {
		WebActions WA = null;
		/******************MANDATORY FUNCTION DON NOT DELETE*******************************/

		Reporter TestReporter  = CreateReport("SPEC_CHECK_001", "1","SPEC_CHECK_001");TestReporter.TestType="TESTDATA";
		WebDriver TestDriver = CreateDriver("CHROME", TestReporter, "", set_ModeResolution("DESKTOP"));
		System.setProperty("galen.config.file",GalenConfigFile);
		
		System.out.println(TestReporter);
		System.out.println(TestDriver);
		/**********************************/
		//Objects
		try{ WA = new WebActions(TestDriver, TestReporter);}catch(Exception e) {
			e.printStackTrace();
		}
		/******************************************************/
		//Login
		TestDriver.get("https://env02.sit.my.services.vodafone.com.au");
		WA.VerifyElementPresentAndType("//input[@id='userid']", "USER ID", "61402140708"); //change username accordingly
		WA.VerifyElementPresentAndType("//input[@id='password']", "password", "Password@1"); //change password accordingly
		WA.VerifyElementPresentAndClick("//input[@id='loginButton']", "Login Button");
		/**************/
		
		TestDriver.get("https://env02.sit.my.services.vodafone.com.au/usage");//change username accordingly
		WA.waitUntilElementClickable("//div[contains(@class,'usagehistory-dropdown')]");//change username accordingly
	
		/****************************ONLY CHANGE THIS******************************************************/
		//WA.SpecCheck("Customer With Usage", false, "Usage history with usage.gspec", DeviceList_Array); // Galen Test	
		
		
		for(WebElement W : WA.VerifyElementPresentAndGetElementList("//div[@class='usage-chevron-heigth flex flex-2 align-center']/div/following-sibling::div[position()=2]"))
			W.click();
		WA.SpecCheck("Customer With Usage", true,false, "Usage history with usage.gspec", DeviceList_Array); // Galen Test
		/**************************************************************************************************/

		/******************MANDATORY FUNCTION DON NOT DELETE*******************************/
		CloseReportsandDriver(TestDriver,TestReporter);
		/**********************************/

	}


	/******************MANDATORY FUNCTION DON NOT DELETE*******************************/
	@Override
	@AfterMethod
	public void tearDown() throws Exception {
		System.out.println("Tear down complete");

	}
	public static void CloseReportsandDriver(WebDriver driver, Reporter Report) throws IOException {
		if (Report.TESTPASSED) {
			Report.ReporterLog("TEST PASSED", LogStatus.PASS);
		} else {
			Report.ReporterLog("TEST FAILED", LogStatus.FAIL);
		}
		if (System.getProperty("REPORT_APPEND") != null
				&& System.getProperty("REPORT_APPEND").equalsIgnoreCase("TRUE")) {
			// CommonStaticVariables.EXTENTTESTREPORT would be closed in
			// @AfterSuite
			Report.EXTENTTESTREPORT.endTest(Report.EXTENTTEST);
			Report.EXTENTTESTREPORT.flush();
		} else {
			Report.EXTENTTESTREPORT.endTest(Report.EXTENTTEST);
			Report.EXTENTTESTREPORT.flush();
			Report.EXTENTTESTREPORT.close();
		}

		// Closing and Quitting the Driver instance
		if (driver != null) {
			driver.close();driver.quit();
		} else {
			System.out.println(
					Report.CurrentRowOfExecution + "   --------------------DRIVER IS NULL----------------------");
		}
		//Galen Report
		try{
			new HtmlReportBuilder().build(Report.GALENTEST, CommonStaticVariables.CurrentReportingLocation+"/TC002_Usage_History");
		}catch(Exception exception) {
			exception.printStackTrace();
		}
	}
	/**********************************/
}