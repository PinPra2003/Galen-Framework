package com.TestSuite.TestData;

import java.io.IOException;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.BusinessModules.Cucumber.Steps.OpenUI.GetSRF;
import com.BusinessModules.Cucumber.Steps.OpenUI.LoginPage;
import com.BusinessModules.Cucumber.Steps.OpenUI.TBUI_Flow;
import com.Engine.CommonStaticVariables;
import com.Engine.ExceptionHandlers;
import com.Engine.LoadEnvironment;
import com.Engine.Reporter;
import com.Engine.SeleniumSetup;
import com.SharedModules.Constants;
import com.Utils.DataProviderExcelReader;
import com.Utils.ReadExcelSheet;
import com.galenframework.reports.HtmlReportBuilder;
import com.google.common.collect.Multimap;
import com.relevantcodes.extentreports.LogStatus;


public class TC001_OpenUI_TBUI extends SeleniumSetup implements Constants {

	/**
	 * Data Provider returns SCRIPT_ID and ROW where the SCRIPT_ID exists in
	 * mentioned sheets
	 * 
	 * @return
	 * @throws Exception
	 */
	@DataProvider(name = "TC001_Sample_Testcase",parallel=true)
	// Data Provider name
	public Object[][] DATA() throws Exception {
		DataProviderExcelReader DP = new DataProviderExcelReader();
		return DP.getExcelData(InputSheet_TestData, LoadEnvironment.EnvironmentDataMap.get("TestData_Scenarios"),"TC001_Sample_Testcase"); // Get data object
	}

	/**
	 * Test method name will be taken for Extent Report. Please mention a valid
	 * method name Test should contain TestPreProcessing for driver and report
	 * instantiation
	 * 
	 * @return
	 * @throws Exception
	 */
	@Test(groups = { "SalesRegression" }, dataProvider = "TC001_Sample_Testcase", invocationCount=1,threadPoolSize=3)
	public void TC001_Sample_Testcase_TestCase(String SCRIPT_ID, String ROW) throws Exception {

		/******************MANDATORY FUNCTION DON NOT DELETE*******************************/

		Map<String, String> DATA_MAP = CreateDataMap(ROW, InputSheet_TestData, LoadEnvironment.EnvironmentDataMap.get("TestData_Scenarios"));
		Reporter TestReporter  = CreateReport(SCRIPT_ID, ROW,DATA_MAP.get("TEST CASE NAME"));TestReporter.TestType="TESTDATA";
		WebDriver TestDriver = CreateDriver(DATA_MAP.get("BROWSER"), TestReporter, "", set_ModeResolution(DATA_MAP.get("MODE")));
		System.out.println("EXECUTING FROM " + ROW +" ROW WITH REPORTING " + TestReporter.toString());		
		/**********************************/
		//Objects
		LoginPage LP = new LoginPage(TestDriver, TestReporter, DATA_MAP);
		GetSRF SRF = new GetSRF(TestDriver, TestReporter, DATA_MAP);
		TBUI_Flow TBUI = new TBUI_Flow(TestDriver, TestReporter, DATA_MAP);
		Multimap<String, String> PLAN_MAP = null; 
		/******************************************************/

		if(DATA_MAP.get("MSO").equalsIgnoreCase("YES")) {
			try{PLAN_MAP=ReadExcelSheet.GetMSOMatrix(DATA_MAP.get("TEST_TYPE"), InputSheet_TestData, "MSO");}catch(Exception exception) {ExceptionHandlers.FinalExceptionHandler(TestReporter, new Object() {			}.getClass().getEnclosingMethod().getName(), exception.getMessage(),TestDriver);}
			System.out.println(PLAN_MAP);
		}else {
			try{PLAN_MAP=ReadExcelSheet.GetMSOMatrix(DATA_MAP.get("TEST_TYPE"), InputSheet_TestData, "SSO");}catch(Exception exception) {ExceptionHandlers.FinalExceptionHandler(TestReporter, new Object() {			}.getClass().getEnclosingMethod().getName(), exception.getMessage(),TestDriver);}
			System.out.println(PLAN_MAP);
		}

		//TEST CASE	
		LP.Navigate();
		LP.Login(LoadEnvironment.EnvironmentDataMap.get("USERNAME"), LoadEnvironment.EnvironmentDataMap.get("PASSWORD"));

		//customerDetails
		TBUI.CustomerDetails_TBUI(DATA_MAP.get("CUSTOMER SEGMENT"),DATA_MAP.get("BUSINESS CUSTOMER TYPE"),TESTDATA_SoletraderABN);

		//Add Identity 
		TBUI.Add_Identity();

		//ID Scan
		TBUI.ID_Scan();

		//Submit Credit check
		TBUI.Credit_Check(DATA_MAP.get("CUSTOMER SEGMENT"),DATA_MAP.get("BUSINESS CUSTOMER TYPE"));

		//Billing Options
		TBUI.Billing_Options(DATA_MAP.get("BUSINESS CUSTOMER TYPE"));


		//Plan Selection
		TBUI.Plan_Selection(PLAN_MAP,DATA_MAP.get("CONNECTION TYPE"));

		//MPP Page
		//TBUI.ManagePaymentPlan();

		//Pause Order 
		TBUI.PauseOrder();
				
				
		//		//Sharing Setup
		//		TBUI.SharingSetup(DATA_MAP.get("SHARING"));
		//
		//		//Order Submission
		//		TBUI.OrderSubmission();

		/******************MANDATORY FUNCTION DON NOT DELETE*******************************/
		CloseReportsandDriver(TestDriver,TestReporter);
		/**********************************/

	}


	/******************MANDATORY FUNCTION DON NOT DELETE*******************************/
	@Override
	@AfterMethod
	public void tearDown() throws Exception {
		System.out.println("Tear down complete");

	}
	public static void CloseReportsandDriver(WebDriver driver, Reporter Report) throws IOException {
		if (Report.TESTPASSED) {
			Report.ReporterLog("TEST PASSED", LogStatus.PASS);
		} else {
			Report.ReporterLog("TEST FAILED", LogStatus.FAIL);
		}
		if (System.getProperty("REPORT_APPEND") != null
				&& System.getProperty("REPORT_APPEND").equalsIgnoreCase("TRUE")) {
			// CommonStaticVariables.EXTENTTESTREPORT would be closed in
			// @AfterSuite
			Report.EXTENTTESTREPORT.endTest(Report.EXTENTTEST);
			Report.EXTENTTESTREPORT.flush();
		} else {
			Report.EXTENTTESTREPORT.endTest(Report.EXTENTTEST);
			Report.EXTENTTESTREPORT.flush();
			Report.EXTENTTESTREPORT.close();
		}

		// Closing and Quitting the Driver instance
		if (driver != null) {
			driver.close();driver.quit();
		} else {
			System.out.println(
					Report.CurrentRowOfExecution + "   --------------------DRIVER IS NULL----------------------");
		}
		//Galen Report
		try{
			new HtmlReportBuilder().build(Report.GALENTEST, CommonStaticVariables.CurrentReportingLocation+"/galen-html-reports");
		}catch(Exception exception) {
			exception.printStackTrace();
		}
	}
	/**********************************/
}