

package com.TestSuite.TestData;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.Engine.LoadEnvironment;
import com.Engine.Reporter;
import com.Engine.SeleniumSetup;
import com.Enumerations.Generic.DesktopTabletMobile;
import com.SharedModules.Constants;
import com.Utils.DataProviderExcelReader;
import com.relevantcodes.extentreports.LogStatus;


public class TC001_Sample_Testcase extends SeleniumSetup implements Constants {

	/**
	 * Data Provider returns SCRIPT_ID and ROW where the SCRIPT_ID exists in
	 * mentioned sheets
	 * 
	 * @return
	 * @throws Exception
	 */
	@DataProvider(name = "TC001_Sample_Testcase",parallel=true)
	// Data Provider name
	public Object[][] DATA() throws Exception {
		DataProviderExcelReader DP = new DataProviderExcelReader();
		return DP.getExcelData(InputSheet, LoadEnvironment.EnvironmentDataMap.get("Samplesheet"),"TC001_Sample_Testcase"); // Get data object
	}

	/**
	 * Test method name will be taken for Extent Report. Please mention a valid
	 * method name Test should contain TestPreProcessing for driver and report
	 * instantiation
	 * 
	 * @return
	 * @throws Exception
	 */
	@Test(groups = { "SalesRegression" }, dataProvider = "TC001_Sample_Testcase", invocationCount=1,threadPoolSize=10)
	public void TC001_Sample_Testcase_TestCase(String SCRIPT_ID, String ROW) throws Exception {

		/******************MANDATORY FUNCTION DON NOT DELETE*******************************/

		Map<String, String> DATA_MAP = CreateDataMap(ROW, InputSheet, LoadEnvironment.EnvironmentDataMap.get("Samplesheet"));
		DesktopTabletMobile DTM = DesktopTabletMobile.valueOf(DATA_MAP.get("MODE").split("_")[0]);
		Reporter TestReporter  = CreateReport(SCRIPT_ID, ROW,DATA_MAP.get("TEST CASE NAME"));TestReporter.TestType="TESTDATA";
		WebDriver TestDriver = CreateDriver(DATA_MAP.get("BROWSER"), TestReporter, "", set_ModeResolution(DATA_MAP.get("MODE")));
		/**********************************/
		System.out.println("EXECUTING FROM " + ROW +" ROW WITH REPORTING " + TestReporter.toString());		

		
		//Objects
		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/******************MANDATORY FUNCTION DON NOT DELETE*******************************/
		CloseReportsandDriver(TestDriver,TestReporter);
		/**********************************/

	}
	
	
	/******************MANDATORY FUNCTION DON NOT DELETE*******************************/
	@Override
	@AfterMethod
	public void tearDown() throws Exception {
		System.out.println("Tear down complete");

	}
	public static void CloseReportsandDriver(WebDriver driver, Reporter Report) {
		if (Report.TESTPASSED) {
			Report.ReporterLog("TEST PASSED", LogStatus.PASS);
		} else {
			Report.ReporterLog("TEST FAILED", LogStatus.FAIL);
		}
		if (System.getProperty("REPORT_APPEND") != null
				&& System.getProperty("REPORT_APPEND").equalsIgnoreCase("TRUE")) {
			// CommonStaticVariables.EXTENTTESTREPORT would be closed in
			// @AfterSuite
			Report.EXTENTTESTREPORT.endTest(Report.EXTENTTEST);
			Report.EXTENTTESTREPORT.flush();
		} else {
			Report.EXTENTTESTREPORT.endTest(Report.EXTENTTEST);
			Report.EXTENTTESTREPORT.flush();
			Report.EXTENTTESTREPORT.close();
		}
		// Closing and Quitting the Driver instance
		if (driver != null) {
			driver.close();driver.quit();
		} else {
			System.out.println(
					Report.CurrentRowOfExecution + "   --------------------DRIVER IS NULL----------------------");
		}
	}
	/**********************************/

}