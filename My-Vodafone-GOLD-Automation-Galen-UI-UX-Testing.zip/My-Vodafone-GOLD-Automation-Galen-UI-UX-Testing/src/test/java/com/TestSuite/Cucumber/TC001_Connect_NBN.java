package com.TestSuite.Cucumber;

import org.junit.runner.RunWith;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.Engine.CucumberSetup;
import com.Utils.DataProviderExcelReader;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;

@RunWith(Cucumber.class)
//@ExtendedCucumberOptions(jsonReport = "Report/cucumber.json", retryCount = 1, detailedReport = true, detailedAggregatedReport = true, overviewReport = true, coverageReport = true, jsonUsageReport = "Report/cucumber-usage.json", usageReport = true, toPDF = true,
//		// excludeCoverageTags = {"@flaky" },
//		includeCoverageTags = { "@passed", "@flaky" },outputFolder = "Report")

//
//plugin = {
//		"html:Report/cucumber-html-report", "json:Report/cucumber.json", "pretty:Report/cucumber-pretty.txt",
//		"usage:Report/cucumber-usage.json", "junit:Report/cucumber-results.xml" }, format = { "pretty",
//				"html:Report/site/cucumber-pretty", "rerun:Report/rerun.txt",
//				"json:Report/cucumber-usage.json" }, 
@CucumberOptions(features = { "./src/test/resources/features/TC001_Connect_NBN.feature" }, glue = {
		"com.BusinessModules.Cucumber.Steps" }, tags = { "~@Ignore" }, monochrome = true)

public class TC001_Connect_NBN extends CucumberSetup{

	private TestNGCucumberRunner testNGCucumberRunner;

	@Test(groups = { "ConnectOrders","ConnectNBN" }, description = "Runs Cucumber Feature", dataProvider = "FeatureLoader", invocationCount = 1, threadPoolSize = 1)
	public void Runner_TC001_Connect_NBN(CucumberFeatureWrapper cucumberFeature, String Row) throws Exception {
		
		String WB =System.getProperty("user.dir") + "/DataProvider/InputSheet.xls";
		String SW = "ConnectOrders";
		String R =Row;
		
	
		Thread.currentThread().setName(WB+","+SW+","+R);
		System.out.println(WB+","+SW+","+R);

		testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());

	}

	@DataProvider(name = "FeatureLoader", parallel = false)
	// Data Provider name
	public Object[][] DATA() throws Exception {
		DataProviderExcelReader DP = new DataProviderExcelReader();
		return DP.getExcelData(testNGCucumberRunner, System.getProperty("user.dir") + "/DataProvider/InputSheet.xls",
				"ConnectOrders"); // Get data object
	}

	@BeforeClass(alwaysRun = true)
	public void setUpClass() throws Exception {
		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
	}

	@AfterClass(alwaysRun = true)
	public void tearDownClass() throws Exception {
		testNGCucumberRunner.finish();
	}
}