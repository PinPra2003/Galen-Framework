package com.WebService;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.Engine.ExceptionHandlers;
import com.Engine.LoadEnvironment;
import com.Engine.Reporter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class REST {

	Reporter Report;

	public REST(Reporter report) {
		this.Report = report;
	}

	public REST() {
		// TODO Auto-generated constructor stub
	}
	private final String USER_AGENT = "Mozilla/5.0";
	public  Map<String,String>  sendRESTRequest(String URL, String METHOD, Map<String,String> HEADERS,String PARAMETERS) throws Exception {

		Map<String , String> responseMap = new HashMap<String,String>();
		URL obj;
		String url = URL;
		String Parameters = null;

		Parameters=PARAMETERS;

		try {

			if(LoadEnvironment.EnvironmentDataMap.get("SET_PROXY").equalsIgnoreCase("TRUE")) {
				System.setProperty("http.proxyHost", LoadEnvironment.EnvironmentDataMap.get("http.proxyHost"));
				System.setProperty("http.proxyPort", LoadEnvironment.EnvironmentDataMap.get("http.proxyPort"));
				System.setProperty("https.proxyHost", LoadEnvironment.EnvironmentDataMap.get("https.proxyHost"));
				System.setProperty("https.proxyPort", LoadEnvironment.EnvironmentDataMap.get("https.proxyPort"));
				System.setProperty("http.proxyUser", LoadEnvironment.EnvironmentDataMap.get("http.proxyUser"));
				System.setProperty("http.proxyPassword", LoadEnvironment.EnvironmentDataMap.get("http.proxyPassword"));
				System.out.println("SETTING PROXY IS COMPLETE AND PROXY IS SET TO  " + System.getProperty("https.proxyHost"));
			}else {
				System.out.println("SETTING PROXY IS COMPLETE AND PROXY IS SKIPPED");
			}


			if(METHOD.equalsIgnoreCase("GET")) {
				if(!Parameters.equalsIgnoreCase("")) {
					obj = new URL(url+"?"+Parameters);
				}else {
					obj = new URL(url);
				}
			}else if(METHOD.equalsIgnoreCase("POST")) {
				obj = new URL(url);
				System.out.println(url);
			}else {
				obj = new URL(url);
				System.out.println(url);
			}

			HttpURLConnection con = (HttpURLConnection) obj.openConnection();

			// optional default is GET
			con.setRequestMethod(METHOD);

			//add request header
			con.setRequestProperty("User-Agent", USER_AGENT);


			for (Map.Entry<String, String> entry : HEADERS.entrySet()){
				System.out.println("SETTING HEADERS - > "+entry.getKey() + ":" + entry.getValue());
				con.setRequestProperty(entry.getKey(), entry.getValue());
			}

			// Send post request
			if(!METHOD.equalsIgnoreCase("GET")) {
				if(Parameters.equalsIgnoreCase("NA")) {
					Parameters="";
				}
				con.setDoOutput(true);
				System.out.println(Parameters);
				DataOutputStream wr = new DataOutputStream(con.getOutputStream());
				wr.writeBytes(Parameters);
				wr.flush();
				wr.close();
			}


			//Get response
			int responseCode = con.getResponseCode();
			//Report.fnReportInfo("Sending "+METHOD+" request to URL : " + url);
			System.out.println("Sending "+METHOD+" request to URL : " + url);

			//Get inputstream of reposne
			InputStream _is;
			if (con.getResponseCode() < HttpURLConnection.HTTP_BAD_REQUEST) {
				responseMap.put("RESPONSE_TYPE", "OUTPUT");
				_is = con.getInputStream();
			} else {
				_is = con.getErrorStream();
				responseMap.put("RESPONSE_TYPE", "ERROR");
			}


			BufferedReader in = new BufferedReader(new InputStreamReader(_is));

			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();


			//Set response items to map
			responseMap.put("RESPONSE_CODE", Integer.toString(responseCode));
			responseMap.put("RESPONSE_MESSAGE", response.toString());



		}catch (Exception exception) {
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage());
		}

		return responseMap;


	}

	public void ThrowException(String Row, String IFCASE) {
		if(IFCASE.equalsIgnoreCase("YES"))
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), "Exception Thorwn From " + Row);

	}

	@SuppressWarnings("unused")
	public  boolean RestValidation(String reponseContent,String RESTPath,String RestValue)throws Exception  {

		boolean returnValue = false;
		JSONParser parser = new JSONParser();
		

		try {

			Object obj = parser.parse(reponseContent);
			JSONObject jsonObject = (JSONObject) obj; 
			Object     intervention = null;
			JSONArray  interventionJsonArray= null;
			JSONObject interventionObject= null;

			intervention = 	jsonObject.get(RESTPath);

			if (intervention instanceof JSONArray) {
				System.err.println("It's an array");
				interventionJsonArray = (JSONArray)intervention;
			}else if (intervention instanceof JSONObject) {
				System.err.println("It's an OBJECT");
				interventionObject = (JSONObject)intervention;
				System.out.println(interventionObject);
			}else {
			
				System.err.println("It's something else, like a string or number");
				if(((String)jsonObject.get(RESTPath)!=null)&&((String)jsonObject.get(RESTPath)).equalsIgnoreCase(RestValue)) {
					returnValue=true;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();

		}

		return returnValue;


	}

}
