package com.PUTTY;

import java.io.PrintStream;

import com.Engine.LoadEnvironment;
import com.Engine.Reporter;
import com.Engine.SeleniumSetup;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.Session;

/**
 * Author	:	Karthik Kannan
 * Version	:	1.0 
 */
public class LrShell extends SeleniumSetup {

	public LrShell(Reporter report) {
		Report = report;
	}

	public String LrShell_getLogfile(String Commands, String OutputFilename
			) throws Exception {
		/*****************************************************************************************************/

		LogXmlParser Logs = new LogXmlParser();


		Session session = Logs.CreateJschSession("baswarp", "year@2013",
				LoadEnvironment.EnvironmentDataMap.get("BW_SERVERIP"));
		Channel channel = Logs.CreateChannelforExecution(session, "shell");
		PrintStream commander = Logs.CreateCommander(channel);
		Logs.CommandSender(commander, "<<Commands>>");
		Logs.CommandSender(commander, "exit");
		Logs.CloseCommandSender(commander);
		Logs.DisplayShell(channel);

		Logs.CloseChannel(channel);
		Logs.CloseSession(session);


		Logs.GetFile("<<LOCATION>>" + OutputFilename,
				System.getProperty("user.dir") + "\\<<temp location>>\\" + OutputFilename);
		return OutputFilename;



	}




}