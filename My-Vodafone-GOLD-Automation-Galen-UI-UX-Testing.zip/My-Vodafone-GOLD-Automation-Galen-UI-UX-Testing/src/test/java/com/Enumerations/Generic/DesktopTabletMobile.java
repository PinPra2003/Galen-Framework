package com.Enumerations.Generic;

public enum DesktopTabletMobile {
	DESKTOP,
	MOBILE,	
	TABLET


}
