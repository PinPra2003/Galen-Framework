/* Author: Karthik K
 * version 1.0
 * Test Listener class overrides the ItestListener class in testng 
 * then gives the overall build result and calls the method which
 * updates the JIRA based on the result
 */

package com.Engine;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;


public class TestListener implements ITestListener {

	public static String buildResult = "";

	@Override
	public void onTestStart(ITestResult result) {
		System.out.println(
				"Teststarted running:" + result.getMethod().getMethodName() + " at:" + result.getStartMillis());

	}

	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println("Result success");
		buildResult = result.toString();
	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("Result failure");
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		System.out.println("Testskipped!");
	}

	@Override
	public void onFinish(ITestContext context) {
		//JIRA UPDATION
//		PostRequest post = new PostRequest();
//		int Count_PASS = context.getPassedTests().getAllResults().size();
//		int Count_FAIL = context.getFailedTests().getAllResults().size();
//		System.out.println("Passeds: " + Count_PASS);
//		System.out.println("Faileds:" + Count_FAIL);
//		if (!context.getAttribute("jiraCard").toString().equalsIgnoreCase("")) {
//			String[] jsonData = { "authentication", "comment", "status", (String) context.getAttribute("subtask") };
//			if (Count_FAIL > 0) {
//				post.sendPost(context.getAttribute("jiraCard").toString(), jsonData, "FAIL");
//			} else if (Count_PASS > 0) {
//				post.sendPost(context.getAttribute("jiraCard").toString(), jsonData, "PASS");
//			} else {
//				org.testng.Reporter.log("Build Failure");
//			}
//		} else {
//			org.testng.Reporter.log("JIRA details not provided");
//		}
	}

	@Override
	public void onStart(ITestContext arg0) {

	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {

	}

	

}
