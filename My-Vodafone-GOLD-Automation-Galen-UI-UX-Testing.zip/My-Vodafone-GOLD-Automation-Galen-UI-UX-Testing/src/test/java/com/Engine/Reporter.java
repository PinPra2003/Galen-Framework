package com.Engine;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.galenframework.reports.GalenTestInfo;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

/**
 * Author	:	Karthik Kannan
 * Version	:	1.0
 * This class would handle the reporting and screenshot taking proccess in the framework
 * 
 */
public class Reporter {

	public ExtentReports EXTENTTESTREPORT;
	public ExtentTest EXTENTTEST;
	public String ScreenshotLocation;
	public String CurrentRowOfExecution;
	public int EXECUTION_OFFSET = 0;
	public boolean TESTPASSED = true;
	public String REPORTNAME;
	public int ReportingRow = 1;
	public String TestType="TEST";

	// RWD TESTING GALEN
	public List<GalenTestInfo> GALENTEST = new LinkedList<GalenTestInfo>();

	public void fnReportPass(String strPassingItem, WebDriver... driver) {
		ReporterLog(strPassingItem, LogStatus.PASS, driver);
	}

	public void fnReportInfo(String strPassingItem, WebDriver... driver) {
		ReporterLog(strPassingItem, LogStatus.INFO, driver);
	}

	public void fnReportWarning(String strPassingItem, WebDriver... driver) throws Exception {
		ReporterLog(strPassingItem, LogStatus.WARNING, driver);
	}

	public void fnReportFail(String strFailingItem, WebDriver... driver) {
		TESTPASSED = false;
		ReporterLog(strFailingItem, LogStatus.FAIL, driver);
	}

	public void fnReportFailAndTerminateTest(String strFailingItem, String strReportMessage, WebDriver... driver) {
		TESTPASSED = false;
		ReporterLog(strReportMessage, LogStatus.FAIL, driver);
		ExceptionHandlers.FinalExceptionHandler(this, strFailingItem, strReportMessage, driver);
	}

	public void fnReportPageBreak(String Str_PageName, WebDriver driver) {
		ReporterLog("---" + Str_PageName + "--- ", LogStatus.INFO,driver);
	}

	//	public void takescreenshot(WebDriver driver, String Str_ReportMessage, LogStatus LS) {
	//
	//		File photographWithPath = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	//
	//		try {
	//			FileUtils.copyFile(photographWithPath, new File(ScreenshotLocation + "/" + ReportingRow + ".png"));
	//		
	//			String Color = "";
	//			switch (LS) {
	//			case ERROR:
	//				break;
	//			case FAIL:
	//				Color = "#ff0000";
	//				break;
	//			case FATAL:
	//				Color = "#800000";
	//				break;
	//			case INFO:
	//				Color = "#00bfff";
	//				break;
	//			case PASS:
	//				Color = "#008000";
	//				break;
	//			case SKIP:
	//				break;
	//			case UNKNOWN:
	//				break;
	//			case WARNING:
	//				Color = "#ffa700";
	//				break;
	//			default:
	//				break;
	//
	//			}
	//
	//			ReporterLog("<a href=\"" + ScreenshotLocation + "/" + ReportingRow + ".png" + "\"style=\"color: " + Color
	//					+ "\">" + Str_ReportMessage.replaceAll("/", "_") + "</a>", LS);
	//
	//		} catch (IOException e) {
	//			ReporterLog(ScreenshotLocation + "/" + Str_ReportMessage.replaceAll("/", "_") + ".png  NOT SAVED", LS);
	//		}
	//	}

	public String takescreenshot(WebDriver driver, String Str_ReportMessage, LogStatus LS) {

		File photographWithPath = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String returnValue = ScreenshotLocation + "/" + Str_ReportMessage.replaceAll("/", "_") + ".png  NOT SAVED";

		try {
			FileUtils.copyFile(photographWithPath, new File(ScreenshotLocation + "/" + ReportingRow + ".png"));

			String Color = "";
			switch (LS) {
			case ERROR:
				break;
			case FAIL:
				Color = "#ff0000";
				break;
			case FATAL:
				Color = "#800000";
				break;
			case INFO:
				Color = "#00bfff";
				break;
			case PASS:
				Color = "#008000";
				break;
			case SKIP:
				break;
			case UNKNOWN:
				break;
			case WARNING:
				Color = "#ffa700";
				break;
			default:
				break;

			}
			returnValue = "<a href=\"" + ScreenshotLocation + "/" + ReportingRow + ".png" + "\"style=\"color: " + Color
					+ "\">" + Str_ReportMessage.replaceAll("/", "_") + "</a>";

			//			ReporterLog("<a href=\"" + ScreenshotLocation + "/" + ReportingRow + ".png" + "\"style=\"color: " + Color
			//					+ "\">" + Str_ReportMessage.replaceAll("/", "_") + "</a>", LS);

		} catch (IOException e) {
			ReporterLog(ScreenshotLocation + "/" + Str_ReportMessage.replaceAll("/", "_") + ".png  NOT SAVED", LS);
		}

		return returnValue;
	}
	public void ReporterLog(String Reprot_Text, LogStatus LS, WebDriver... driver) {


		if (LS.name().equalsIgnoreCase("Fail")) {
			TESTPASSED = false;
		}
		Charset UTF8_CHARSET = Charset.forName("UTF-8");
		Charset USASCII_CHARSET = Charset.forName("ISO-8859-1");
		if (driver.length > 0) {
			String ScreenshotContent = takescreenshot(driver[0], Reprot_Text, LS);
			EXTENTTEST.log(LS, ScreenshotContent);
		} else {
			EXTENTTEST.log(LS, Reprot_Text);
		}
		String Data = "[ Reported ] " + new String(
				(LS.name() + "\t" + ReportingRow + "  " + Reprot_Text).getBytes(UTF8_CHARSET), USASCII_CHARSET);
		System.out.println(Data);
		org.testng.Reporter.log(Data);
		ReportingRow += 1;

	}

}
