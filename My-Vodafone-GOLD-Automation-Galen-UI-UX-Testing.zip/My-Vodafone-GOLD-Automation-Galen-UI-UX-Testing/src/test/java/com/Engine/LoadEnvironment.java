package com.Engine;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.properties.EncryptableProperties;

public  class LoadEnvironment {
	public static Map<String, String> EnvironmentDataMap = new HashMap<String, String>();
	public static String workingDir = System.getProperty("user.dir");

	/**
	 * This functional Load the downstream environment properties for the test
	 * run and stores them under EnvironmentDataMap
	 * 
	 * @param env
	 */
	public static void LoadDownStreamENV(String env) {
		ProperToMapLoader("DOWNSTREAM ENVIRONMENT", env,
				workingDir + "/PropertyFiles/EnvironmentProperties/" + env + ".properties");
	}

	/**
	 * This functional Load the Upstream environment properties for the test run
	 * and stores them under EnvironmentDataMap
	 * 
	 * @param env
	 */
	public static void LoadUpStreamProperties(String env) {
		ProperToMapLoader("UPSTREAM ENVIRONMENT", env,
				workingDir + "/PropertyFiles/EnvironmentProperties/" + env + ".properties");
	}

	/**
	 * This functional Load the Upstream environment properties for the test run
	 * and stores them under EnvironmentDataMap
	 * 
	 * @param env
	 */
	public static void LoadGenericTestProperties() {
		ProperToMapLoader("GENERIC PROPERTIES", "",
				workingDir + "/PropertyFiles/GenericProperties/TestConfigGeneric.properties");
		EnvironmentDataMap.put("INPUTSHEET", workingDir + EnvironmentDataMap.get("INPUTSHEET"));
		System.out.println("SMALL_LOOP_TIMEOUT IS LOADED WITH  "+EnvironmentDataMap.get("SMALL_LOOP_TIMEOUT"));
	}

	/**
	 * This functional Load the Upstream environment properties for the test run
	 * and stores them under EnvironmentDataMap
	 * 
	 * @param env
	 */
	public static void LoadProvisioningProperties(String env) {
		ProperToMapLoader("UPSTREAM ENVIRONMENT ie; PROVISIONING PROPERTIES", env,
				workingDir + "/PropertyFiles/ProvisioningProperties/Provisoning.properties");
	}

	/**
	 * 
	 * @param PropertyType
	 * @param PropertyIdentifier
	 * @param PropertyLocation
	 * 
	 */
	public static void ProperToMapLoader(String PropertyType, String PropertyIdentifier, String PropertyLocation) {
		// Properties prop = new Properties();
		// InputStream input = null;
		// try {
		// PropertyIdentifier=PropertyIdentifier.toLowerCase();
		// input = new FileInputStream(PropertyLocation);
		// //load a properties file
		// prop.load(input);
		// for (String key : prop.stringPropertyNames()) {
		// EnvironmentDataMap.put(key, prop.getProperty(key));
		// }
		// System.out.println(PropertyType + "LOADED WITH " + PropertyIdentifier
		// + "as identifier from " + PropertyLocation);
		// }catch(Exception exception){
		// ExceptionHandlers.PreRunExceptionHandler("Exception occured while
		// loading " + PropertyType + " with Identifier "+
		// PropertyIdentifier + " Form Location "+ PropertyLocation + "With the
		// Message "+ exception.getMessage());
		// }

		try {
			StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
			encryptor.setPassword("AUTOMATION");
			Properties prop = new EncryptableProperties(encryptor);
			prop.load(new FileInputStream(PropertyLocation));
			for (String key : prop.stringPropertyNames()) {
				 //System.out.println(key+"="+prop.getProperty(key));
				EnvironmentDataMap.put(key, prop.getProperty(key));
			}
			 System.out.println(PropertyType + "LOADED WITH " +
			 PropertyIdentifier + "as identifier from " + PropertyLocation);
		} catch (Exception exception) {
			ExceptionHandlers.PreRunExceptionHandler(
					"Exception occured while loading " + PropertyType + " with Identifier " + PropertyIdentifier
							+ " Form Location " + PropertyLocation + "With the Message " + exception.getMessage());
		}
	}

	
}
