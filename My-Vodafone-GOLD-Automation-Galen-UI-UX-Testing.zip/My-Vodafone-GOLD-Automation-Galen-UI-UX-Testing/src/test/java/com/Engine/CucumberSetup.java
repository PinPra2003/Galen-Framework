/**
 * Author	:	Karthik Kannan
 * Version	:	1.0
 * CucumberSetup defines the functions and modules that are used 
 * for the primary setup of the test run which includes reporting
 * module creation, loading of system variables and test properties
 * and post test run functions of clearing the variables, closing the browsers
 * and saving the reports.
 * 
 * This Class is extended into every test run and BaseClass of the DI to create a separate instance and 
 * implements a interface to store the report folder names and static report variables
 * for re-use across test runs  
 */

package com.Engine;

import java.io.File;

import java.net.URL;
import java.util.Map;

import org.openqa.selenium.Dimension;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import org.testng.annotations.BeforeSuite;

import com.Utils.ReadExcelSheet;
import com.Utils.Reusables;
import com.relevantcodes.extentreports.DisplayOrder;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class CucumberSetup {
	
	
	/**
	 * Author	:	Karthik Kannan
	 * Version	:	1.0
	 * Common Variables for Selenium Setup
	 */

	public WebDriver driver;
	public Reporter Report;
	public String MODE_OF_EXECUTION = "LOCAL";

	public enum Browser {
		FIREFOX, GOOGLECHROME, IE, SAFARI, CHROME
	}

	/**
	 * Author	:	Karthik Kannan
	 * Version	:	1.0
	 * This functions takes up the @BeforeSuite TestNG annotation This function
	 * would be invoked before the start of the test suite performing 1.
	 * Retrieve System Properties Passed during Runtime 2. Report location setup
	 * 3. Loading the Environments 4. Loading the TestGeneric Properties 5.
	 * Setup of driver Paths 6. Setup Common Report if REPORT_NAME!=null and
	 * REPORT_APPEND!=null
	 */
	@BeforeSuite
	public void SetupBeforeTestSuite() {
		/* 1. Retrieve System Properties Passed during Runtime */

		// Environment Variables
		String ENVIRONMENT = System.getProperty("ENVIRONMENT");

		// Reporting Variables
		String REPORT_NAME = System.getProperty("REPORT_NAME");
		String REPORT_APPEND = System.getProperty("REPORT_APPEND");
		MODE_OF_EXECUTION = System.getProperty("MODE_OF_EXECUTION");

		/* 2. Report location setup */
		if (ENVIRONMENT == null) {
		ExceptionHandlers.PreRunExceptionHandler("Please provide the Environment against which the cases must be executed");
		} else {

			/*
			 * ---Setting Up Report Location and storing the location string in
			 * SetUpInterface---
			 */

			File file = new File(CommonStaticVariables.CurrentReportingLocation);
			if (!file.exists()) {
				if (file.mkdirs()) {
					System.out.println("Primary Directory is created!");
				} else {
					System.out.println("FOLDER NOT CREATED EXITING AS 1 ........ ");
					ExceptionHandlers.PreRunExceptionHandler("Failed to create Primary Directory!");
				}
			} else {
				System.out.println("FOLDER ALREADY EXISTS TRYING TO DELETE ........ ");
				if (file.delete()) {
					System.out.println("Primary Directory is Deleted !");
				} else {
					System.out.println("FOLDER NOT DELETED EXITING AS 1 ........ ");
					ExceptionHandlers.PreRunExceptionHandler("Failed to delete Primary Directory!");
				}
				if (file.mkdirs()) {
					System.out.println("Primary Directory is created!");
				} else {
					System.out.println("FOLDER NOT CREATED EXITING AS 1 ........ ");
					ExceptionHandlers.PreRunExceptionHandler("Failed to create Primary Directory!");
				}
			}


			/* 3. Loading the Environments */
			LoadEnvironment.LoadDownStreamENV(ENVIRONMENT);
		

			/* 4. Loading the TestGeneric Properties */
			LoadEnvironment.LoadGenericTestProperties();



			/* 5. Setup of driver Paths */
			System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir") + "/SupportDrivers/chromedriver.exe");
			System.setProperty("webdriver.ie.driver",
					System.getProperty("user.dir") + "/SupportDrivers/IEDriverServer.exe");
			System.setProperty("phantomjs.binary.path",
					System.getProperty("user.dir") + "/SupportDrivers/phantomjs.exe");
			System.setProperty("webdriver.gecko.driver",
					System.getProperty("user.dir") + "/SupportDrivers/geckodriver.exe");

			System.out.println("WEB DRIVER PROPERTIES SET");
			/*
			 * 6. Setup Common Report if REPORT_NAME!=null and
			 * REPORT_APPEND!=null
			 */
			if (REPORT_NAME != null && REPORT_APPEND.equalsIgnoreCase("TRUE")) {
				CommonStaticVariables.EXTENTTESTREPORT = new ExtentReports(
						CommonStaticVariables.CurrentReportingLocation + "/" + REPORT_NAME + ".html", false,
						DisplayOrder.NEWEST_FIRST);
			}
			System.out.println("EXTENT TEST PROPERTY  SET");

		}
	}

	/** Author	:	Karthik Kannan
	 * Version	:	1.0
	 * This function is used to create data maps, drivers and reporting instances
	 * @param SCRIPTID
	 * @param ROW
	 * @param InputSheet
	 * @param SheetName
	 * @return
	 */
	public Map<String, String> TestPreProcessing(String SCRIPTID, String ROW, String InputSheet, String SheetName) {
		Map<String, String> DATA_MAP = null;
		try {
			System.out.println("SCRIPT ID --->" +SCRIPTID);
			Report = InitializeExtentReport(SCRIPTID, ROW);
			Report.CurrentRowOfExecution = ROW;
			String Mode = "DESKTOP";
			ReadExcelSheet RX = new ReadExcelSheet();
			DATA_MAP = RX.CreateMapFromExcel(InputSheet, SheetName, ROW);

			// Launching Driver
			System.out.println("Launching Driver");
			if (DATA_MAP.containsKey("MODE")) {
				Mode = DATA_MAP.get("MODE").toUpperCase();
			}

			driver = WhereToExecute(DATA_MAP.get("BROWSER").toString().toUpperCase(),
					LoadEnvironment.EnvironmentDataMap.get("DEFAULT_LAUNCH_URL"), set_ModeResolution(Mode)); // "http://localhost:4444/wd/hub"
			Report.fnReportInfo("Test Case Running on " + Mode + " Mode:");

		} catch (Exception exception) {
			ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage());
		}

		return DATA_MAP;
	}

	/**
	 * Author	:	Karthik Kannan
	 * Version	:	1.0
	 * This function create a reporting variable
	 * @param SCRIPTID
	 * @param ROW
	 * @return
	 */
	public Reporter CreateReport(String SCRIPTID,String ROW) {

		try {
			Report = InitializeExtentReport(SCRIPTID, ROW);
			Report.CurrentRowOfExecution = ROW;

		} catch (Exception exception) {
			exception.printStackTrace();
		}

		return Report;
	}

	/**
	 * Author	:	Karthik Kannan
	 * Version	:	1.0
	 * This function creates a test data map
	 * @param ROW
	 * @param InputSheet
	 * @param SheetName
	 * @return
	 */
	public Map<String, String> CreateDataMap(String ROW, String InputSheet, String SheetName) {
		Map<String, String> DATA_MAP = null;
		try {
			System.out.println("-------------------CREATING DATA MAP-------------------");

			ReadExcelSheet RX = new ReadExcelSheet();
			DATA_MAP = RX.CreateMapFromExcel(InputSheet, SheetName, ROW);


		} catch (Exception exception) {
			exception.printStackTrace();
		}

		return DATA_MAP;
	}

	/**
	 * Author	:	Karthik Kannan
	 * Version	:	1.0
	 * @param BROWSER
	 * @param LAUNCH_URL
	 * @param set_ModeResolution
	 * @return
	 */
	public WebDriver WhereToExecute(String BROWSER, String LAUNCH_URL, Integer... set_ModeResolution) {
		MODE_OF_EXECUTION = System.getProperty("MODE_OF_EXECUTION");
		System.out.println(LoadEnvironment.EnvironmentDataMap.get("password"));
		WebDriver daemon = null;
		System.out.println("Creating driver in " + MODE_OF_EXECUTION + " mode with " + BROWSER);
		Browser value = Browser.valueOf(BROWSER.toUpperCase());
		if (MODE_OF_EXECUTION.equalsIgnoreCase("LOCAL")) {
			switch (value) {
			case FIREFOX:
				try {
					daemon = null;
					for (int second = 0;; second++) {
						if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
							Report.ReporterLog("Driver Launching Warning", LogStatus.INFO);
							ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
							}.getClass().getEnclosingMethod().getName(), "Driver Launching Warning");
						}
						try {
							daemon = new FirefoxDriver();
							/*FirefoxBinary binary = new FirefoxBinary(new File("C:/Mozilla Firefox/firefox.exe"));
							FirefoxProfile profile = new FirefoxProfile();
							daemon = new FirefoxDriver(binary, profile);*/
							break;
						} catch (Exception exception) {
							continue;
						}
					}
					// daemon = new FirefoxDriver();
					System.out.println("Successfully created instance : " + daemon);
				} catch (Exception exception) {
					ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
					}.getClass().getEnclosingMethod().getName(), exception.getMessage());
				}
				break;
			case GOOGLECHROME:
			case CHROME:
				try {


					daemon = null;
					for (int second = 0;; second++) {
						if (second >= Integer.parseInt(LoadEnvironment.EnvironmentDataMap.get("LOOP_COUNTER"))) {
							Report.ReporterLog("Driver Launching Warning", LogStatus.INFO);
							ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
							}.getClass().getEnclosingMethod().getName(), "Driver Launching Warning");
						}
						try {

							ChromeOptions options = new ChromeOptions();
							options.addArguments("-incognito");
							DesiredCapabilities capabilities = DesiredCapabilities.chrome();
							capabilities.setCapability(ChromeOptions.CAPABILITY, options);
							daemon = new ChromeDriver(capabilities);
							break;

						} catch (Exception exception) {
							continue;
						}
					}

					// daemon = new ChromeDriver();
					System.out.println("Successfully created instance : " + daemon);
				} catch (Exception exception) {
					ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
					}.getClass().getEnclosingMethod().getName(), exception.getMessage());
				}
				break;
			case IE:
				try {
					DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();
					ieCapabilities.setCapability(
							InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
					ieCapabilities.setCapability("platform", "WINDOWS");
					ieCapabilities.setCapability("cssSelectorsEnabled", true);
					ieCapabilities.setCapability("unexpectedAlertBehaviour", "accept");
					ieCapabilities.setCapability("browserName", "internet explorer");
					daemon = new InternetExplorerDriver(ieCapabilities);
				} catch (Exception exception) {
					ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
					}.getClass().getEnclosingMethod().getName(), exception.getMessage());
				}
				break;
			default:
				break;
			}

			// Setting the browser Dimentions
			if ((set_ModeResolution.length < 2) || (set_ModeResolution[0] == 9999) || (set_ModeResolution[1] == 9999)) {
				daemon.manage().window().setSize(new Dimension(1024, 768));
				daemon.manage().window().maximize();
			} else {
				daemon.manage().window().setSize(new Dimension(set_ModeResolution[0], set_ModeResolution[1]));
			}

		}
		if (MODE_OF_EXECUTION.equalsIgnoreCase("GRID")) {

			System.out.println("Configuring GRID Options");
			DesiredCapabilities capability = new DesiredCapabilities();
			switch (value) {
			case FIREFOX:
				try {
					capability = DesiredCapabilities.firefox();
					daemon = new RemoteWebDriver(new URL(LAUNCH_URL), capability);
					daemon.manage().window().maximize();
				} catch (Exception exception) {
					ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
					}.getClass().getEnclosingMethod().getName(), exception.getMessage());
				}
				break;
			case GOOGLECHROME:
			case CHROME:
				try {
					capability = DesiredCapabilities.chrome();
					capability.setCapability("browserName", "chrome");
					System.out.println("Creating remote driver instance");
					daemon = new RemoteWebDriver(new URL(LAUNCH_URL), capability);
					daemon.manage().window().maximize();
				} catch (Exception exception) {
					ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
					}.getClass().getEnclosingMethod().getName(), exception.getMessage());
				}
				break;
			case IE:
				try {
					capability = DesiredCapabilities.internetExplorer();
					capability.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
							true);
					capability.setCapability("cssSelectorsEnabled", true);
					capability.setCapability("unexpectedAlertBehaviour", "accept");
					capability.setCapability("browserName", "internet explorer");
					daemon = new RemoteWebDriver(new URL(LAUNCH_URL), capability);
					daemon.manage().window().maximize();
				} catch (Exception exception) {
					ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
					}.getClass().getEnclosingMethod().getName(), exception.getMessage());
				}
				break;
			default:
				break;
			}
			// Setting the browser Dimentions
			if ((set_ModeResolution.length < 2) || (set_ModeResolution[0] == 9999) || (set_ModeResolution[1] == 9999)) {
				daemon.manage().window().setSize(new Dimension(1366, 768));

			} else {
				daemon.manage().window().setSize(new Dimension(set_ModeResolution[0], set_ModeResolution[1]));
			}

		}
		if (MODE_OF_EXECUTION.equalsIgnoreCase("PERFECTO")) {

			System.out.println("Configuring PERFECTO Options");
			DesiredCapabilities capability = new DesiredCapabilities();
			switch (value) {
			case FIREFOX:
				try {
					capability = DesiredCapabilities.firefox();
					daemon = new RemoteWebDriver(new URL(LAUNCH_URL), capability);
					daemon.manage().window().maximize();
				} catch (Exception exception) {
					ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
					}.getClass().getEnclosingMethod().getName(), exception.getMessage());
				}
				break;
			case GOOGLECHROME:
			case CHROME:
				try {
					capability = DesiredCapabilities.chrome();
					capability.setCapability("browserName", "chrome");
					System.out.println("Creating remote driver instance");
					daemon = new RemoteWebDriver(new URL(LAUNCH_URL), capability);
					daemon.manage().window().maximize();
				} catch (Exception exception) {
					ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
					}.getClass().getEnclosingMethod().getName(), exception.getMessage());
				}
				break;
			case IE:
				try {
					capability = DesiredCapabilities.internetExplorer();
					capability.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
							true);
					capability.setCapability("cssSelectorsEnabled", true);
					capability.setCapability("unexpectedAlertBehaviour", "accept");
					capability.setCapability("browserName", "internet explorer");
					daemon = new RemoteWebDriver(new URL(LAUNCH_URL), capability);
					daemon.manage().window().maximize();
				} catch (Exception exception) {
					ExceptionHandlers.FinalExceptionHandler(Report, new Object() {
					}.getClass().getEnclosingMethod().getName(), exception.getMessage());
				}
				break;
			default:
				break;
			}
			// Setting the browser Dimentions
			if ((set_ModeResolution.length < 2) || (set_ModeResolution[0] == 9999) || (set_ModeResolution[1] == 9999)) {
				daemon.manage().window().setSize(new Dimension(1366, 768));

			} else {
				daemon.manage().window().setSize(new Dimension(set_ModeResolution[0], set_ModeResolution[1]));
			}

		}


		return daemon;
	}

	/**
	 * Author	:	Karthik Kannan
	 * Version	:	1.0
	 * This function is used to setup the resolution parameters of the browser and to compute thec CLICK offsets
	 * to be used by WebActions->VerifyElementPresentAndClcik() function
	 * @param Mode
	 * @return
	 */
	public Integer[] set_ModeResolution(String Mode) {
		Integer Width = 0, Height = 0;
		switch (Mode.toUpperCase()) {
		case "TABLET_IPAD_L":
			Width = 768;
			Height = 1024;
			break;
		case "TABLET_IPAD_P":
		case "TABLET":
			Width = 1024;
			Height = 768;
			break;
		case "MOBILE_IPHONE6_L":
			Width = 667;
			Height = 375;
			break;
		case "MOBILE_IPHONE6_P":
		case "MOBILE":
			Width = 375;
			Height = 667;
			break;
		case "DESKTOP":
			Width = 9999;
			Height = 9999;
			break;
		default:
			Width = 1024;
			Height = 768;
			break;
		}
		Report.EXECUTION_OFFSET = Height / 2;
		Integer[] toReturn = { Width, Height };
		return toReturn;
	}

	/**
	 * Author	:	Karthik Kannan
	 * Version	:	1.0
	 * This function will create a report for the test run to update during
	 * runtime Based on REPORT_NAME!=null and REPORT_APPEND!=null a. existing
	 * ExtentReport created in @BeforeSuite or b. create an ExtentREport per
	 * test case and create a folder with the TESTCASE|SCRIPTID as name for
	 * saving the screenshots
	 * 
	 * @param ReportName
	 * @param ROW
	 * @return
	 */
	public Reporter InitializeExtentReport(String ReportName, String ROW) {
		Reporter report = null;
		try {
			report = new Reporter();
			report.REPORTNAME = ReportName;
			/**
			 * Creates One Reports with multiple test cases .. Even in case of
			 * multiple iterations the same report is maintained
			 */

			if (System.getProperty("REPORT_APPEND") != null
					&& System.getProperty("REPORT_APPEND").equalsIgnoreCase("TRUE")) {
				// CommonStaticVariables.EXTENTTESTREPORT created in
				// @BeforeSuite
				report.EXTENTTESTREPORT = CommonStaticVariables.EXTENTTESTREPORT;
				report.EXTENTTEST = report.EXTENTTESTREPORT.startTest(ReportName + "_" + ROW, ReportName + "_" + ROW);
			} else {
				/**
				 * Creates A Report for every TC but in case of re iteration the
				 * report is appended
				 */

				report.EXTENTTESTREPORT = new ExtentReports(
						CommonStaticVariables.CurrentReportingLocation + "/" + ReportName + "_" + ROW + ".html", false);
				report.EXTENTTEST = report.EXTENTTESTREPORT.startTest(ReportName + "_" + ROW, ReportName + "_" + ROW);
			}

			// Create Folder for Screenshot 1 per test case
			report.ScreenshotLocation = CommonStaticVariables.CurrentReportingLocation + "/" + ReportName + "_R_" + ROW
					+ "_T_" + Reusables.getdateFormat("hh_mm_ss", 0);

			File file = new File(report.ScreenshotLocation);
			if (!file.exists()) {
				if (file.mkdirs()) {
					System.out.println("Directory is created!");
				} else {
					System.out.println("FOLDER NOT CREATED REPORTING WARNING ........ ");
					ExceptionHandlers.FinalExceptionHandler(report, new Object() {
					}.getClass().getEnclosingMethod().getName(), "FAILED TO CREATE SCREENSHOT FOLDER");
				}
			} else {

			}
			System.out.println("Screenshot Folder Created");
		} catch (Exception exception) {
			ExceptionHandlers.FinalExceptionHandler(report, new Object() {
			}.getClass().getEnclosingMethod().getName(), exception.getMessage());
		}
		return report;
	}
}