package com.Engine;

import com.Utils.Reusables;
import com.relevantcodes.extentreports.ExtentReports;

/**
 * @author karthik kannan
 * version : 1.0
 * This Class provide the common static variables for the framework
 *
 */
public class CommonStaticVariables {
	// Reporting Variables
	public static String ReportingParentFolder = System.getProperty("user.dir") + "/Report/"; //Parent folder for reports
	public static String ReportStartTime = Reusables.getdateFormat("dd_MM_yy_hh_mm_ss", 0); //Reporting Timestamp
	public static String DefaultReportName = "Automation_Execution_Report_"; //REPORT_NAME default value
	public static String CurrentReportingLocation = ReportingParentFolder + DefaultReportName + ReportStartTime; //Reporting location created for every test iteration

	public static ExtentReports EXTENTTESTREPORT = null;// Would be updated from
														// @BeforeSuite if
														// REPORT_NAME!=null and
														// REPORT_APPEND!=null

}
