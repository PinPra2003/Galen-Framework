package com.Engine;

import java.nio.charset.Charset;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;


import com.relevantcodes.extentreports.LogStatus;

public class ExceptionHandlers {

	/**
	 * Author	:	Karthik Kannan
	 * Version	:	1.0
	 * 
	 * This Function defines the common Exception handler that is to be used
	 * after the creation of a Reporting Variable.
	 * 
	 * @param Report
	 * @param MethodofOccurance
	 * @param Message
	 * @param driver
	 */

	public static void FinalExceptionHandler(Reporter Report, String MethodofOccurance, String Message,WebDriver... driver) {
		Report.TESTPASSED = false;
		String AssertMessage = Report.REPORTNAME + " Failed with a exception @ " + MethodofOccurance+ " with the message " + Message;
		Charset UTF8_CHARSET = Charset.forName("UTF-8");
		Charset USASCII_CHARSET = Charset.forName("ISO-8859-1");

		if(driver.length>0)
			Report.ReporterLog(Message, LogStatus.FATAL, driver);
		else
			Report.ReporterLog(Message, LogStatus.FATAL);

		if(Report.TestType.equalsIgnoreCase("TESTDATA")) {
			if(driver.length>0) 
				CloseReportsandDriver(Report,driver);
			else
				CloseReportsandDriver(Report);
		}else {
			System.out.println(Report.TestType);
		}



		/**********************************************/
		org.testng.Reporter.log(new String(AssertMessage.getBytes(UTF8_CHARSET), USASCII_CHARSET));
		Assert.fail(AssertMessage);
		/**********************************************/

	}

	/**
	 * Author	:	Karthik Kannan
	 * Version	:	1.0
	 * 
	 * This function is a preRunExeception handler which handles the exceptions during 
	 * 	1. Loading of environment Variables
	 * 	 
	 * @param Exception
	 * This function Exists with 1 . Marking the build as a failure
	 */
	public static void PreRunExceptionHandler(String Exception) {

		System.out.println("IN PRE RUN EXCEPTION HANDLER ---- WITH EXECEPTION ---- " + Exception);
		Charset UTF8_CHARSET = Charset.forName("UTF-8");
		Charset USASCII_CHARSET = Charset.forName("ISO-8859-1");
		org.testng.Reporter.log(new String(Exception.getBytes(UTF8_CHARSET), USASCII_CHARSET));
		System.exit(1);
	}
	/**
	 * Created By Karthik K
	 * Introduced to Handle execptions in Test data creation scripts ( due to binding with @Test, reports and drivers
	 * have to closed from exeception handler
	 * 
	 * @param driver
	 * @param Report
	 */
	public static  void CloseReportsandDriver(Reporter Report, WebDriver...driver) {
		System.out.println("----------------- CALLED CLOSE REPORTS AND DRIVER FROM FINAL EXCEPTION HANDLER ----------------------");
		if (Report.TESTPASSED) {
			Report.ReporterLog("TEST PASSED", LogStatus.PASS);
		} else {
			Report.ReporterLog("TEST FAILED", LogStatus.FAIL);
		}

		if (System.getProperty("REPORT_APPEND") != null
				&& System.getProperty("REPORT_APPEND").equalsIgnoreCase("TRUE")) {	
			// CommonStaticVariables.EXTENTTESTREPORT would be closed in
			// @AfterSuite
			Report.EXTENTTESTREPORT.endTest(Report.EXTENTTEST);
			Report.EXTENTTESTREPORT.flush();
		} else {
			Report.EXTENTTESTREPORT.endTest(Report.EXTENTTEST);
			Report.EXTENTTESTREPORT.flush();
			Report.EXTENTTESTREPORT.close();
		}
		// Closing and Quitting the Driver instance
		if (driver.length>0) {
			driver[0].close();driver[0].quit();
		} else {
			System.out.println(
					Report.CurrentRowOfExecution + "   --------------------DRIVER IS NULL----------------------");
		}
	}

}