package com.WebObjectRepository;

public interface ObjectRepo_OpenUI_TBUI {

	// Launcher Siebel
	public static String OpenUI_USERNAME="//*[@name='SWEUserName']";
	public static String OpenUI_PASSWORD="//*[@name='SWEPassword']";
	public static String OpenUI_LOGIN="//*[contains(@id,'swepi') and text()='Login']";


	public static String OpenUI_CustomerAccounts="//*[text()='Customer Accounts']";
	public static String OpenUI_AccountNew="//*[@aria-label='Account:New']";
	public static String OpenUI_AccountCancel="//*[contains(@title,'Account:Cancel')]";
	public static String OpenUI_Name="//*[@aria-label='Name']";
	public static String OpenUI_Last_Name="//*[@aria-label='Last Name']";


	public static String OpenUI_CustomerSegment="//*[@aria-label='Customer Segment']";
	public static String OpenUI_CustomerType="//*[@aria-label='Customer Type']";
	public static String OpenUI_PIN="//*[@aria-label='PIN']";
	public static String OpenUI_BillSegment="//*[@aria-label='Bill Segment']";
	public static String OpenUI_ABN="//*[@aria-labelledby='Tax_Exempt_Number_Label']";
	public static String OpenUI_ABN_VALIDATE="//*[@aria-label='Account:Validate ABN/ACN']";
	public static String OpenUI_ABN_PICK="//*[@aria-label='ABR Enquiry:Pick']";
	public static String OpenUI_NOE="//*[@aria-label='Number of Employees']";
	public static String OpenUI_IndustryType="//*[@aria-labelledby='Industry_Type_Label']";
	public static String OpenUI_Customer_Row_ID="//*[@aria-label='Customer Row Id']";
	public static String OpenUI_AccountSave="//*[contains(@title,'Account:Save')]";
	public static String OpenUI_AccountEdit="//*[contains(@title,'Account:Edit')]";

	//Contacts
	public static String OpenUI_AcountSummarySelected="//*[@aria-label='Account Summary Selected']";
	public static String OpenUI_SharingDetailsSelected="//*[@aria-label='Sharing Details Selected']";
	public static String OpenUI_Thirdlevelviewbar="//*[@aria-label='Third Level View Bar']";
	public static String OpenUI_Thirdlevelviewbar2="//*[@aria-label='Third Level View Bar']";
	public static String OpenUI_ContactsSelected="//*[@aria-label='Contacts Selected']";
	public static String OpenUI_ContactQuery="//*[@aria-label='Contacts:Query']";
	public static String OpenUI_ContactsNew="//*[contains(@aria-label,'Contacts:New')]";
	public static String OpenUI_ContactsMenu="//*[contains(@title,'Contacts Menu')]";
	public static String OpenUI_ContactsMenu2="//*[contains(@title,'Contacts Menu')]";
	public static String OpenUI_ContactsNew2="//*[contains(@aria-label,'Contacts:New')]";
	public static String OpenUI_LastName="//*[contains(@aria-labelledby,'l_Last_Name')]";
	public static String OpenUI_LastName2="//*[contains(@aria-describedby,'l_Last_Name')]";
	public static String OpenUI_LastName3="//*[@id='1_s_1_l_Last_Name']";
	public static String OpenUI_ContactRole="//*[contains(@aria-labelledby,'VF_Contact_Role')]";


	public static String OpenUI_FirstName="//*[contains(@aria-labelledby,'l_First_Name')]";
	public static String OpenUI_FirstName2="//*[contains(@aria-describedby,'l_First_Name')]";
	public static String OpenUI_FirstName3="1_s_1_l_First_Name";
	public static String OpenUI_MiddleName="//*[contains(@aria-labelledby,'l_Middle_Name')]";
	public static String OpenUI_MiddleName2="id=1_s_1_l_Middle_Name";
	public static String OpenUI_M_M="//*[contains(@aria-labelledby,'M_M')]";
	public static String OpenUI_M_M2="//*[contains(@aria-labelledby,'M_M')]";
	public static String OpenUI_M_M3="id=1_s_1_l_M_M";
	public static String OpenUI_M_M4="id=1_s_1_l_M_M";
	public static String OpenUI_ContactPreferredName="//*[contains(@aria-labelledby,'Contact_Preferred_Name')]";
	public static String OpenUI_ContactPreferredName2="id=1_s_1_l_Contact_Preferred_Name";
	public static String OpenUI_BirthDate="//*[contains(@aria-labelledby,'l_Birth_Date')]";
	public static String OpenUI_BirthDate2="id=1_s_1_l_Birth_Date";
	public static String OpenUI_Home_Phone="//*[contains(@aria-labelledby,'Home_Phone')]";
	public static String OpenUI_Home_Phone2="id=1_s_1_l_Home_Phone__";
	public static String OpenUI_Cellular_Phone="//*[contains(@aria-labelledby,'Cellular_Phone')]";
	public static String OpenUI_Cellular_Phone2="id=1_s_1_l_Cellular_Phone__";
	public static String OpenUI_Email_Address="//*[contains(@aria-labelledby,'Email_Address')]";
	public static String OpenUI_Email_Address2="id=1_s_1_l_Email_Address";

	//Add Identity 1

	public static String OpenUI_IdentificationSelected="//*[contains(@aria-label,'Identification Selected')]";
	public static String OpenUI_Identification_New="//*[contains(@aria-label,'Identification:New')]";
	public static String OpenUI_IdType="//*[contains(@aria-label,'Id Type')]";
	public static String OpenUI_IdType2="//*[contains(@aria-label,'Id Type')]";
	public static String OpenUI_IdReference="//*[contains(@aria-label,'Id Reference #')]";
	public static String OpenUI_IdReference2="//*[contains(@aria-label,'Id Reference #')]";
	public static String OpenUI_Issuer="//*[contains(@aria-label,'Issuer')]";
	public static String OpenUI_Issuer2="//*[contains(@aria-label,'Issuer')]";
	public static String OpenUI_IdentificationSave="//*[contains(@aria-label,'Identification:Save')]";
	public static String OpenUI_Contact_role="//*[@name='VF_Contact_Role']";


	//Add Identity 2


	public static String OpenUI_CountryofIssue="//*[contains(@aria-label,'Country of Issue')]";
	public static String OpenUI_CountryofIssue2="//*[contains(@aria-label,'Country of Issue')]";

	//IDSCAN


	public static String OpenUI_SiebelToggle="//*[@un='SiebelToggle']";
	public static String OpenUI_SiebelToggle2="//*[@un='SiebelToggle']";
	public static String OpenUI_IDScanSessionsNew="//*[contains(@aria-label,'ID Scan Sessions:New')]";
	public static String OpenUI_IDScanMenu="//*[@title,'Identification Menu']";
	public static String OpenUI_IDScanBypassReasonCodeicon="//*[contains(@id,'1_ID_Scan_Bypass_Reason_Code_icon')]";
	public static String OpenUI_ScannerNotWorking="//*[contains(@class,'ui-corner-all') and text()='Scanner Not Working']";
	public static String OpenUI_IDScanSessionsSave="//*[contains(@aria-label,'ID Scan Sessions:Save')]";

	//Addresses

	public static String OpenUI_Addresses="//*[@un='Addresses']";
	public static String OpenUI_AccountAddressesNew="//*[@aria-label='Account Addresses:New']";
	public static String OpenUI_ButtonNew="//*[@id='ButtonNew']";
	public static String OpenUI_SearchText="//*[@id='SearchText']";

	public static String OpenUI_PickItemFormatFirst="//*[@class='pickitem format first']/a";
	public static String OpenUI_ButtonAccept="//*[@id='ButtonAccept']";
	public static String OpenUI_CustomerAddresses="//*[@summary='Customer Addresses']";
	public static String OpenUI_AddressesSelected="//*[@aria-label='Addresses Selected']";


	//Financial Profile
	public static String OpenUI_FinancialProfile="//*[@un='Financial Profile']";
	public static String OpenUI_FinancialProfileNew="//*[contains(@aria-label,'Financial Profile:New')]";
	public static String OpenUI_IntendedUsage="//*[contains(@aria-label,'Intended Usage')]";
	public static String OpenUI_Current_Address="//*[contains(@aria-label,'Current Address')]";
	public static String OpenUI_Current_Address2="//*[contains(@aria-label,'Current Address')]";
	public static String OpenUI_Current_AddressOK="//*[contains(@aria-label,'Addresses:OK')]";
	public static String OpenUI_Employment_Status="//*[contains(@aria-label,'Employment Status')]";
	public static String OpenUI_Years_Address="//*[contains(@aria-label,'Years @ Address')]";
	public static String OpenUI_Occupation="//*[contains(@aria-label,'Occupation')]";
	public static String OpenUI_Months_Address="//*[contains(@aria-label,'Months @ Address')]";
	public static String OpenUI_ResidentialStatus="//*[contains(@aria-label,'Residential Status')]";

	public static String OpenUI_EmpDurationYears="//*[contains(@aria-label,'Emp. Duration (Years)')]";
	public static String OpenUI_EmpDurationMonths="//*[contains(@aria-label,'Emp. Duration (Months)')]";

	public static String OpenUI_HoursperWeek="//*[contains(@aria-label,'Hours per Week')]";
	public static String OpenUI_CurrentEmployer="//*[contains(@aria-label,'Current Employer')]";
	public static String OpenUI_PreviousEmployer="//*[contains(@aria-label,'Previous Employer')]";
	public static String OpenUI_CreditCheckPermissionReceived="//*[contains(@aria-label,'Credit Check Permission Received')]";
	public static String OpenUI_EmployerContactPhone="//*[contains(@aria-label,'Employer Contact Phone #')]";
	public static String OpenUI_SalesAgentName="//*[contains(@aria-label,'Sales Agent Name')]";
	public static String OpenUI_EmployerContactName="//*[contains(@aria-label,'Employer Contact Name')]";
	public static String OpenUI_TypeofSale="//*[contains(@aria-label,'Type of Sale')]";
	public static String OpenUI_PermanentResidentYN="//*[contains(@aria-label,'Permanent Resident (Y/N)')]";

	//Financial Profile - Business
	public static String OpenUI_NoofEmployees="//*[@aria-labelledby='VF_Number_of_Employees_Label']";
	public static String OpenUI_NatureofBusiness="//*[@aria-label='Nature of Business']";
	public static String OpenUI_PositioninCompany="//*[@aria-label='Position in Company']";
	public static String OpenUI_NoofLocations="//*[@aria-label='Number of Locations']";
	public static String OpenUI_DirectorTimeinIndustry="//*[@aria-label='Director-Time in Industry (Mths)']";
	public static String OpenUI_TradingAddress="//*[@aria-label='Trading Address']";
	public static String OpenUI_CreditCheckPermission="//*[@aria-label='Credit Check Permission Received']";




	//Select Handset
	public static String OpenUI_HandsetList_New="//*[contains(@aria-label,'Handset List:New')]";


	public static String OpenUI_Id_devicename="//*[@id='1_s_1_l_Device_Name']";
	public static String OpenUI_DeviceName="//*[@name='Device_Name']";
	public static String OpenUI_DeviceName2="//*[@name='Device_Name']";
	public static String OpenUI_IDOK="//*[@rn='IdOK']";
	public static String OpenUI_Elementltr="//*[@class='siebui-element-ltr']";
	public static String OpenUI_Quantity="//*[@name='Quantity']";
	public static String OpenUI_FinancialProfileSubmitCreditCheck="//*[contains(@aria-label,'Financial Profile:Submit Credit Check')]";
	public static String OpenUI_SubmitCreditcheckDisabled="//*[@aria-label='Financial Profile:Submit Credit Check' and @disabled='disabled']";

	//Billing Account
	public static String OpenUI_BillingAccounts="//*[@un='Billing Accounts']";
	public static String OpenUI_BillingAccountViewAU="//*[@rn='VF Customer - Billing Account View - AU']";
	public static String OpenUI_BillingAccountsNew="//*[contains(@aria-label,'Billing Accounts:New')]";
	public static String OpenUI_BillingAccountsSave="//*[contains(@aria-label,'Billing Accounts:Save')]";
	public static String OpenUI_Name_readonlyfalse="//*[@aria-label='Name' and @aria-readonly='false']";
	public static String OpenUI_Billing_Profile="//*[text()='Billing Profile']";
	public static String OpenUI_ProductsandServicesNew="//*[@aria-label='Products and Services:New']";

	//Billing Profile
	public static String OpenUI_BillingAccount_ViewExtended="//*[@rn='VF Billing Account Profile View - Extended']";
	public static String OpenUI_BillingProfile_New="//*[contains(@aria-label,'Billing Profile:New')]";
	public static String OpenUI_BillingProfile_editemail="//*[contains(@aria-label,'Billing Profile:Edit Email Address')]";
	public static String OpenUI_Emailto="//*[@aria-label='Email Bill To' and @aria-readonly='false']";
	public static String OpenUI_updatebillingemailaddress="//*[contains(@aria-label,'Update Billing Email Address:OK')]";
	public static String OpenUI_Payment_Type_Label="//*[@aria-labelledby='Payment_Type_Label']";
	public static String OpenUI_Payment_Type_Label2="//*[@aria-labelledby='Payment_Type_Label']";
	public static String OpenUI_Bank_Branch_Label="//*[@aria-labelledby='Bank_Branch_Label']";
	public static String OpenUI_AccountNamelabel="//*[@aria-labelledby='Account_Name_Label']";
	public static String OpenUI_AutomaticDebit_EditAccount="//*[@aria-label='Automatic Debit:Edit Account #']";
	public static String OpenUI_AccountNo_Label="//*[@aria-labelledby='Account_#_Label']";
	public static String OpenUI_UpdateBankAccountNumberOK="//*[@aria-label='Update Bank Account Number:OK']";
	public static String OpenUI_AutomaticDebit_Save="//*[@aria-label='Automatic Debit:Save']";

	//Installed Assets


	public static String OpenUI_PickProposition_PromotionGo="//*[@aria-label='Pick Proposition/Promotion:Go']";
	public static String OpenUI_PopupQuerySrchspec="//*[contains(@rn,'PopupQuerySrchspec')]";
	public static String OpenUI_PopupQuerySrchspec2="//*[contains(@rn,'PopupQuerySrchspec')]";
	public static String OpenUI_PickProposition_PromotionOK="//*[@aria-label='Pick Proposition/Promotion:OK']";
	public static String OpenUI_LineItemsCustomize="//*[@aria-label='Line Items:Customize']";
	public static String OpenUI_Label="//*[text()='Order #']/../../..//td[3]//div//input";


	//Customize
	public static String OpenUI_LineItem_Customize="//*[@aria-label='Line Items:Customize']";
	public static String OpenUI_CxObjName="id=CxObjName";
	public static String OpenUI_DOMAINSELECT="//*[contains(@id,'DOMAINSELECT')]";
	public static String OpenUI_DOMAINSELECT2="//*[contains(@id,'DOMAINSELECT')]";
	public static String OpenUI_QuantityInput="//*[contains(@id,'Quantity')]/input";
	public static String OpenUI_QuantityInput2="//*[contains(@id,'Quantity')]/input";
	public static String OpenUI_RaiseOrder="//button[contains(., 'Raise Order')]";
	public static String OpenUI_PropRaiseOrder="//*[@id='GRPITEM[~^`grpItemId1`^~[LINK']";
	public static String OpenUI_Display_Reason_Code="//*[contains(@aria-labelledby,'l_VF_Display_Reason_Code ')]";

	public static String OpenUI_Display_Reason_Code_icon="//*[contains(@id,'VF_Display_Reason_Code_icon')]";
	public static String OpenUI_CustomerRequested="//*[contains(@class,'ui-corner-all') and text()='Customer Requested']";
	public static String OpenUI_1VF_Comments1="//*[contains(@aria-labelledby,'l_VF_Comments')]";
	public static String OpenUI_VF_Comments="name=VF_Comments";
	public static String OpenUI_VF_Comments2="//*[@name='VF_Comments']";
	public static String OpenUI_LineDetailSelected="//*[contains(@aria-label,'Line Detail Selected')]";
	
	public static String OpenUI_DataOption = "//div[text()='Data Option']/ancestor::div[2]/div[1]";


	//Allocate SIM
	public static String OpenUI_AllocateSIM="//*[@un='Allocate SIM']";
	public static String OpenUI_SIMSwapQuery="//*[@aria-label='SIM Swap:Query']";
	public static String OpenUI_SIMSwapMenu="//*[@title='SIM Swap Menu']";
	public static String OpenUI_SIMSwapMenu2="//*[@title='SIM Swap Menu']";
	public static String OpenUI_SerialNo="//*[@aria-label='Serial #']";
	public static String OpenUI_SIM_SwapGo="//*[@aria-label='SIM Swap:Go']";
	public static String OpenUI_SIMSwapAllocate="//*[@aria-label='SIM Swap:Allocate']";
	public static String OpenUI_AllocateSIMSelected="//*[contains(@aria-label,'Allocate SIM Selected')]";
	public static String OpenUI_AllocatedSIMDeallocateSIM="//*[@aria-label='Allocated SIM:Deallocate SIM']";

	//Allocate MSISDN
	public static String OpenUI_AllocateMSISDN="//*[@un='Allocate MSISDN']";
	public static String OpenUI_AllocateMSISDNSelected="//*[@aria-label='Allocate MSISDN Selected']";
	public static String OpenUI_ChangeMSISDNQuery="//*[@aria-label='Change MSISDN:Query']";
	public static String OpenUI_ChangeMSISDNCancel="//*[@aria-label='Change MSISDN:Cancel']";
	public static String OpenUI_l_MSISDN="//*[contains(@aria-labelledby,'l_MSISDN ')]";
	public static String OpenUI_ChangeMSISDNGo="//*[@aria-label='Change MSISDN:Go']";
	public static String OpenUI_ChangeMSISDNAllocateMSISDN="//*[@aria-label='Change MSISDN:Allocate MSISDN']";
	public static String OpenUI_s_1_l="//*[@id='s_1_l']";
	public static String OpenUI_MSISDNSelected="//*[@id='s_1_l']//tr[3]//td[2]";
	public static String OpenUI_ChangeMSISDNAllocateMSISDNDisabled="//*[@aria-label='Change MSISDN:Allocate MSISDN' and @disabled='disabled']";
	public static String OpenUI_SalesOrderCalculateCharges="//*[@aria-label='Sales Order:Calculate Charges']";
	public static String OpenUI_MSISDNLabel="//*[contains(@id,'Label')]";
	public static String OpenUI_ChargesSelected="//*[@aria-label='Charges Selected']";
	public static String OpenUI_ManageOffers="//*[@un='Manage Offers']";
	public static String OpenUI_FourthLevelViewBar="//*[@aria-label='Fourth Level View Bar']";
	public static String OpenUI_AvailableOffersEdit="//*[@aria-label='Available Offers:Edit']";
	public static String OpenUI_SalesOrderSubmitOrder="//*[@title='Sales Order:Submit Order' and @rn='SubmitOrder']";
	public static String OpenUI_PaperlessBypassReason="//*[@aria-label='Paperless Bypass Reason']";
	public static String OpenUI_Status_Label="//*[@aria-labelledby='Status_Label']";
	public static String OpenUI_SalesOrderMenu="//*[@title='Sales Order Menu']";
	public static String OpenUI_SalesOrderMenu2="//*[@title='Sales Order Menu']";
	public static String OpenUI_ExecuteQuery="//*[@title='Execute Query']";

	//Allocate IMEI

	public static String OpenUI_Allocate_IMEI_tab="//*[text()='Allocate IMEI']";
	public static String OpenUI_IMEISwapQuery="//*[@aria-label='Allocate IMEI:Query']";
	public static String OpenUI_IMEISwapMenu="//*[@title='Allocate IMEI Menu']";
	public static String OpenUI_IMEI="//*[@aria-label='IMEI']";
	public static String OpenUI_IMEI1="//*[@aria-label='IMEI']";
	public static String OpenUI_Allocate_IMEI_Go="//*[@aria-label='Allocate IMEI:Go']";
	public static String OpenUI_Allocate_IMEI_Go1="//*[@aria-label='Allocate IMEI:Go']";
	// public static String OpenUI_Allocate_IMEI_Go="//*[@rn='WriteRecord']";
	// public static String OpenUI_Allocate_IMEI_Go="//*[@id='s_1_1_21_0_Ctrl']";
	// public static String OpenUI_Allocate_IMEI_Go="//*[@id='S_A1']//*[@class='AppletHIFormBorder']//*[@class='AppletBackTable']//*[@class='AppletBack']/td[2]/button";



	//MSO

	public static String OpenUI_LineItemNew="//*[@aria-label='Line Items:New']";
	public static String OpenUI_nextpropclick="//*[@class='tree-wrap tree-wrap-ltr']/..//span[text()='2']/..";

	//Billing Account Status
	public static String OpenUI_BillingAccountSearch="//*[text()='Search']";
	public static String OpenUI_BillingAccountlookup="//*[@id='lookinCombo']";
	public static String OpenUI_BillingAccountselect="//*[@id='lookinCombo']//option[3]";
	public static String OpenUI_msisdnselect="//*[@id='lookinCombo']//option[5]";
	public static String OpenUI_BillingAccountAccNumber="//*[@title='Account #' and @type='text']";
	public static String OpenUI_BillingAccountAccNumberSearch="id=inner-adv-find-button";
	public static String OpenUI_BillingAccountSelect="//*[@class='siebui-search-highlight']";
	public static String OpenUI_BillingAccountText="//*[text()='Billing Account']";
	//***account status***//
	public static String OpenUI_BillingAccountStatus="//*[@aria-label='Account Status']";
	public static String OpenUI_BillingAccountStatus2="//*[@aria-label='Account Status']";
	public static String OpenUI_BillingAccountBalanceRetrieveAll="//*[@aria-label='Balances:Retrieve All']";
	public static String OpenUI_BillingAccountBalanceShowMore="//*[@id='S_A3']//*[@title='Show More']";
	public static String OpenUI_BillingAccountBalanceShowMore2="//*[@id='S_A3']//*[@title='Show More']";
	//***getting balance value***//
	public static String OpenUI_BillingAccountTotalUnbilledBalance="//*[text()='Total Unbilled Balance']/..//td[3]";
	public static String OpenUI_BillingAccountTotalAmountDue="//*[text()='Total Due Amount']/..//td[3]";
	public static String OpenUI_BillingAccountTotalUnappliedAmount="//*[text()='Total Unapplied Amount']/..//td[3]";


	public static String OpenUI_BillingAccountInvoiceRetrieveAll="//*[@title='Invoice Charge Summary:Retrieve All']";

	public static String OpenUI_BillingAccountGoToBillingAccount="//*[text()='Go to Billing Account']";



	public static String OpenUI_Demo_Search="id=srch_icon";
	public static String OpenUI_Demo_Lookin="id=lookinCombo";

	/********************************************************************/
	//TBUI - Home

	public static String OpenUI_File="//*[@un='File']";
	public static String OpenUI_HomeSelected="//*[@aria-label='Home Selected']";

	//TBUI - Connect Postpaid

	public static String OpenUI_TBUI_ConnectPostpaid="//*[@aria-label='Connect Postpaid']";
	public static String OpenUI_TBUI_NextButton="//*[@aria-label='Next']";
	public static String OpenUI_TBUI_CoverageCheckRequired = "//*[@aria-labelledby='Coverage_Check_Required_Label']";
	public static String OpenUI_TBUI_CoverageCheckBitton = "//*[@un='Coverage Check']";


	//ABN Content 
	public static String OpenUI_TBUI_TradingAs ="//*[@aria-labelledby='Trading_As_Label']";
	public static String OpenUI_TBUI_TradingDate ="//*[@aria-labelledby='VF_Trading_Date_Label']";
	public static String OpenUI_TBUI_Company_Name_Label ="//*[@aria-labelledby='Company_Name_Label']";


	//Consumer - Customer Details

	public static String OpenUI_TBUI_CustomerSegment="//*[@aria-labelledby='VF_Customer_Segment_Label']";
	public static String OpenUI_TBUI_CAPIN="//*[@aria-labelledby='CAPIN_Label']";

	// Contact Details

	public static String OpenUI_TBUI_Title="//*[@aria-labelledby='Title_Label']";
	public static String OpenUI_TBUI_Title1="//*[@aria-labelledby='Title_Label']";
	public static String OpenUI_TBUI_DOB="//*[@aria-labelledby='Date_of_Birth_Label']";
	public static String OpenUI_TBUI_FirstName="//*[@aria-labelledby='First_Name_Label']";
	public static String OpenUI_TBUI_LastName="//*[@aria-labelledby='Last_Name_Label']";
	public static String OpenUI_TBUI_ContactNumber="//*[@aria-labelledby='Home_Phone_Label']";
	public static String OpenUI_TBUI_Email="//*[@aria-labelledby='Email_Address_Label']";

	// Address Information

	public static String OpenUI_TBUI_Address ="//*[@aria-labelledby='WSDL_Address_Label']";
	public static String OpenUI_TBUI_Address1="//*[@aria-labelledby='WSDL_Address_Label']";
	public static String OpenUI_TBUI_AddressCoverageCheck="//*[@aria-labelledby='Coverage_Check_Required_Label']";

	// Business - Customer Details

	public static String OpenUI_TBUI_ABNorACN="//*[@aria-labelledby='ABN/ACN_Label']";
	public static String OpenUI_TBUI_ValidateABNorACN="//*[@title='Customer Type:Validate ABN/ACN']";
	public static String OpenUI_TBUI_Pick="//*[@title='ABR Enquiry:Pick']";
	public static String OpenUI_TBUI_CustomerType="//*[@aria-labelledby='VF_Customer_Type_Label']";
	public static String OpenUI_TBUI_IndustryType="//*[@aria-labelledby='Industry_Type_Label']";
	public static String OpenUI_TBUI_EmployeeRange="//*[@aria-labelledby='Employee_Range_Label']";
	public static String OpenUI_TBUI_DecisionMaker="//*[@aria-labelledby='Is_Decision_Maker_Label']";

	// Capture Identification Details

	public static String OpenUI_TBUI_Identification_New="//*[@aria-label='Capture Identification Details:New']";
	//public static String OpenUI_TBUI_IDTypeOne="id=1_Id_Type";
	//public static String OpenUI_TBUI_IDTypeOne="//*[contains(@id,'Id_Type')]";
	public static String OpenUI_TBUI_IDTypeOne="//*[contains(@aria-labelledby,'Id_Type')]";
	public static String OpenUI_TBUI_IDTypeOne1="//*[contains(@id,'Id_Type')]";
	public static String OpenUI_TBUI_IDReferenceOne="//*[contains(@id,'Id_Reference_Number')]";
	public static String OpenUI_TBUI_IDReferenceOne1="//*[contains(@id,'Id_Reference_Number')]";
	public static String OpenUI_TBUI_IDExpiryOne1="//*[contains(@aria-labelledby,'Expiry_Date')]";
	public static String OpenUI_TBUI_IDStateOfIssueOne="//*[contains(@aria-labelledby,'State_of_Issue')]";
	public static String OpenUI_TBUI_IDStateOfIssueOne1="//*[contains(@aria-labelledby,'State_of_Issue')]";
	public static String OpenUI_TBUI_IDCountryOfIssueOne="//*[contains(@aria-labelledby,'Country_of_Issue')]";

	// ID Scanning

	public static String OpenUI_TBUI_IDScanningNew="//*[@aria-label='ID Scanning:New']";
	public static String OpenUI_TBUI_IDScanning="name=ID_Scan_Bypass_Reason_Code";

	//Order #

	public static String OpenUI_TBUI_Order_Number="//*[@un='Order #']";

	//Credit Check

	//public static String OpenUI_TBUI_Employment_Status="//*[@rn='VFFinancialStatus']";
	//public static String OpenUI_TBUI_Occupation="//*[@rn='VFFinancialPosition']";
	//public static String OpenUI_TBUI_Occupation1="//*[@aria-labelledby='VFFinancialPosition_Label']";
	//public static String OpenUI_TBUI_Residential_Status="//*[@rn='Residental Status']";
	//public static String OpenUI_TBUI_Current_Address="//*[@rn='CurrentAddress']";
	//public static String OpenUI_TBUI_Current_Address1="//*[@rn='CurrentAddress']";
	//public static String OpenUI_TBUI_Current_Address_OK="//*[@aria-label='Addresses:OK']";
	//public static String OpenUI_TBUI_YearAtCurrentAddress="//*[@rn='VFCurrentYearsatAddress']";
	//public static String OpenUI_TBUI_Permanent_Resident="//*[@rn='Permanent Resident']";

	//Consumer

	public static String OpenUI_TBUI_Employment_Status_Dropdown="//*[@id='s_4_1_6_0_icon']";

	public static String OpenUI_TBUI_Employment_Status="//*[@aria-labelledby='VFFinancialStatus_Label']";
	public static String OpenUI_TBUI_Occupation="//*[@aria-labelledby='VFFinancialPosition_Label']";
	public static String OpenUI_TBUI_Occupation1="//*[@aria-labelledby='VFFinancialPosition_Label']";
	public static String OpenUI_TBUI_Residential_Status="//*[@aria-labelledby='Residential_Status_Label']";
	public static String OpenUI_TBUI_Current_Address="//*[@aria-labelledby='CurrentAddress_Label']";
	public static String OpenUI_TBUI_Current_Address1="//*[@aria-labelledby='CurrentAddress_Label']";
	public static String OpenUI_TBUI_Current_Address_OK="//*[@aria-label='Addresses:OK']";
	public static String OpenUI_TBUI_YearAtCurrentAddress="//*[@aria-labelledby='VFCurrentYearsatAddress_Label']";
	public static String OpenUI_TBUI_Permanent_Resident="//*[@aria-labelledby='Permanent_Resident_Label']";

	//Business

	public static String OpenUI_TBUI_NumberOfLocations="//*[@aria-labelledby='Number_of_Locations_Label']";
	public static String OpenUI_TBUI_ApplicantJobDetails="//*[@aria-labelledby='_Position_of_Applicant_Label']";
	public static String OpenUI_TBUI_TradingAddress="//*[@aria-labelledby='Trading_Address_Label']";
	public static String OpenUI_TBUI_TradingAddress1="//*[@aria-labelledby='Trading_Address_Label']";
	public static String OpenUI_TBUI_TradingAddress_OK="//*[@aria-label='Addresses:OK']";

	public static String OpenUI_TBUI_CurrentEmployer="//*[@aria-labelledby='VFEmployerCurrent_Label']";
	public static String OpenUI_TBUI_YearswithCurrentEmployer="//*[@aria-labelledby='VFYearswithCurrentEmployer_Label']";
	public static String OpenUI_TBUI_TimeinCurrentEmployer="//*[@aria-labelledby='VFTimeinCurrentEmployer_Label']";
	public static String OpenUI_TBUI_IntendedUsage="//*[@aria-labelledby='VFIntendedUsage_Label']";
	public static String OpenUI_TBUI_EmployerContactPhone="//*[@aria-labelledby='VFEmployerContactPhone_Label']";

	//HandSet List

	public static String OpenUI_TBUI_HandSet_New="//*[@title='Handset List:New']";
	public static String OpenUI_TBUI_HandSet_Name="//*[@name='Device_Name']";
	public static String OpenUI_TBUI_HandSet_Name1="//*[@name='Device_Name']";
	public static String OpenUI_TBUI_HandSet_Name2="//*[@id='1_s_8_l_Device_Name']";
	public static String OpenUI_TBUI_HandSet_Name3="//*[@id='1_s_8_l_Device_Name']";
	//	public static String OpenUI_TBUI_HandSet_OK="//*[@rn='IdOK']";
	public static String OpenUI_TBUI_HandSet_OK="//button[@data-display='OK']";
	public static String OpenUI_TBUI_DeviceNameText="//*[@rn='Device Name']";
	public static String OpenUI_TBUI_HandSet_Query="//*[@aria-label='Handset List:Query']";


	//Credit Check Authorisation

	//public static String OpenUI_TBUI_HandSet_Authorisation="//*[@rn='D B Identifier']";
	public static String OpenUI_TBUI_HandSet_Authorisation="//*[@aria-labelledby='D_B_Identifier_Label']";

	//Submit Credit check
	//public static String OpenUI_TBUI_Credit_Check_Submit="//*[@rn='VF Submit Credit Check']";
	public static String OpenUI_TBUI_Credit_Check_Submit="//button[text()='Submit Credit Check']";


	//Billing Options
	public static String OpenUI_TBUI_Billing_BSB="//*[@aria-label='BSB']";
	public static String OpenUI_TBUI_Billing_BSB_Search="//*[@id='s_9_1_8_0_icon']";
	public static String OpenUI_TBUI_Billing_BankDetails_BSB="//*[@aria-label='BSB Number']";
	public static String OpenUI_TBUI_Billing_BSB_Go="//*[@aria-label='Bank Details:Go']";
	public static String OpenUI_TBUI_Billing_BSB_Pick="//*[@aria-label='Bank Details:Pick']";
	public static String OpenUI_TBUI_Billing_Account_Edit="//*[@aria-label='Edit Account #']";
	public static String OpenUI_TBUI_Billing_Account_Number="//*[@aria-label='Account #']";
	public static String OpenUI_TBUI_Billing_Account_Number_OK="//*[@aria-label='Update Bank Account Number:OK']";
	public static String OpenUI_TBUI_Billing_Account_Name="//*[@aria-label='Account Name']";
	public static String OpenUI_TBUI_OrderID="//*[text()='Order #']/../../..//td[11]/div/input";
	public static String OpenUI_TBUI_CustomerRowID="//*[text()='Customer Row Id']/../../..//td[5]/div/input";

	//Billing Options -- E2E05

	public static String OpenUI_TBUI_Billing_NBN_BSB_Search_05="//*[@id='s_10_1_8_0_icon']";

	// Proposition - Plan

	public static String OpenUI_TBUI_Proposition_Add="//*[@aria-label='Proposition:Add']";
	public static String OpenUI_TBUI_Proposition_Table="//table[@summary='Proposition']/tbody/tr";
	public static String OpenUI_TBUI_Proposition_Table_ShowMore="//*[@class='AppletTitle' and text()='Proposition']/ancestor::table[1]//td//img[@alt='Show More']";
	
	public static String OpenUI_TBUI_Proposition_Query="//button[@aria-label='Proposition:Query']";
	public static String OpenUI_TBUI_Proposition_Query_Type="//input[@id='1_Name']";
		public static String OpenUI_TBUI_Proposition_Query_Go="//td[text()='Proposition']/following-sibling::td/button[@data-display='Go']";
	
	
	
	public static String OpenUI_TBUI_Customize="//*[@aria-label='Line Items:Customise']";
	
	
	
	
	

	public static String OpenUI_TBUI_Subscription_Options="//*[contains(@id,'DOMAINSELECT')]";
	public static String OpenUI_TBUI_Subscription_Options2="//*[contains(@id,'DOMAINSELECT')]";
	//public static String OpenUI_TBUI_DataOption="//*[@id='2-CN9XGXS`^~[PORT[~^`2-CKKLU1W`^~[PROD[~^`1-2TZ2C6Y`^~[FIELD[~^`Quantity']/input";
	//public static String OpenUI_TBUI_DataOption="//*[contains(@id,'Quantity')]/input";
	//public static String OpenUI_TBUI_DataOption="//*[@id='2-CN9Y4JP`^~[PORT[~^`2-CKKLU1W`^~[PROD[~^`1-2TZ2C6Y`^~[FIELD[~^`Quantity']//*[@name='GRPITEM[~^`2-CN9Y4JP`^~[PORT[~^`2-CKKLU1W`^~[DOMAIN']";
	public static String OpenUI_TBUI_DataOption="//*[@id='cxStd']/div[2]/div[2]/table[2]//*[@id='2-CKKY405`^~[PORT[~^`2-CKKLU1W']/div[3]/div/input";

	public static String OpenUI_TBUI_DataOption2="//*[contains(@id,'Quantity')]/input";
	public static String OpenUI_TBUI_RaiseOrder="//button[contains(., 'Raise Order')]";

	//public static String OpenUI_TBUI_Data_Option="//*[@id='2-CN9XGXS`^~[PORT[~^`2-CKKLU1W`^~[PROD[~^`1-2TZ2C6Y`^~[FIELD[~^`Quantity']/input";
	//public static String OpenUI_TBUI_Data_Option1="//*[@id='SPAN_2-CN9Y4JP`^~[PORT[~^`2-CKKLU1W']/div/div[3]/div/input";
	//public static String OpenUI_TBUI_Subscription_Options="//*[@id='2-CN9XGXS`^~[PORT[~^`2-CKKLU1P`^~[DOMAINSELECT']";
	//public static String OpenUI_TBUI_RaiseOrder="//*[@id='GRPITEM[~^`grpItemId1`^~[LINK']";
	//public static String OpenUI_TBUI_Proposition_Add="//*[@aria-label='Proposition:Add']";
	//public static String OpenUI_TBUI_Proposition_Add="//*[@aria-label='Proposition:Add']";
	//public static String OpenUI_TBUI_Proposition_Add="//*[@aria-label='Proposition:Add']";
	//public static String OpenUI_TBUI_Proposition_Add="//*[@aria-label='Proposition:Add']";


	//MSISDN - Go

	public static String OpenUI_TBUI_MSISDN_Go="//*[@aria-label='New MSISDN:Go']";
	public static String OpenUI_TBUI_MSISDN_Pick="//*[@aria-label='New MSISDN:Pick']";
	public static String OpenUI_TBUI_Notification_MSISDN_07="//*[@id='2_s_8_l_VF_AA_Set_Notification_MSISDN']";
	public static String OpenUI_TBUI_Notification_MSISDN="//*[@id='1']/td[10]/../td[4]";
	public static String OpenUI_TBUI_Notification_MSISDN_mark="//*[@id='1_VF_AA_Set_Notification_MSISDN']";

	//Sharing Setup

	public static String OpenUI_TBUI_External_Reference="//*[@aria-labelledby='VF_External_Reference_Id_Label']";
	public static String OpenUI_TBUI_Selection_Group_Label="//*[@aria-labelledby='Selection_Group_Label']";
	public static String OpenUI_TBUI_Edit_Group_Name="//*[@aria-labelledby='Group_Name_Label']";

	//Generate Contract

	public static String OpenUI_TBUI_Generate_Contract="//*[@aria-label='Generate Contract:Generate Contract']";
	public static String OpenUI_TBUI_Paperless_Reason="//*[@aria-label='Paperless Bypass Reason']";
	public static String OpenUI_TBUI_Submit="//*[@aria-label='Submit']";

	//Pause Button 
	public static String OpenUI_TBUI_PauseButton="//button[@aria-label='Pause']";

	
	//Sitemap
	public static String OpenUI_TBUI_SiteMap = "//*[@rn='SiteMap']";
	
	
	//Mobile Payment Plan
	public static String OpenUI_TBUI_MPP_Title  = "//*[@class='siebui-taskui-title' and contains(text(),' Mobile Payment Plan')]";
	public static String OpenUI_TBUI_MPP_ContractMonths  = "//input[@aria-labelledby='MPPContractMonths_Label']";
	
	
	
	
	
	
	
	
	
	
	
}	
