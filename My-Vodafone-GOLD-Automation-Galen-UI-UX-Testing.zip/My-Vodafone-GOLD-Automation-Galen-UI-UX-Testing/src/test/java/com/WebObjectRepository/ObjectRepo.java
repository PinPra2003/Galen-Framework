package com.WebObjectRepository;

public interface ObjectRepo {
/***SELENIUM POC***/	
public static String  DESKTOP_XPATH_Projects_Tab				=	"//li[contains(@id,'projects')]/a[contains(text(),'Projects')]";
public static String  DESKTOP_XPATH_Download_Tab				=	"//li[contains(@id,'download')]/a[contains(text(),'Download')]";
public static String  DESKTOP_XPATH_Documentation_Tab			=	"//li[contains(@id,'documentation')]/a[contains(text(),'Documentation')]";
public static String  DESKTOP_XPATH_Searchbox					=	"//form[contains(@id,'search')]//input[@id='q']";
public static String  DESKTOP_XPATH_Searchbox_Submit			=	"//form[contains(@id,'search')]//input[@id='submit']";

	


/**		LOGIN PAGE 		**/

public static String XPATH_USERNAME					=		"//input[contains(@name,'SWEUserName')]";
public static String XPATH_PASSWORD					=		"//input[contains(@name,'SWEPassword')]";
public static String XPATH_LoginButton				=		"//a[contains(text(),'Login')]";



/**		HOME PAGE		**/

public static String XPATH_SIEBEL_APP_MENU_TOGGLE	=		"//a[contains(@class,'siebui-appmenu-toggle')]";
public static String XPATH_CONNECTION_LINK			=		"//li[contains(@class,'ui-tabs-tab')]/a[contains(text(),'Connection')]";
public static String XPATH_TAB_LINK					=		"//li[contains(@class,'ui-tabs-tab')]/a[contains(text(),'<<TAB>>')]";
public static String XPATH_TAB_ISACTIVE_CHECK		=		"//li[contains(@class,'ui-tabs-tab')]/a[contains(text(),'<<TAB>>')]/ancestor::li[contains(@aria-selected,'true')]";

public static String XPATH_TASKS					=		"//li[contains(@title,'Tasks')]/span[contains(.,'Tasks')]";
public static String XPATH_TOOLBAR_OPTIONS			=		"//li[contains(@title,'<<OPTION>>')]/span[contains(.,'<<OPTION>>')]";


public static String XPATH_CONNECT_NBN_FROM_TASKS	=		"//span[not(contains(@class,'fancytree-folder'))]//*[contains(text(),'Connect NBN')]";
public static String XPATH_SESSION_ID				=		"//Input[contains(@aria-label,'Session Id')]";
public static String XPATH_ORDER_NUMBER				=		"//Input[contains(@aria-label,'Order Number')]";

public static String XPATH_TASK_PAGE_VERIFY				=		"//div[contains(@class,'siebui-applet-taskui-h') and contains(.,'<<TASK NAME>>')]";


}