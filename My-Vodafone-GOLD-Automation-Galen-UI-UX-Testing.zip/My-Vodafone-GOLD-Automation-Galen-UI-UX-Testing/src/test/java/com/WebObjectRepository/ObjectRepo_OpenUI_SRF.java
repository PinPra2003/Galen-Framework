package com.WebObjectRepository;

public interface ObjectRepo_OpenUI_SRF {

	public static String OpenUI_HELP="//span[text()='Help']";	
	public static String OpenUI_AboutView="//li[contains(@data-caption,'Help')]//li/a[text()='About View...']";
	public static String OpenUI_Applets="//div[@aria-label='Applets']";
	public static String OpenUI_AppletsOKButton="//button[@aria-label='About View:OK']";
	
	//*[@class='siebui-taskui-title']
	
}	
