package com.SharedModules;

/**
 * Author	:	Karthik Kannan
 * Version	:	1.0 
 */
public interface Constants {
	
public static final String InputSheet = System.getProperty("user.dir")+"/DataProvider/InputSheet.xls";
public static final String InputSheet_TestData = System.getProperty("user.dir")+"/DataProvider/TestData.xls";


public static final String TESTDATA_CAPIN="1378";
public static final String TESTDATA_SoletraderABN="88313125522";
public static final String TESTDATA_CorporateABN="61119369809";
public static final String TESTDATA_GovernmentABN="66638993569";
public static final String TESTDATA_TradingAs ="THE AUSTRALIAN MOVIE VOUCHER";
public static final String TESTDATA_TradingDate ="02/03/2010";
public static final String TESTDATA_TradingCompany ="13FILM CORPORATE PTY. LTD.";
public static final String TESTDATA_Address = "Level 7 40 Mount Street, NORTH SYDNEY NSW 2060";

public static final String DeviceList = "DESKTOP,TABLET,MOBILE";
public static final String[] DeviceList_Array = {"DESKTOP","TABLET","MOBILE"};
public static final	String GalenConfigFile = System.getProperty("user.dir")+"/PropertyFiles/GenericProperties/GalenConfig.properties";
public static final	String GalenSpecFileFolder= System.getProperty("user.dir")+"/Specification/";

}