package com.SharedModules;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.Engine.LoadEnvironment;
import com.Engine.Reporter;

public class DBUtilities {

	Reporter Report;
	public DBUtilities(Reporter report){
		Report = report;
	}

	public boolean updateCreditClass(String CustomerRowId) {
		boolean returnValue = false;
		try {

			Connection con = ConnectFactory.CreateConnection(LoadEnvironment.EnvironmentDataMap.get("Siebel_DB_URL"), 
					LoadEnvironment.EnvironmentDataMap.get("Siebel_DB_USERNAME"), 
					LoadEnvironment.EnvironmentDataMap.get("Siebel_DB_PASSWORD"));

			// create our java preparedstatement using a sql update query
			PreparedStatement ps;
			System.out.println("RUNNING PS ");
			ps = con.prepareStatement(
					"update siebel.s_finan_prof set X_CRDT_STAT_CD='APPROVE',X_CREDIT_CLASS='W',X_MAX_CONNECTIONS='10'  where accnt_id in ('"+CustomerRowId+"');");

			// call executeUpdate to execute our sql update statement and returns number of rows affected
			int updateCount = ps.executeUpdate();System.out.println("ROWS UPDATED IS  "+updateCount);
			ps.close();
			con.commit();
			ConnectFactory.CloseConnection(con);
			System.out.println("conn closed ");
			returnValue=true;
			Report.fnReportInfo("Credit Check updated to Approve for customer  " +CustomerRowId);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return returnValue;
	}

}
