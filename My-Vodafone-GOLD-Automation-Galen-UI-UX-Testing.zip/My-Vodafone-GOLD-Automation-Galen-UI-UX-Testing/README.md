+--src/
|  +--main/
|  |  +--java/
|  |  +--resources/
|  +--test/
|  |  +--java/
|  |  |  +--com/
|  |  |  |  +--BusinessModules/							#	Contains the business trasactions / functions 
|  |  |  |  |  +--Cucumber/									#	Cucumber modules
|  |  |  |  |  |  +--Commons/									#	This is a dependency injection module ( for variable sharing )
|  |  |  |  |  |  |  +--BaseClass.java							
|  |  |  |  |  |  +--Steps/										#	Cucumber step definitions
|  |  |  |  |  |  |  +--CommonDefinitions.java
|  |  |  |  |  |  |  +--StepDefn.java
|  |  |  |  |  |  |  +--StepDefn2.java
|  |  |  |  |  +--Java/										#  Business modules for Java based test scripts
|  |  |  |  |  |  +--SampleModule.java
|  |  |  |  +--Engine/									#	Contains functions for selenium based core activities ( driver, report creation etc.)
|  |  |  |  |  +--CommonStaticVariables.java
|  |  |  |  |  +--CucumberSetup.java
|  |  |  |  |  +--ExceptionHandlers.java
|  |  |  |  |  +--LoadEnvironment.java
|  |  |  |  |  +--Reporter.java
|  |  |  |  |  +--SeleniumSetup.java
|  |  |  |  |  +--TestListener.java
|  |  |  |  +--Enumerations/							#	Contains all enumerations used in the project
|  |  |  |  |  +--Generic/
|  |  |  |  |  |  +--DesktopTabletMobile.java
|  |  |  |  +--PUTTY/									#	Contains functions to perform basic Unix based operations
|  |  |  |  |  +--LogXmlParser.java
|  |  |  |  |  +--LrShell.java
|  |  |  |  +--Retry/									#	TestNG retry listners
|  |  |  |  |  +--Retry.java
|  |  |  |  |  +--RetryListener.java
|  |  |  |  +--SharedModules/							#	All shared functions / functions
|  |  |  |  |  +--Constants.java
|  |  |  |  +--TestSuite/								#	Contains all test scripts
|  |  |  |  |  +--Cucumber/									#	Contains cucumber based modules
|  |  |  |  |  |  +--Puppet.java
|  |  |  |  |  +--JAVASample/								#	Contains JAVA based modules
|  |  |  |  |  |  +--TC001_Sample_Testcase.java
|  |  |  |  |  +--TestData/									#	Contains scripts specific for Test data creations ( Parallel data drivien)
|  |  |  |  |  |  +--TC001_Sample_Testcase.java
|  |  |  |  +--Utils/									#	All utility classes
|  |  |  |  |  +--DataProviderExcelReader.java				#	For reading the row ids from excel ( Data driven input )
|  |  |  |  |  +--Decryptor.java							#	Decription script for property files
|  |  |  |  |  +--Encryptor.java							#	Encription script for property files
|  |  |  |  |  +--ReadExcelSheet.java						#	Data reader
|  |  |  |  |  +--Reusables.java							#	All reusable utils ( like date Time generator, random alpha numeric generator)
|  |  |  |  +--WebActions/								#	Functions to perform selenium actions
|  |  |  |  |  +--WebActions.java						
|  |  |  |  +--WebObjectRepository/						#	Web Object repository to store element locators
|  |  |  |  |  +--ObjectRepo.java
|  |  +--resources/																
|  |  |  +--features/									#	Cucumber feature files stored
|  |  |  |  +--Sample.feature
